#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>
#include "XMLParser.h"
#include <iostream>
#include <sstream>
#include "logic_gate.h"
#include "logic_circuit.h"
#include "logic_event.h"
#include "logic_junction.h"
#include "logic_wire.h"

TEST_CASE("Logic event, [LogicEvent]") {

    SUBCASE("Logic event is initialized properly") {
        Event e1, e2;
        REQUIRE_FALSE(e1.isJunctionEvent);
        REQUIRE_FALSE(e1.newJunctionState);
        REQUIRE(e1.junctionID == ID_NONE);
        REQUIRE(e1.wireID == ID_NONE);
        REQUIRE(e1.gateID == ID_NONE);
        REQUIRE(e1.newState == UNKNOWN);
        REQUIRE(e1.eventTime == TIME_NONE);
        REQUIRE(e1.gateOutputID == "");
        REQUIRE(e1.getCreationTime() == 0);
        REQUIRE(e2.getCreationTime() == 1);
    }

    SUBCASE("Logic event comparison when simulation time differs") {
        Event e1, e2;
        e1.eventTime = 2;
        e2.eventTime = 1;
        REQUIRE(e1 > e2);
    }

    SUBCASE("When simulation time is the same then the object created later is greater") {
        Event e1, e2;
        e1.eventTime = 10;
        e2.eventTime = 10;
        REQUIRE(e2 > e1);
    }
}

TEST_CASE("Logic junction, [LogicJunction]") {

    SUBCASE("Logic junction defaults to enabled state") {
        Junction junc{123};
        REQUIRE(junc.getEnableState());
    }

    SUBCASE("Setting enable state works") {
        Junction junc{7};
        REQUIRE(junc.getEnableState());
        junc.setEnableState(false);
        REQUIRE_FALSE(junc.getEnableState());
        junc.setEnableState(true);
        REQUIRE(junc.getEnableState());
    }

    SUBCASE("GetWires returns an empty list for empty junction") {
        Junction junc{123};
        auto wires{junc.getWires()};
        REQUIRE(wires.empty());
    }

    SUBCASE("ConnectWire connects wire to junction") {
        Junction junc{123};
        junc.connectWire(17);
        junc.connectWire(42);
        auto wires{junc.getWires()};
        REQUIRE(wires.size() == 2);
        REQUIRE(wires.count(17) == 1);
        REQUIRE(wires.count(42) == 1);
    }

    SUBCASE("DisconnectWire returns true when the final instance of a wire is removed from the junction") {
        Junction junc{7};
        junc.connectWire(17);
        junc.connectWire(42);
        junc.connectWire(42);

        bool wasLastConnection = junc.disconnectWire(42);
        REQUIRE_FALSE(wasLastConnection);

        wasLastConnection = junc.disconnectWire(17);
        REQUIRE(wasLastConnection);

        // Disconnecting an already-removed wire returns false (previously this
        // crashed via WARNING dereferencing a null logiclog; now null-guarded).
        bool falseOnDisconnectedWire = junc.disconnectWire(17);
        REQUIRE_FALSE(falseOnDisconnectedWire);

        auto wires{junc.getWires()};
        REQUIRE(wires.size() == 1);
        REQUIRE(wires.count(17) == 0);
        REQUIRE(wires.count(42) == 1);

        wasLastConnection = junc.disconnectWire(42);
        REQUIRE(wasLastConnection);
        auto wires2{junc.getWires()};
        REQUIRE(wires2.empty());
    }
}

TEST_CASE("Logic wire, [LogicWire]") {

    SUBCASE("Wires are created in high-impedance state") {
        Wire w;
        REQUIRE(w.getState() == HI_Z);
    }

    SUBCASE("WireInput operator < works primarily on gateID, secondarily on gateOutputID") {
        WireInput wi1{2, "a"};
        WireInput wi2{3, "b"};
        WireInput wi3{2, "b"};
        WireInput wi4{2, "a"};
        WireInput wi5{1, "b"};
        
        REQUIRE(wi1 < wi2);
        REQUIRE(wi5 < wi4);
        REQUIRE(wi3 < wi2);
        REQUIRE_FALSE(wi4 < wi5);
        REQUIRE_FALSE(wi2 < wi1);
        REQUIRE_FALSE(wi2 < wi3);
        REQUIRE(wi1 < wi3);
        REQUIRE_FALSE(wi3 < wi1);
        REQUIRE_FALSE(wi1 < wi1);
    }

    SUBCASE("WireOutput operator < works primarily on gateID, secondarily on gateInputID") {
        WireOutput wo1{2, "a"};
        WireOutput wo2{3, "b"};
        WireOutput wo3{2, "b"};
        WireOutput wo4{2, "a"};
        WireOutput wo5{1, "b"};
        
        REQUIRE(wo1 < wo2);
        REQUIRE(wo5 < wo4);
        REQUIRE(wo3 < wo2);
        REQUIRE_FALSE(wo4 < wo5);
        REQUIRE_FALSE(wo2 < wo1);
        REQUIRE_FALSE(wo2 < wo3);
        REQUIRE(wo1 < wo3);
        REQUIRE_FALSE(wo3 < wo1);
        REQUIRE_FALSE(wo1 < wo1);
    }

    // TODO: WIRE_PTR operator <

    SUBCASE("Wire can be forced to a given state") {
        // !StateType is just unsigned char so values 5->
        // are theoretically possible...

        // Range of values:
        // const StateType ZERO = 0;
        // const StateType ONE = 1;
        // const StateType HI_Z = 2;
        // const StateType CONFLICT = 3;
        // const StateType UNKNOWN = 4;

        Wire w;
        REQUIRE(w.getState() == HI_Z);
        w.forceState(ZERO);
        REQUIRE(w.getState() == ZERO);
        w.forceState(ONE);
        REQUIRE(w.getState() == ONE);
        w.forceState(CONFLICT);
        REQUIRE(w.getState() == CONFLICT);
        w.forceState(UNKNOWN);
        REQUIRE(w.getState() == UNKNOWN);
        w.forceState(HI_Z);
        REQUIRE(w.getState() == HI_Z);
    }

    SUBCASE("Wire getFirstInput returns first (sorted) non-NONE input or junk") {

        Wire w, w2;
        REQUIRE(w.getFirstInput().gateID == ID_NONE);
        w.connectInput(7, "bb");
        w.connectInput(3, "a");
        REQUIRE(w.getFirstInput().gateID == 3);

        w2.connectInput(ID_NONE, "asd");
        auto wi2 = w2.getFirstInput();
        REQUIRE(((wi2.gateID == ID_NONE) && (wi2.gateOutputID == "")));
    }

    SUBCASE("Wire getFirstOutput returns first (sorted) output or junk") {
        Wire w;
        REQUIRE(w.getFirstOutput().gateID == ID_NONE);
        w.connectOutput(8, "some-gate");
        w.connectOutput(5, "other-gate");
        REQUIRE(w.getFirstOutput().gateID == 5);
    }

    SUBCASE("Wire getOutputGates") {
        Wire w;
        REQUIRE(w.getOutputGates().empty());
        w.connectOutput(55, "some-gate");
        w.connectOutput(78, "other-gate");
        auto gates = w.getOutputGates();
        REQUIRE(gates.size() == 2);
        REQUIRE(gates.front() == 55);
        REQUIRE(gates.back() == 78);
    }
}

TEST_CASE("Logic gate setParameter during construction, [LogicGate]") {
    
    SUBCASE("N_INPUT") {
        Gate_N_INPUT ngate;
        REQUIRE(ngate.getParameter("INPUT_BITS") == "0");
    }

    SUBCASE("COMPARE") {
        Gate_COMPARE cgate;
        REQUIRE(cgate.getParameter("INPUT_BITS") == "0");
    }
    
    SUBCASE("GATE PASS") {
        Gate_PASS pgate;
        REQUIRE(pgate.getParameter("INPUT_BITS") == "1");
    }

    SUBCASE("GATE MUX") {
        Gate_MUX mgate;
        REQUIRE(mgate.getParameter("INPUT_BITS") == "0");
    }

    SUBCASE("GATE DRIVER") {
        Gate_DRIVER driver_gate;
        REQUIRE(driver_gate.getParameter("OUTPUT_BITS") == "0");
    }

    SUBCASE("GATE DECODER") {
        Gate_DECODER decoder_gate;
        REQUIRE(decoder_gate.getParameter("INPUT_BITS") == "0");
    }

    SUBCASE("GATE PRI ENCODER") {
        Gate_PRI_ENCODER encoder_gate;
        REQUIRE(encoder_gate.getParameter("INPUT_BITS") == "0");
    }

    SUBCASE("GATE ADDER") {
        Gate_ADDER adder_gate;
        REQUIRE(adder_gate.getParameter("INPUT_BITS") == "0");
    }

    SUBCASE("GATE JFKK") {
        Gate_JKFF JFKK_gate;
        REQUIRE(JFKK_gate.getParameter("SYNC_SET") == "false");
        REQUIRE(JFKK_gate.getParameter("SYNC_CLEAR") == "false");
    }

    SUBCASE("GATE RAM") {
        Gate_RAM RAM_gate;
        REQUIRE(RAM_gate.getParameter("ADDRESS_BITS") == "0");
        REQUIRE(RAM_gate.getParameter("DATA_BITS") == "0");
    }

    SUBCASE("GATE Junction") {
        Circuit cir;
        Gate_JUNCTION junction_gate(&cir);
        REQUIRE(junction_gate.getParameter("JUNCTION_ID") == "NONE");
    }
}

TEST_CASE("XMLParser writing, [XMLParser]") {
    std::ostringstream oss;
    XMLParser parser(&oss);

    SUBCASE("OpenTag") {
        parser.openTag("myTag");
        REQUIRE(oss.str() == "<myTag>");
    }

    SUBCASE("When opening more than one tag Then the tags are on separate lines") {
        parser.openTag("myTag");
        parser.openTag("mySecondTag");
        REQUIRE(oss.str() == "<myTag>\n<mySecondTag>");
    }

    SUBCASE("Create open tag with empty tag name") {
        parser.openTag("");
        REQUIRE(oss.str() == "<>");
    }

    SUBCASE("Write value for open tag") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        REQUIRE(oss.str() == "<myTag>myVal");
    }

    SUBCASE("Write multiple values for open tag") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        parser.writeTag("myTag", "myOtherVal");
        parser.writeTag("myTag", "myThirdVal");
        REQUIRE(oss.str() == "<myTag>myValmyOtherValmyThirdVal");
    }

    SUBCASE("Write empty value for open tag") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "");
        REQUIRE(oss.str() == "<myTag>");
    }

    SUBCASE("Write value for open tag that is not the latest writes nothing") {
        parser.openTag("otherTag");
        parser.openTag("myTag");
        parser.writeTag("otherTag", "otherVal");
        REQUIRE(oss.str() == "<otherTag>\n<myTag>");
    }

    SUBCASE("Write value for open tag that doesn't exist writes nothing") {
        parser.openTag("myTag");
        parser.writeTag("otherTag", "otherVal");
        REQUIRE(oss.str() == "<myTag>");
    }

    SUBCASE("Values with < in the beginning get the character replaced with bell") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "<<weirdValue>");
        REQUIRE(oss.str() == "<myTag>\a\aweirdValue>");
    }

    SUBCASE("closeTag with null string writes nothing") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        parser.closeTag("");
        REQUIRE(oss.str() == "<myTag>myVal");
    }

    SUBCASE("CloseTag closes latest open tag") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        parser.closeTag("myTag");
        REQUIRE(oss.str() == "<myTag>myVal</myTag>");;
    }

    SUBCASE("CloseTag with not the latest open tag writes nothing") {
        parser.openTag("firstTag");
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        parser.closeTag("firstTag");
        REQUIRE(oss.str() == "<firstTag>\n<myTag>myVal");
    }

    SUBCASE("CloseTag with non-existent tag writes nothing") {
        parser.openTag("myTag");
        parser.writeTag("myTag", "myVal");
        parser.closeTag("nonsense");
        REQUIRE(oss.str() == "<myTag>myVal");
    }
}

TEST_CASE("XMLParser reading, [XMLParser]") {
    std::fstream ifs(TESTXML_PATH, std::ios::in);  // path injected by CMake (TESTXML_PATH)
    // Fail loudly if the fixture is missing rather than limping on with cryptic
    // section failures.
    REQUIRE(ifs.is_open());
    XMLParser parser(&ifs, false);

    // Contents of test-file:
    // <hello>HelloValue</hello>
    // <port>PortValue
    // <inner-port>InnerValue</inner-port></port>
    //# Comment
    //<final>Final</final>

    SUBCASE("getCurrentIdx returns zero on construction") {
        REQUIRE(parser.getCurrentIndex() == 0);
    }

    SUBCASE("ReadTag") {
        REQUIRE(parser.readTag() == "hello");
    }

    SUBCASE("ReadTagValue") {
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.readTagValue("hello") == "HelloValue");
    }

    SUBCASE("ReadTagValue on non-value token returns empty string") {
        REQUIRE(parser.readTagValue("hello") == "");
    }

    SUBCASE("ReadTagValue with arbitrary tagName returns current tag value") {
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.readTagValue("nonsense") == "HelloValue");
    }

    SUBCASE("ReadTag repeatedly returns empty string until readCloseTag is called") {
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.readTag() == "");
        REQUIRE(parser.readTag() == "");
        REQUIRE(parser.readTag() == "");
        REQUIRE(parser.readCloseTag() == "hello");
        REQUIRE(parser.readTag() == "port");
    }

    SUBCASE("ReadCloseTag closes the most open tag") {
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.readCloseTag() == "hello");
        REQUIRE(parser.readTag() == "port");
        REQUIRE(parser.readTag() == "inner-port");
        REQUIRE(parser.readCloseTag() == "inner-port");
        REQUIRE(parser.readCloseTag() == "port");
    }

    SUBCASE("ReadCloseTag reads ahead tokens even if they are not read with readTag") {
        REQUIRE(parser.readCloseTag() == "hello");
    }

    SUBCASE("isTag and isCloseTag check the next token ahead") {
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == true);
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == false);
        parser.readTagValue("hello");
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == true);
        REQUIRE(parser.readCloseTag() == "hello");
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == true);
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.readTag() == "port");
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.readTag() == "inner-port");
        REQUIRE(parser.readCloseTag() == "inner-port");
        REQUIRE(parser.isTag(parser.getCurrentIndex()) == false);
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == true);
        REQUIRE(parser.readCloseTag() == "port");
    }

    SUBCASE("ReadTag munches comments and returns next token data") {
        REQUIRE(parser.readTag() == "hello");
        REQUIRE(parser.readCloseTag() == "hello");
        REQUIRE(parser.readTag() == "port");
        REQUIRE(parser.readTag() == "inner-port");
        REQUIRE(parser.readCloseTag() == "inner-port");
        REQUIRE(parser.readCloseTag() == "port");
        REQUIRE(parser.readTag() == "final");
        REQUIRE(parser.readTagValue("final") == "Final");
        REQUIRE(parser.readCloseTag() == "final");
    }
}

TEST_CASE("XMLParser survives line endings and truncation, [XMLParser]") {

    // Walk the document with the public reader and record what it hands back.
    auto tokenize = [](const std::string &xml) {
        std::istringstream iss(xml);
        XMLParser parser(&iss, false);
        std::vector<std::string> tokens;
        for (int i = 0; i < 100; i++) {
            if (parser.isTag(parser.getCurrentIndex())) {
                tokens.push_back("<" + parser.readTag() + ">");
            } else if (parser.isCloseTag(parser.getCurrentIndex())) {
                std::string closed = parser.readCloseTag();
                if (closed.empty()) break; // end of document
                tokens.push_back("</" + closed + ">");
            } else {
                std::string value = parser.readTagValue("");
                if (value.empty()) break;
                tokens.push_back(value);
            }
        }
        return tokens;
    };

    SUBCASE("CRLF tokenizes the same as LF") {
        std::vector<std::string> expected{"<library>", "<name>", "Test", "</name>", "</library>"};
        REQUIRE(tokenize("<library>\n<name>Test</name>\n</library>\n") == expected);
        REQUIRE(tokenize("<library>\r\n<name>Test</name>\r\n</library>\r\n") == expected);
    }

    SUBCASE("A missing trailing newline is not a cliff") {
        std::vector<std::string> expected{"<a>", "</a>"};
        REQUIRE(tokenize("<a></a>") == expected);
        REQUIRE(tokenize("<a></a>\r\n") == expected);
    }

    SUBCASE("Truncated documents end instead of running away") {
        const std::vector<std::string> openOnly{"<a>"};
        const std::vector<std::string> dangling{"<a>", "dangling"};
        const std::vector<std::string> pair{"<a>", "</a>"};
        REQUIRE(tokenize("").empty());
        REQUIRE(tokenize("<").empty());
        REQUIRE(tokenize("<unterminated").empty());
        REQUIRE(tokenize("<a></unterminated") == openOnly);
        REQUIRE(tokenize("<a>dangling") == dangling);
        REQUIRE(tokenize("<a></a>\n# comment with no newline") == pair);
    }

    SUBCASE("Reading past the end terminates rather than spinning") {
        std::istringstream iss("<a>value</a>");
        XMLParser parser(&iss, false);
        REQUIRE(parser.readTag() == "a");
        REQUIRE(parser.readTagValue("a") == "value");
        REQUIRE(parser.readCloseTag() == "a");
        // Nothing left: the parser reports the container closed and hands back
        // empty strings forever instead of looping.
        REQUIRE(parser.isCloseTag(parser.getCurrentIndex()) == true);
        REQUIRE(parser.readCloseTag() == "");
        REQUIRE(parser.readTag() == "");
        REQUIRE(parser.readTagValue("a") == "");
    }
}
