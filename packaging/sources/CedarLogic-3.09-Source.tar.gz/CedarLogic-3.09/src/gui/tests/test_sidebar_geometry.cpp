#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>
#include "SidebarGeometry.h"

TEST_CASE("A sidebar cannot hide the canvas or clip its four columns") {
    CHECK(clampSidebarWidth(10, 1000, 220, 200, 5) == 220);
    CHECK(clampSidebarWidth(5000, 1000, 220, 200, 5) == 795);
    CHECK(clampSidebarWidth(360, 1000, 220, 200, 5) == 360);
}

TEST_CASE("Widths saved on a larger display still fit a smaller window") {
    CHECK(clampSidebarWidth(800, 520, 220, 200, 5) == 315);
    CHECK(clampSidebarWidth(-1, 520, 220, 200, 5) == 220);
    // A minimized/unlaid-out splitter must never get a negative sash position.
    CHECK(clampSidebarWidth(240, 0, 220, 200, 5) == 1);
}
