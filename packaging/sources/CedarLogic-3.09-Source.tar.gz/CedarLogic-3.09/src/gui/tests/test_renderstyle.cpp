#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>
#include "render/RenderStyle.h"

using namespace cl::render;

TEST_CASE("Unknown wires keep their light-mode blue when dark mode is enabled") {
#if defined(__linux__) || defined(_WIN32)
    for (bool dark : {false, true}) {
        const Color c = RenderStyle::screen(dark).wire(WireState::Unknown, false).color;
        CHECK(c.r == doctest::Approx(0.3f));
        CHECK(c.g == doctest::Approx(0.3f));
        CHECK(c.b == doctest::Approx(1.0f));
    }
#endif
}

TEST_CASE("Cyan identifies short circuits in both themes") {
    for (bool dark : {false, true}) {
        for (WireState state : {WireState::Low, WireState::High, WireState::HiZ,
                                WireState::Unknown, WireState::Conflict}) {
            const Color c = RenderStyle::screen(dark).wire(state, false).color;
            const bool cyan = c.r == 0.0f && c.g == 1.0f && c.b == 1.0f;
            CHECK(cyan == (state == WireState::Conflict));
        }
    }
}
