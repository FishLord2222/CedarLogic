// This file includes opengl whether on windows, mac, or linux.
// 10/1/2016 - Tyler J. Drake

#ifndef GLWRAPPER_H
#define GLWRAPPER_H

using GLfloat = float;
using GLdouble = double;
using GLuint = unsigned int;
using GLubyte = unsigned char;
using GLushort = unsigned short;

#endif
