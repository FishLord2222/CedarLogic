/*****************************************************************************
   Project: CEDAR Logic Simulator
   Copyright 2006 Cedarville University, Benjamin Sprague,
                     Matt Lewellyn, and David Knierim
   All rights reserved.
   For license information see license.txt included with distribution.   

   LibraryParse: Uses XMLParser to parse library files
*****************************************************************************/

#ifndef LIBRARYPARSE_H_
#define LIBRARYPARSE_H_

#include "XMLParser.h"
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <sstream>

#include "logic_values.h"
#include "float.h"

using namespace std;

struct lgHotspot {
	lgHotspot( string nName = "", bool nIsInput = true, float nX = 0, float nY = 0, bool nIsInverted = false, string nEInput = "", int busLines = 1) : name(nName), isInput(nIsInput), x(nX), y(nY), isInverted(nIsInverted), logicEInput(nEInput), busLines(busLines) {};
	string name;
	bool isInput;
	float x, y;
	bool isInverted;
	string logicEInput;
	int busLines;
};

struct lgLine {
	lgLine( float nX1 = 0, float nY1 = 0, float nX2 = 0, float nY2 = 0, bool nIsLabel = false ) : x1(nX1), x2(nX2), y1(nY1), y2(nY2), isLabel(nIsLabel) {}
	float x1, x2, y1, y2;
	bool isLabel;
};

// A structured circular arc in a gate's shape (Workstream G). Unlike <line>,
// which bakes curves into ~20 straight chords at author time, an arc survives to
// the renderer so Skia can stroke it smooth at any zoom. Angles are degrees from
// +Y increasing clockwise toward +X -- the same convention <circle> uses -- so
// the AND body's right side is cx=0,cy=0,r=2,start=0,sweep=180.
struct lgArc {
	lgArc( float nCx = 0, float nCy = 0, float nR = 1, float nStart = 0, float nSweep = 360, bool nIsLabel = false )
		: cx(nCx), cy(nCy), r(nR), startDeg(nStart), sweepDeg(nSweep), isLabel(nIsLabel) {}
	float cx, cy, r, startDeg, sweepDeg;
	bool isLabel;
};

// A structured circle in a gate's shape (Workstream G) -- inversion bubbles,
// mostly. Kept whole so Skia strokes a true circle instead of the segs-gon the
// author baked in; segs is retained so the GL path can reproduce that old
// tessellation exactly (byte-stable) while Skia renders smooth.
struct lgCircle {
	lgCircle( float nCx = 0, float nCy = 0, float nR = 1, int nSegs = 12, bool nIsLabel = false )
		: cx(nCx), cy(nCy), r(nR), segs(nSegs), isLabel(nIsLabel) {}
	float cx, cy, r;
	int segs;
	bool isLabel;
};

struct lgDlgParam {
	string textLabel; // The label shown to the user when the widget is drawn. The "Visible Name" of the param.

	string name; // The "invisible name" of the param (either GUI or Logic).
	bool isGui; // True if the param is a gui type. False if it is a logic param.
	
	string type; // The "type" of this parameter. Type can be: STRING, INT, BOOL, FLOAT, FILE_IN, FILE_OUT.
	float Rmin, Rmax; // Number types can specify a min and max range for the variable.

	lgDlgParam( string ntextLabel = "", string nname = "", string ntype = "STRING", bool nisGui = true, float nRmin = -FLT_MAX, float nRmax = FLT_MAX ) : textLabel(ntextLabel), name(nname), isGui(nisGui), type(ntype), Rmin(nRmin), Rmax(nRmax) {};
};

struct LibraryGate {
	string gateName; // Note: All gates must have a gateName, to identify them in the library.
	string caption; // Note: Gate's caption will be shown as a tooltip in the library
	string guiType; // Note: If a gate has the default guiType, then guiType = "".
	string logicType; // Note: If a gate has no logic type, then logicType="".
	vector < lgHotspot > hotspots;
	vector < lgLine > shape;
	vector < lgArc > arcs; // Structured curved primitives (Workstream G); render smooth.
	vector < lgCircle > circles; // Structured circles (Workstream G); render smooth.
	vector < lgDlgParam > dlgParams; // The parameters to be listed in the "settings dialog".
	map < string, string > guiParams;
	map < string, string > logicParams;
};

class LibraryParse {
public:
	// Parse a gate library from its XML text. The library is compiled into the
	// executable (see EmbeddedRes.h), so there is no file to open.
	explicit LibraryParse(const string& xml);
	LibraryParse();
	virtual ~LibraryParse();

	// Added by Colin Broberg 11/16/16 -- need to make this a public function so that I can use it for dynamic gates
	void addGate(string libName, LibraryGate newGate);
	
	// Returns a gate from the library in lgGate.  If the gate does not
	//	exist in the library, returns false, otherwise true.
	bool getGate(string gateName, LibraryGate &lgGate);
	
	// Return the logic type of a particular gate:
	string getGateLogicType( string gateName );
	
	// Return the gui type of a particular gate type:
	string getGateGUIType( string gateName );
	
	string getName() { return libName; };
	
	map < string, map < string, LibraryGate > >* getGateDefs() { return &gates; };

private:
	// Read every library in the document into `gates`. The parser is passed in
	// rather than held, because it is alive only while the constructor runs.
	void parseFile( XMLParser &xparse );

	// Parse one shape object, adding an offset if needed.
	bool parseShapeObject( XMLParser &xparse, string type, LibraryGate* newGate,
	                       double offX = 0.0, double offY = 0.0, int labelGroup = -1 );

	string libName;
	
	// Maps library name to a map of gates, which maps to the librarygate struct
	map < string, map < string, LibraryGate > > gates;
};

#endif /*LIBRARYPARSE_H_*/
