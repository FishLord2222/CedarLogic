// RenderStyle -- how a target paints the semantic scene (Workstream G).
//
// The Scene stores *what a thing is* (a wire and its logic state, a gate of a
// kind, a label), never a baked color. RenderStyle turns that semantics into
// paint, per output. Two styles, one scene:
//
//   screen(): color-by-state, live -- net colors, LED/7-seg hues, selection and
//             hover overlays, the grid. Built for a backlit display.
//   print():  white ground, solid black strokes at legible weight; no grid, no
//             selection; hierarchy by line weight (buses heavier than nets), not
//             hue; live signal state never reaches paper -- a printout is the
//             static schematic (topology), not a snapshot of the running sim.
//             A KiCad-style title block frames the page.
//
// This split is why unifying screen and export is not a recolored screenshot:
// export has historically printed poorly in black-and-white because meaning was
// encoded in color, which collapses to indistinguishable grey on paper. Here the
// print style is a first-class rendering intent.
//
// Header-only C++11; zero impact on the default build until draw sites consult a
// style (phase G1/G4).

#ifndef CL_RENDER_RENDERSTYLE_H
#define CL_RENDER_RENDERSTYLE_H

#include <string>

#include "Scene.h"

namespace cl {
namespace render {

// Logic value, carried semantically so the *style* -- not the draw site --
// picks the paint.
enum class WireState { Low, High, HiZ, Unknown, Conflict };

enum class GateKind { Generic, Input, Output, Junction, Label };

// KiCad-style page frame: title, sheet, revision, date, author, sheet N of M.
struct TitleBlock {
	bool enabled;
	std::string title;
	std::string sheet;
	std::string revision;
	std::string date;
	std::string author;
	int sheetNumber;
	int sheetCount;
	TitleBlock()
		: enabled(false), sheetNumber(1), sheetCount(1) {}
};

struct RenderStyle {
	bool showGrid;        // print: false
	bool showSelection;   // print: false (no hover/selection overlays)
	bool showLiveState;   // print: false (no signal colors on paper)
	bool colorOutput;     // print: false (black on white)
	bool darkMode;        // screen: high-contrast dark palette
	TitleBlock titleBlock;

	RenderStyle()
		: showGrid(true), showSelection(true),
		  showLiveState(true), colorOutput(true), darkMode(false) {}

	// Centralized screen palette. Dark mode deliberately keeps the light-mode
	// signal colors so users do not have to relearn what green/blue/red/gray
	// mean. Only the neutral drawing colors invert for the black canvas: gates
	// and ordinary/idle wires become white, while signal-state colors remain
	// familiar.
	Color circuitColor() const {
		return darkMode ? Color(1.0f, 1.0f, 1.0f, 1.0f)
		                : Color(0.05f, 0.05f, 0.05f, 1.0f);
	}
	Color wireOnColor() const {
		// Preserve the light-mode red high-signal wire. Only an idle/neutral
		// wire is white in dark mode; red must remain red for readability.
		return darkMode ? Color(0.9f, 0.0f, 0.0f, 1.0f)
		                : Color(0.0f, 0.9f, 0.0f, 1.0f);
	}
	Color unknownColor() const {
#if defined(__linux__) || defined(_WIN32)
		return Color(0.3f, 0.3f, 1.0f, 1.0f);
#else
		return Color(0.5f, 0.5f, 0.5f, 1.0f);
#endif
	}
	Color undefinedColor() const {
		// Non-driven (HI_Z) nets use the original green in both themes.
		// Blue is reserved for UNKNOWN, not a disconnected/floating net.
		return Color(0.0f, 0.78f, 0.0f, 1.0f);
	}
	Color shortCircuitColor() const {
		return Color(0.0f, 1.0f, 1.0f, 1.0f);
	}
	Color gridColor() const {
		// The light grid is black-on-white. On a black canvas use a faint white
		// line instead so the grid remains visible without becoming dominant.
		return darkMode ? Color(1.0f, 1.0f, 1.0f, 0.12f)
		                : Color(0.0f, 0.0f, (float)0.08, (float)0.08);
	}
	Color selectionColor() const {
		return Color(0.0f, 0.4f, 1.0f, 1.0f);
	}
	Color selectionFillColor() const {
		Color c = selectionColor();
		c.a = 0.30f;
		return c;
	}

	// Paint for a wire of the given state. On screen, color by state and widen
	// buses; on paper, always solid black with weight carrying the bus/net
	// hierarchy and state ignored (topology only).
	Stroke wire(WireState state, bool isBus) const {
		const float netWidth = isBus ? 3.0f : 1.0f;
		if (!colorOutput || !showLiveState) {
			// Print: black, hierarchy by weight.
			return Stroke(Color(0, 0, 0, 1), isBus ? 2.4f : 1.4f);
		}
		Color c;
		switch (state) {
			case WireState::High:     c = wireOnColor(); break; // active
			case WireState::Low:      c = darkMode ? circuitColor()
			                                      : Color(0.0f, 0.35f, 0.0f); break; // idle
			case WireState::HiZ:      c = undefinedColor(); break; // hi-Z
			case WireState::Conflict: c = shortCircuitColor(); break; // conflict
			case WireState::Unknown:
			default:                  c = unknownColor(); break;
		}
		return Stroke(c, netWidth);
	}

	// Stroke color for a gate body. Black on paper; near-black on screen.
	Color gateStroke(GateKind /*kind*/) const {
		if (!colorOutput) return Color(0, 0, 0, 1);
		return circuitColor();
	}

	// Page/canvas background.
	Color background() const {
		return (colorOutput && darkMode) ? Color(30.0f / 255.0f, 30.0f / 255.0f,
		                                            30.0f / 255.0f, 1.0f) // #1e1e1e
		                               : Color(1, 1, 1, 1);
	}

	// The live, color-by-state screen style.
	static RenderStyle screen(bool darkMode = false) {
		RenderStyle s;
		s.darkMode = darkMode;
		return s;
	}

	// The static, black-and-white, print-legible schematic style.
	static RenderStyle print() {
		RenderStyle s;
		s.showGrid = false;
		s.showSelection = false;
		s.showLiveState = false;
		s.colorOutput = false;
		s.titleBlock.enabled = true;
		return s;
	}
};

}  // namespace render
}  // namespace cl

#endif  // CL_RENDER_RENDERSTYLE_H
