// SkiaBackend -- binds Skia's Ganesh GL backend to CedarLogic's existing GL
// context (Workstream G, phase G0).
//
// Supports GPU surfaces from an existing GL context and CPU raster surfaces.
// The Qt canvas uses the raster path for its cached circuit scene and exports.
//
// Compiles only under WITH_SKIA.

#ifndef CL_RENDER_SKIABACKEND_H
#define CL_RENDER_SKIABACKEND_H

#ifdef WITH_SKIA

#include "core/SkRefCnt.h"

class GrDirectContext;
struct GrGLInterface;
class SkSurface;
class SkImage;
class SkPicture;
class SkFont;
class SkFontMgr;
class SkTypeface;

namespace cl {
namespace render {

class SkiaBackend {
public:
	// One backend per GL context. Call after the GL context is current.
	static SkiaBackend& get();

	// Build the GrDirectContext from the current GL context (idempotent).
	// Returns false if Skia could not adopt the GL context.
	bool ensureContext();

	GrDirectContext* context() { return fContext.get(); }

	// Wrap the currently-bound GL framebuffer (fboId, usually 0 for the window)
	// as a render target surface. Caller must have made the GL context current.
	sk_sp<SkSurface> windowSurface(int width, int height, int fboId = 0,
	                               int sampleCount = 0, int stencilBits = 8);

	// A CPU raster surface for offscreen rendering (PNG/SVG/PDF, goldens).
	sk_sp<SkSurface> rasterSurface(int width, int height);

	// A default typeface for text, or null if none is available. Resolved at
	// runtime, most-specific first: CEDAR_FONT_FILE, a bundled res/ face, then a
	// platform system sans-serif. See defaultFont() for the full search order.
	const SkFont* defaultFont();

	// G0 proof: draw one stroked path and (if a font is available) one line of
	// text into `surface`, then flush. Renders to whatever the surface targets.
	void probe(SkSurface* surface);

	// Minimap thumbnail cache (used by skiaRenderWindowCached). The cached image
	// is reused while `key` and the size match; setMinimapCache replaces it.
	bool minimapCacheHit(unsigned long long key, int w, int h) const;
	SkImage* minimapCacheImage() const;
	void setMinimapCache(sk_sp<SkImage> img, unsigned long long key, int w, int h);

	// Main-canvas scene picture cache (used by skiaRenderWindowScene). The
	// recorded circuit is reused while `key` matches; a pan is a picture replay,
	// only a content/scale change re-records.
	bool sceneCacheHit(unsigned long long key) const;
	SkPicture* sceneCachePicture() const;
	void setSceneCache(sk_sp<SkPicture> pic, unsigned long long key);

private:
	SkiaBackend() {}
	SkiaBackend(const SkiaBackend&);
	SkiaBackend& operator=(const SkiaBackend&);

	sk_sp<GrDirectContext> fContext;
	sk_sp<const GrGLInterface> fInterface;   // native GL binding Ganesh drives
	sk_sp<SkImage> fMinimapCache;   // declared after fContext: destructs first
	unsigned long long fMinimapKey = 0;
	int fMinimapW = 0, fMinimapH = 0;
	sk_sp<SkPicture> fScenePicture;   // main-canvas circuit, world coords
	unsigned long long fSceneKey = 0;
	sk_sp<SkFontMgr> fFontMgr;
	sk_sp<SkTypeface> fTypeface;
	SkFont* fFont = nullptr;
	bool fFontTried = false;
};

}  // namespace render
}  // namespace cl

#endif  // WITH_SKIA
#endif  // CL_RENDER_SKIABACKEND_H
