#pragma once

// Edit these entries when preparing a release. Newest version goes first.
static const char* const CEDARLOGIC_CHANGELOG =
R"CHANGELOG(CedarLogic 3.09

- Avoid rereading tutorial files when resizing or switching appearance.

- Reload gate properties on every open, fixing stale TO/FROM names after
  copying and renaming another component or cancelling an edit.

- Recreate 76 tutorial screenshots using the current Qt interface.
- Update 41 help pages for current wiring, pages, dialogs and oscilloscope controls.
- Scale tutorial images proportionally in smaller windows and remove repeated titles.
- Add repeatable screenshot capture and offline help validation tools.
- Preserve the original faith-page illustration and consistent theme text colors.
- Restore theme-aware toolbar icons in the command reference.
- Improve the Final Project layout and document signing, appearance, editor
  settings, autosave/recovery and circuit editing locks.
- Increase tutorial mouse-wheel scrolling and respond immediately to rapid
  wheel events, retaining proportional high-resolution wheel movement.
- Handle touchpad pixel and momentum events in help, with a saved Help
  touchpad speed control in Editor preferences (1x to 8x, default 3x).

)CHANGELOG"
R"CHANGELOG(CedarLogic 3.08

- Restore blue connection rings when a wire or moved component is over a valid
  pin or wire target, including bus-width validation and cancellation cleanup.
- Prevent manually routed wires from folding into a switch after the connected
  switch is moved; preserve routing through cancel, undo/redo and save/reopen.
- Show a single snapped placement preview while dragging a sidebar component
  over the canvas, restoring the sidebar thumbnail when the pointer leaves.
- Preserve complete internal wire routes when moving a marquee-selected group;
  connections to gates outside the selection continue to stretch normally.
- Prevent crashes from deleted gates/wires and stale simulation updates.
- Correct junction bookkeeping and bounds-check bus connections.
- Harden wire cleanup, zero-length segments, dragging and collision bounds.
- Harden library XML parsing and repair conflicting gate-pin claims on load.
- Preserve recovery sources through failed autosaves and repeated crashes,
  until a successful save or explicit discard.
- Keep crash diagnostics local with a copy action; remove the upstream issue link.
- No Sentry SDK or automatic crash uploads.

)CHANGELOG"
R"CHANGELOG(CedarLogic 3.07

- Replaced wxWidgets completely with the Qt 6 frontend for Linux and Windows.
- Added a compact, rounded interface with themed dialogs and grouped Preferences.
- Added fuzzy sidebar search across gate categories and optional names beneath symbols.
- Sidebar names default to off and remember the selected setting across launches.
- Added six UI accent choices and system, light and dark appearance options.
- Added saved active-high/active-low decoder polarity in double-click properties,
  with inversion circles on active-low outputs.
- Added next-launch crash reports with copy/report actions and Windows debug symbols.
- Improved compact-sidebar performance with cached thumbnails, lazy drag previews
  and fewer redraws during resizing.
- Optimized gate lookups, wire capture, oscilloscope signal discovery and placement
  previews; reduced simulation data copies and clarified the affected editor code.
- Provided version-only Linux RPM/AppImage and portable Windows x64 downloads,
  with AppData metadata, a source archive and SHA-256 checksums.
- Fixed rotated TO/FROM labels for decimal, negative and wrapped angle values.
- Corrected memory-file extension parsing, including uppercase .CDM files.
- Refresh disconnected wire states while paused without advancing the clock.

)CHANGELOG"
#ifdef __linux__
R"CHANGELOG(CedarLogic for Linux 3.06

- Added a draggable, collapsible sidebar with a toolbar button and Ctrl+B.
- Remembered sidebar width and visibility; kept four gate columns and the
  circuit view centred while resizing.
- Matched undetermined wire colors in dark and light mode.
- Cleaned up the selector menu in the sidebar
- Released the previous circuit's open marker when starting a new circuit or
  opening a copy.
- Added Open in New Window beside Open in the File menu and toolbar, with
  Ctrl+Shift+O and independent simulation and undo history for each window.
- Kept the current circuit when its save prompt is canceled.

)CHANGELOG"
#endif
#ifdef _WIN32
R"CHANGELOG(CedarLogic for Windows 3.06

- Added a draggable, collapsible sidebar with a toolbar button and Ctrl+B.
- Remembered sidebar width and visibility; kept four gate columns and the
  circuit view centred while resizing.
- Matched unknown-wire blue in dark and light mode.
- Carried over save-cancel protection and document-lock cleanup from Linux.
- Added Open in New Window, with Ctrl+Shift+O and a toolbar button.
- Kept four gate columns in the sidebar and sized its popup to native rows.
- Applied the Windows dark-mode preference to the native window, menus,
  toolbar and dialogs, including switching back to light mode.
- Refreshed toolbar icons when switching themes.

CedarLogic for Windows 3.05

- Ported the local Linux 3.05 features and fixes to Windows.
- Includes the Skia renderer, dark circuit theme, circuit signatures,
  PNG/SVG/PDF export, and the offline release history below.
- Packaged with a Windows installer, shortcuts, and optional .cdl association.
- Fixed preference persistence when Windows closes the application.
- Increased toolbar icon contrast and matched icons to the native toolbar
  background when Windows uses dark mode.

)CHANGELOG"
#endif
R"CHANGELOG(CedarLogic for Linux 3.05

- Removed the Windows WinSparkle auto-update code and its download dependency.
- Download latest version now opens my Github release
- Added an offline, scrollable Changelog under Help
- Added a dark circuit and palette theme, including matching gates, wires, grid,
  minimap and export colors. Accessible in Preferences
- Improved image export with content-fitted sizes and a preview beyond the
  earlier resolution-option fix; updated the related help pages.
- Fixed crashes and stale state when replacing circuits or editing wires.
- Fixed gate and wire rendering cache updates, including TO/FROM labels.
- Sized View and Help menus from their themed entries each time they open,
  preventing clipping and excess empty space.
- Sized the section dropdown to its native rows without an empty tail,
  and matched its width to the selector button.
- Fixed parsing and clipboard edge cases found in the local Linux source.

CedarLogic for Linux 3.04

- Added T and F shortcuts to convert selected TO/FROM gates.
- Added Sign Circuit at the top of a project, with the username set in
  Edit > Preferences.
- Fixed the missing resolution option in Save Image settings.
- Removed Herobrine.

CedarLogic for Linux 3.03 (published September 20, 2026)

- Fixed a major bug that prevented saving or opening files.

CedarLogic for Linux 3.02 (published September 16, 2026)

- Brought CedarLogic to Linux using the initial Ubuntu 24.04 and Nix work.
- Tested Fedora and Arch Linux builds; provided an RPM and AppImage.
- Documented the extra Arch dependencies and future packaging plans.
)CHANGELOG";
