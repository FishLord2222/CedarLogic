/*****************************************************************************
   Project: CEDAR Logic Simulator

   GateLibrary: the loaded gate libraries and the parser that fills them.

   Consumers reach the loaded definitions through gateLibrary(), independently
   of the desktop frontend.
*****************************************************************************/

#pragma once

#include <map>
#include <string>
#include "LibraryParse.h"

class GateLibrary {
public:
	// The library currently shown in the palette.
	std::string currentLibrary;
	// Parser that reads gate-definition files into the maps below.
	LibraryParse libParser;
	// library name -> (gate name -> definition).
	std::map< std::string, std::map< std::string, LibraryGate > > libraries;
	// gate name -> the library that owns it (child -> parent).
	std::map< std::string, std::string > gateNameToLibrary;
};

// The process-wide gate library. Lives for the whole run, like the app it was
// carved out of; constructed on first use.
GateLibrary& gateLibrary();
