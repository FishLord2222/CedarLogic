/*****************************************************************************
   Project: CEDAR Logic Simulator
   Copyright 2006 Cedarville University, Benjamin Sprague,
                     Matt Lewellyn, and David Knierim
   All rights reserved.
   For license information see license.txt included with distribution.   

   guiGate: GUI representation of gate objects
*****************************************************************************/

#ifndef GUIGATE_H_
#define GUIGATE_H_


#include "gl_wrapper.h"

class guiWire;

#include <float.h>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <string>
#include <fstream>
#include "logic_values.h"
#include "XMLParser.h"
#include "klsCollisionChecker.h"
#include "klsMessage.h"


using namespace std;

#define GATE_HOTSPOT_THICKNESS 0.05

class gateHotspot : public klsCollisionObject {
friend class guiGate;
public:
	gateHotspot() : klsCollisionObject(COLL_GATE_HOTSPOT) {
		modelLocation = worldLocation = GLPoint2f( 0, 0 );
		busLines = 1;
		calcBBox();
	};

	gateHotspot( string hsName ) : klsCollisionObject(COLL_GATE_HOTSPOT), name( hsName ) {
		gateHotspot();
		busLines = 1;
	};

	// Create the bbox for this hotspot:
	void calcBBox( void ) {
		klsBBox newBBox;
		newBBox.addPoint( worldLocation );

		newBBox.extendTop( (GLfloat) GATE_HOTSPOT_THICKNESS / 2.0 );
		newBBox.extendBottom( (GLfloat) GATE_HOTSPOT_THICKNESS / 2.0 );
		newBBox.extendLeft( (GLfloat) GATE_HOTSPOT_THICKNESS / 2.0 );
		newBBox.extendRight( (GLfloat) GATE_HOTSPOT_THICKNESS / 2.0 );

		this->setBBox( newBBox );
	};

	GLPoint2f getLocation( void ) { return worldLocation; };

	void setBusLines(int _busLines) {
		busLines = _busLines;
	}

	int getBusLines() {
		return busLines;
	}

public:
	string name;

protected:
	int busLines;
	GLPoint2f modelLocation, worldLocation;
};


// Engine-neutral rendering seam (Workstream G); defined in gui/render/.
namespace cl { namespace render { class Scene; struct RenderStyle; } }

class guiGate : public klsCollisionObject {
public:
	guiGate();
	virtual ~guiGate();
	void setID(long nid) { gateID = nid; };
	unsigned long getID() { return gateID; };

protected:
	string libName;
	string libGateName;
public:
	void setLibraryName( string nLibName, string nLibGateName ) {
		libName = nLibName;
		libGateName = nLibGateName;
	};

	string getLibraryName( void ) {
		return libName;
	};

	string getLibraryGateName( void ) {
		return libGateName;
	};

	string getLogicType();
	string getGUIType();
	
	//****************************************************************
	//Edit by Joshua Lansford 12/25/2006
	//I made the doParamsDialog method below virtual
	//so that the that the subclass can call its own special type
	//of pop-up that it wants.
	//Specifically, the Z-80 Processor can call up it's pop-up window
	//and the ram gate can call up its own window that shows all
	//its ram contents.
	//*****************************************************************

	// Set and get param virtual functions, simply assigns a string
	virtual void setGUIParam( string paramName, string value ) {
		gparams[paramName] = value;
		if( paramName == "angle" ) {
			// Update the matrices and bounding box:
			updateConnectionMerges();
			updateBBoxes();
		}
	};
	virtual string getGUIParam( string paramName ) { return gparams[paramName]; };
	map < string, string >* getAllGUIParams() { return &gparams; };
	virtual void setLogicParam( string paramName, string value ) {
		lparams[paramName] = value;
	};
	virtual string getLogicParam( string paramName ) { return lparams[paramName]; };
	map < string, string >* getAllLogicParams() { return &lparams; };

	// Extra (name, value) params a gate type persists beyond its gparams/lparams
	// -- the model-serialization counterpart of saveGateTypeSpecifics(). The base
	// gate has none; guiGateRAM returns its memory contents.
	virtual void getTypeSpecificParams(vector< pair<string, string> > &out) const {}

	void declareInput(string name) { isInput[name] = true; };
	void declareOutput(string name) { isInput[name] = false; };

	// Emit this gate into the engine-neutral rendering Scene (Workstream G).
	// Base draws the gate outline + label lines under the model transform;
	// interactive subtypes can override to add their widgets. GL path untouched.
	virtual void drawToScene(cl::render::Scene& scene,
	                         const cl::render::RenderStyle& style);
	void setGLcoords( float x, float y, bool noUpdateWires = false );
	void getGLcoords( float &x, float &y );
	
	// Shift the gate by x and y, relative to its current location:
	void translateGLcoords( float x, float y );
	// Make all connections end their drag so segments are merged
	void finalizeWirePlacements( void );
	
	// Draw this gate as unselected:
	void unselect( void );
	void select( void ) { selected = true; };
	// Needed for toggles and keypads, maybe others; returns a message to be passed
	//	from a click.
	virtual klsMessage::Message_SET_GATE_PARAM* checkClick( GLfloat x, GLfloat y ) { return NULL; };
	
	// Draw this gate as selected from now until unselect() is
	// called, if the coordinate passed to it is within
	// this gate's bounding box in GL coordinates.
	// Return true if this gate is selected.
	bool clickSelect( GLfloat x, GLfloat y );

	// Insert a line in the line list.
	void insertLine( float x1, float y1, float x2, float y2, bool isLabel = false );

	// Insert a structured arc (Workstream G). Kept whole -- the Skia path strokes
	// it smooth, the GL path tessellates it -- rather than baked into chords.
	// Degrees from +Y clockwise, matching the <circle>/Scene convention.
	void insertArc( float cx, float cy, float r, float startDeg, float sweepDeg, bool isLabel = false );

	// Insert a structured circle (Workstream G). Skia strokes it true; GL redraws
	// the `segs`-gon the author baked in, keeping the fixed-function path stable.
	void insertCircle( float cx, float cy, float r, int segs, bool isLabel = false );

	// Recalculate the bounding box, based on the lines that are included alredy:
	virtual void calcBBox( void );


	// Insert a hotspot in the hotspot list.
	void insertHotspot( float x1, float y1, string connection, int busLines);

	// Check if any of the hotspots of this gate are within the delta
	// of the world coordinates sX and sY. delta is in gl coords.
	string checkHotspots( GLfloat x, GLfloat y, GLfloat delta );

	// Return the coordinates of the hotspot in GL world-space coords.
	void getHotspotCoords(string hsName, float &x, float &y);

	// Get the name of the hotspot that overlaps the one given.
	// Return "" for no overlap or bad hotspot name.
	std::string getHotspotPal(const std::string &hotspot);

	// Is a particular hotspot aligned to the vertical or horizontal edge?
	bool isVerticalHotspot( string hsName );

	// Update all wires connected to me
	// Update the connected wires' shapes to accomidate the new gate position:
	void updateConnectionMerges( void );
	
	klsBBox getModelBBox( void ) { return modelBBox; };
	// Everything the gate paints, decorations included -- what to frame a picture
	// of the gate with (see calcBBox). Unioned with the hit box because the
	// subclasses that override calcBBox (guiLabel, guiTO_FROM) size themselves
	// around rendered text and extend only that one.
	// NB the empty checks: addBBox on a reset box folds in its FLT_MAX sentinels
	// and yields an infinite box, which would scale a thumbnail to nothing.
	klsBBox getModelDrawBBox( void ) {
		if( modelDrawBBox.empty() ) return modelBBox;
		if( modelBBox.empty() ) return modelDrawBBox;
		klsBBox box = modelDrawBBox;
		box.addBBox( modelBBox );
		return box;
	};

	// World-space bbox of the gate BODY only (no hotspot pins). The collision
	// bbox (getBBox) is expanded by setBBox->makeValidBBox to enclose the hotspot
	// sub-objects for hover detection, which would let you select a gate by
	// clicking the empty space beside a pin; selection hit-tests against this
	// instead so it tracks the visible body.
	klsBBox getSelectionBBox( void ) { return selectionBBox; };

	// Get a hotspot from its name.
	gateHotspot * getHotspot(const std::string &hotspotName) {
		return hotspots[hotspotName];
	}

	// Get the gate's vertices (for SVG export, etc.)
	const vector<GLPoint2f>& getVertices() const { return vertices; }

	// Get the gate's label vertices (for SVG export, etc.)
	const vector<GLPoint2f>& getLabelVertices() const { return labelVertices; }

	// A structured arc in the gate outline (Workstream G): drawn smooth under
	// Skia, tessellated for GL/legacy export. Degrees from +Y, clockwise.
	struct GateArc { float cx, cy, r, startDeg, sweepDeg; bool isLabel; };

	// A structured circle in the gate outline (Workstream G) -- inversion bubbles.
	// Skia strokes it true; GL reproduces the `segs`-gon the author baked in.
	struct GateCircle { float cx, cy, r; int segs; bool isLabel; };

	// Get the gate's arcs / circles (for the legacy SVG export, etc.)
	const vector<GateArc>& getArcs() const { return arcs; }
	const vector<GateCircle>& getCircles() const { return circles; }

	// Get the gate's transformation matrix (for SVG export, etc.)
	const GLdouble* getModelMatrix() const { return mModel; }

protected:
	// Convert model->world coordinates:
	GLPoint2f modelToWorld( GLPoint2f c );
	
	// Get a world-space bounding box:
	klsBBox getWorldBBox( void ) { return this->getBBox(); };

protected:
	void updateBBoxes( bool noUpdateWires = false );

	GLdouble mModel[16];

public:

	void addConnection(string, guiWire*);
	guiWire* getConnection( string hotspot ) { return connections[hotspot]; };
	void removeConnection(string, int&);
	bool isConnected(string);
	bool isSelected() { return selected; };

	// Hashes of everything that affects how this gate is drawn, for the retained
	// Skia render caches. geometryHash covers the model transform (position,
	// rotation, flip) and GUI params (angle, box coords, label) -- what the
	// B&W minimap needs. appearanceHash adds selection and the logic params that
	// drive state fills (toggle/register/keypad values) -- what the live canvas
	// needs. Float BITS are hashed (a value->unsigned cast on negatives is UB).
	virtual unsigned long long geometryHash() const;
	unsigned long long appearanceHash() const;
	bool isConnectionInput(string idx) { return isInput[idx]; };
	
	void saveGate(XMLParser*);
	// Save in v1.x compatible format (single wire IDs)
	void saveGateLegacy(XMLParser*);

	//*********************************
	//Edit by Joshua Lansford 6/06/2007
	//I want the ram files to save their contents to file
	//with the circuit.  However, I don't want to send
	//an entire page of data up to the gui each time
	//an entry changes.
	//This way the ram gate can intelegently save what
	//it wants to into the file.
	//Also any other gate that wishes too, can also
	//save specific stuff.
	virtual void saveGateTypeSpecifics( XMLParser* xparse ){};
	//End of edit***********************


	// Return the map of hotspot names to their coordinates:
	map<string, GLPoint2f> getHotspotList( void ) { 
		map< string, GLPoint2f > remappedHS;
		map< string, gateHotspot* >::iterator hs = hotspots.begin();
		while( hs != hotspots.end() ) {
			remappedHS[hs->first] = (hs->second)->getLocation();
			hs++;
		}
		return remappedHS; 
	};
protected:
	long gateID;
	string gateType;
	string guiGateType;
	
	GLfloat myX, myY;

	bool selected; // Is this gate selected or not?

	// Model space bounding box:
	klsBBox modelBBox;
	klsBBox modelDrawBBox;
	klsBBox selectionBBox; // world-space body bbox (no hotspots), for selection
	
	vector<GLPoint2f> vertices;
	vector<GLPoint2f> labelVertices;
	// Structured arcs (Workstream G): drawn smooth under Skia, tessellated for GL.
	// GateArc is declared in the public section (getArcs()).
	vector<GateArc> arcs;
	vector<GateCircle> circles;
	// map i/o name to hotspot coord
	map< string, gateHotspot* > hotspots;
	// map i/o name to wire id
	map< string, guiWire* > connections;
	// map i/o name to status as input (true = input, false = output)
	map< string, bool > isInput;
	// map param name to value
	map< string, string > gparams;	// GUI params
	map< string, string > lparams;  // Logic params
};

class guiGateTOGGLE : public guiGate {
public:
	guiGateTOGGLE();
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;

	void setGUIParam( string paramName, string value );
	void setLogicParam( string paramName, string value );

	// Toggle the output button on and off:
	string getState() { return getLogicParam("TOGGLE_STATE"); };
	klsMessage::Message_SET_GATE_PARAM* checkClick( GLfloat x, GLfloat y );

protected:
	int renderInfo_outputNum;
	GLLine2f renderInfo_clickBox;
};

class guiGateKEYPAD : public guiGate {
public:
	guiGateKEYPAD();
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;
	void setLogicParam( string paramName, string value );

	// Toggle the output button on and off:
	klsMessage::Message_SET_GATE_PARAM* checkClick( GLfloat x, GLfloat y );
protected:
	GLLine2f renderInfo_valueBox;
private:
	string keypadValue;
};

class guiGateREGISTER : public guiGate {
public:
	guiGateREGISTER();
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;
	void setGUIParam( string paramName, string value );
	void setLogicParam( string paramName, string value );
protected:
	GLLine2f renderInfo_valueBox;
	GLdouble renderInfo_diffx;
	GLdouble renderInfo_diffy;
	bool renderInfo_drawBlue;
	int renderInfo_numDigitsToShow;
	string renderInfo_currentValue;
};

class guiGatePULSE : public guiGate {
public:
	guiGatePULSE() : guiGate() {
		// Set the default CLICK box:
		// Format is: "minx miny maxx maxy"
		setGUIParam( "CLICK_BOX", "-0.76,-0.76,0.76,0.76" );

		// Default to single pulse width:
		setGUIParam( "PULSE_WIDTH", "1" );
	};
	
	klsMessage::Message_SET_GATE_PARAM* checkClick( GLfloat x, GLfloat y );
};


class guiGateLED : public guiGate {
public:
	guiGateLED();
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;
	// The B&W markers (minimap/print) depend on the driving net's state, so fold
	// it into the geometry hash or the thumbnail caches a stale marker.
	unsigned long long geometryHash() const override;
	void setGUIParam( string paramName, string value );
protected:
	GLLine2f renderInfo_ledBox;
};


// ************************ Labels *************************
#define SELECTED_LABEL_INTENSITY 0.50

// Skia's em size runs larger than the retired GL bitmap font's nominal height,
// so text is drawn at TEXT_HEIGHT * this to keep cap heights matching.
#define TEXT_SKIA_SCALE 1.35f


class guiLabel : public guiGate {
public:
	guiLabel();
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;

	// Recalculate the label's bounding box:
	void calcBBox( void );
	
	// A convenience function that translates
	// TEXT_HEIGHT parameter into a GLdouble:
	GLdouble getTextHeight( void ) {
		istringstream iss(gparams["TEXT_HEIGHT"]);
		GLdouble textHeight = 1.0;
		iss >> textHeight;
		
		return textHeight;
	};

	// A custom setParam function is required because
	// the object must resize it's bounding box 
	// each time the LABEL_TEXT or TEXT_HEIGHT parameter is set.
	void setGUIParam( string paramName, string value );

private:
	// Draw anchor of the label text, in model space (calcBBox keeps it in sync).
	GLPoint2f textPos;
};


// ************************ TO/FROM gate *************************
#define TO_FROM_TEXT_HEIGHT 1.5
#define TO_BUFFER 0.4
#define FROM_BUFFER 0.0
#define FROM_FIX_SHIFT 0.0
#define FLIPPED_OFFSET 0.5

class guiTO_FROM : public guiGate {
public:
	guiTO_FROM();

	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style) override;
	unsigned long long geometryHash() const override;

	// Recalculate the gate's bounding box:
	void calcBBox( void );
	
	// A custom setParam function is required because
	// the object must resize it's bounding box 
	// each time the JUNCTION_ID parameter is set.
	void setLogicParam( string paramName, string value );

private:
	string textString = "Text";
	GLPoint2f textPos;
	float textWidth = 0.0f;
};


// ************************ RAM gate ****************************

//*************************************************
//Edit by Joshua Lansford 12/25/2006
//I am creating a guiGate for the RAM so that
//the ram can have its own special pop-up window
class guiGateRAM : public guiGate {
public:
	guiGateRAM();
	
	
	//Destructor for cleaning up private vars
	virtual ~guiGateRAM();
	
	//Saves the ram contents to the circuit file
	//when the circuit saves
	virtual void saveGateTypeSpecifics( XMLParser* xparse );

	//Model-serialization counterpart: emit RAM memory as (Address:<n>, <data>).
	virtual void getTypeSpecificParams(vector< pair<string, string> > &out) const;
	
	//Because the ram gui will be passed lots of data
	//from the ram logic, we don't want it all going
	//into the default hash of changed paramiters.
	//Thus we catch it here
	virtual void setLogicParam( string paramName, string value );

	//This method is used by the RamPopupDialog to
	//learn what values are at different addresses
	//in memory.
	unsigned long getValueAt( unsigned long address );
	
	//These is used by the pop-up to determine
	//what was the last value read and written
	long getLastWritten();
	long getLastRead();

private:
	//The pop-up dialog
	
	//This data is so we can fill the pop-up with relevent
	//information
	unsigned long dataBits;
	unsigned long addressBits;
	map< unsigned long, unsigned long > memory;
	
	//used for highlighting the last read and
	//written in the pop-up
	long lastWritten = -1;
	long lastRead = -1;
};
//End of edit

//*************************************************

#endif /*GUIGATE_H_*/
