/*****************************************************************************
   Project: CEDAR Logic Simulator

   Settings: user/application settings and derived timing.

   Shared model settings. Reach them through appConfig(); the Qt appearance
   controller supplies persisted values independently of the simulation.
*****************************************************************************/

#pragma once

#include <string>

struct ApplicationSettings {
	std::string gateLibFile;
	std::string textFontFile;
	std::string helpFile;
	std::string lastDir;
	std::string signatureName;
	int mainFrameWidth;
	int mainFrameHeight;
	int mainFrameLeft;
	int mainFrameTop;
	int timePerStep;
	int refreshRate;
	int autosaveSeconds;   // 0 disables autosave entirely
	float wireConnRadius;
	bool wireConnVisible;
	bool gridlineVisible;
	bool rightClickRotate;
	bool darkMode;
	int sidebarWidth = 240; // logical pixels, independent of display scaling
	bool sidebarVisible = true;
};

class Settings {
public:
	ApplicationSettings appSettings;
	// Milliseconds of simulated time per step (derived from appSettings.timePerStep).
	unsigned long timeStepMod = 0;
	// Directory the executable's resources load from (may differ from cwd).
	std::string resourcesDir;
};

// The process-wide settings. Lives for the whole run; constructed on first use.
Settings& appConfig();
