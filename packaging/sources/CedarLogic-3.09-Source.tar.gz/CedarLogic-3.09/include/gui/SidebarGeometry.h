#pragma once

#include <algorithm>

// Keep saved widths useful after moving to a smaller display. Widths passed to
// this helper use the same units (DIP for preferences, pixels for live layout).
inline int clampSidebarWidth(int requested, int available, int minimum,
                             int canvasMinimum, int sashWidth) {
    const int maximum = std::max(1, available - canvasMinimum - sashWidth);
    const int lower = std::min(minimum, maximum);
    return std::max(lower, std::min(requested, maximum));
}
