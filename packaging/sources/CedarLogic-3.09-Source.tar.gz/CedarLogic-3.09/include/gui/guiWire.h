/*****************************************************************************
   Project: CEDAR Logic Simulator
   Copyright 2006 Cedarville University, Benjamin Sprague,
                     Matt Lewellyn, and David Knierim
   All rights reserved.
   For license information see license.txt included with distribution.   

   guiWire: GUI representation of wire objects
*****************************************************************************/

#ifndef GUIWIRE_H_
#define GUIWIRE_H_

#include <cfloat>
#include <functional>
#include <string>
#include <vector>
#include "logic_values.h" // StateType
#include "klsCollisionChecker.h"
#include "wireSegment.h"
#include "wire/Hotspots.h"
#include "wire/SegmentMap.h"
#include "wire/WireShape.h"

// Engine-neutral rendering seam (Workstream G); defined in gui/render/.
namespace cl { namespace render { class Scene; struct RenderStyle; } }

class guiGate;
class XMLParser;

float distanceToLine(GLPoint2f p, GLPoint2f l1, GLPoint2f l2);

struct glWireRenderInfo {
	vector< GLPoint2f > vertexPoints;
	vector< GLPoint2f > intersectPoints;
	vector< GLLine2f > lineSegments;
};

class guiWire : public klsCollisionObject {
public:
	guiWire();

	virtual ~guiWire();

	// Connection functions
	//		addConnection: if openMode is true, then no shape is calculated; waiting for setSegmentMap call.
	void addConnection(guiGate* iGate, string connection, bool openMode = false);

	// Takes an id, not a pointer: a connection is a gid, and dropping one never
	// needed the gate itself. All copies are removed from the segment tree.
	void removeConnection(IDType gid, string connection);
	void removeConnection(guiGate* gate, string connection);

	// Drop every trace of a gate, whichever pins and however many copies.
	// Also clears segment-local copies of the connection.
	void removeGate(IDType gid);

	// The circuit this wire belongs to; used to resolve a wireConnection's gid
	// to a live guiGate* (see gateOf). Set by the editor when the wire is created.
	void setGateResolver(std::function<guiGate*(unsigned long)> resolver) { gateResolver = std::move(resolver); }

	long numConnections();

	vector < wireConnection > getConnections();

	// Update the placement of a connection by extending/moving its
	//	segment.  Will set up a mouse coord from the current position
	//	and another one from the new position to pass to updateSegDrag
	void updateConnectionPos(unsigned long gid, string connection);

	// Emit this wire into the engine-neutral rendering Scene (Workstream G).
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style);

	bool hover(float cx, float cy, float delta);

	GLPoint2f getCenter();

	// Moving functions
	void move(GLPoint2f origin, GLPoint2f delta);

	// Create the bbox for this wire, based on
	// the bboxes of the wire segments. Also,
	// add the wire segments into the subObjs list:
	void calcBBox();

	// Selection functions
	bool isSelected();
	void select();
	void unselect();

	// Set the wire's first (and most likely only) Id.
	void setID(IDType wireId);

	// Get the wire's first (and most likely only) Id.
	IDType getID() const;

	// Set the all of the wire's Ids (For buses, really).
	void setIDs(const std::vector<IDType> &ids);

	// Set all of the wire's Ids (For buses, really).
	const std::vector<IDType> & getIDs() const;
	
	// Set the state for each wire id. (again multiple because buses)
	void setState(std::vector<StateType> state);
	
	// Set the state of a busline in this wire from its id.
	void setSubState(IDType buslineId, StateType state);

	// Get the state for each wire id.
	const std::vector<StateType> & getState() const;

	// Render-cache signatures (see guiGate). geometryHash covers the wire's
	// routing (its line segments) + selection; appearanceHash adds signal state
	// (the net colour). Float bits are hashed to avoid the negative-cast UB.
	unsigned long long geometryHash() const;
	unsigned long long appearanceHash() const;

	// Get the intersection points for drawing connection dots
	const std::vector<GLPoint2f>& getIntersectPoints() const { return renderInfo.intersectPoints; }

	// Give directions for XML tag definition of wire
	void saveWire(XMLParser* xparse);
	// Save in v1.x compatible format (single wire ID)
	void saveWireLegacy(XMLParser* xparse);

	// Get the list of pointers to segments that constitute the wire shape
	// Get the mapping of ID to segment that is the wire shape
	//	NOTE: To do anything with the returned map via intersections of segs
	//			you must set the segments' parent map pointer
	map < long, wireSegment > getSegmentMap();

	// Set the map/tree from which the wire will generate its shape.
	//	Tree must contain valid wireConnection information.
	//	IMPORTANT: Also must set nextSegID to be a valid ID
	void setSegmentMap(map < long, wireSegment > newSegMap);
	void restoreSegmentMap(map < long, wireSegment > newSegMap);

	// We need to hold an initial seg map for undo/redo functionality.
	map < long, wireSegment > getOldSegmentMap();

	// Generates segList, all segments being generated
	//	from the coordinates of the connection point vertices.
	//	As segments are created, they are merged with segments
	//	following the same path, and duplicates are removed.
	void calcShape();  // TODO

	// Manual wire routing functionality
	//	Takes a mouse pointer and finds the segment in question.
	//	The segment is isolated between its nearest intersections
	//	and set as the dragging segment.
	bool startSegDrag(klsCollisionObject* mouse, const klsBBox* dragOrigin = nullptr);

	//	The current dragging segment is moved to a new position
	//	while the associated segments are added/modified to keep
	//	our drag segment connected in the tree
	void updateSegDrag(klsCollisionObject* mouse);

	//	The current dragging segment is dropped, clean up
	bool endSegDrag();

private:
	// Resolve a connection's gate id to its live guiGate* via the circuit.
	// Replaces the old raw guiGate* cached in wireConnection, which could dangle
	// across a gate delete/undo/paste.
	//
	// The editor destroys wires before replacing its gate registry. The assert
	// marks any caller that violates that ownership order.
	guiGate* gateOf(const wireConnection& c) const;

	// Answers where a connection sits by resolving its gate through the
	// circuit. The segment tree asks through this rather than reaching for a
	// gate itself, which is what lets it be exercised without a circuit.
	class GateHotspots : public cl::wire::Hotspots {
	public:
		explicit GateHotspots(const guiWire &w) : wire(w) {}
		GLPoint2f coordsOf(const wireConnection &c) const override;
		bool isVertical(const wireConnection &c) const override;
	private:
		const guiWire &wire;
	};

	GateHotspots hotspots() const { return GateHotspots(*this); }

	// Atomically replace the whole segment tree. Detaches the collision
	// sub-objects (raw pointers into the segMap values about to be freed), swaps
	// the map in, then rebuilds the registration via calcBBox -- so a wholesale
	// reassignment can never leave the collision checker holding a dangling
	// wireSegment pointer. Every `segMap = newMap` goes through here.
	void commitSegMap(map < long, wireSegment > newSegMap);

	// The owning circuit (gate registry). Non-owning.
	std::function<guiGate*(unsigned long)> gateResolver;

	// Tidy and join the wire's segments, keeping the collision checker and
	// render cache in step with the result.
	void mergeSegments();
	void generateRenderInfo();  // TODO




	// The segments, and everything that has to travel with them: the undo
	// snapshot, the id the next segment takes, the head, and the drag state.
	cl::wire::WireShape shape_;

	// What is the whole wire connected to?
	vector< wireConnection > connectPoints;

	// Instance vars
	bool selected;
	bool setVerticalBar;

	// The wire ids for each wire in the bus.
	// These same ids are used in the gui and logic systems.
	// There are maps of id to guiWire in GUICircuit and GUICanvas.
	// In these maps, the first bus id is used to look up the wire.
	// The other ids all point to null.
	std::vector<IDType> ids;

	// The state for each wire in the bus.
	// Most wires will have a vector of size 1.
	std::vector<StateType> state;

	glWireRenderInfo renderInfo;
};

#endif /*GUIWIRE_H_*/
