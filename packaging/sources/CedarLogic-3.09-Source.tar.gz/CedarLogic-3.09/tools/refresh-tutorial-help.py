#!/usr/bin/env python3
"""Refresh offline help prose and dimensions after running capture_tutorial."""
from pathlib import Path
from html import escape
import struct
import json,re
root=Path(__file__).resolve().parents[1]/'res/help'
pages={}
def page(file,title,blocks): pages[file]=(title,blocks)
def shot(name,caption): return ('image',name,caption)
page('Adding_Gates_To_A_Circuit.htm','Adding Gates To A Circuit',[
'1. Open CedarLogic. The sidebar contains the gate libraries; the canvas is on the right.',shot('image2','The current CedarLogic workspace.'),
'2. Search for “3-input xor” in the sidebar. Hover over a symbol to see its name.',shot('image4','Search locates the three-input XOR gate across libraries.'),
'3. Drag the XOR symbol onto the canvas. You can also click a symbol, then click the canvas. Escape cancels placement.',shot('image6','The placement preview follows the pointer onto the canvas.'),
'4. Release the drag, or click the canvas, to place one gate. Choose the symbol again to place another.',shot('image7','A placed three-input XOR gate.'),
'5. Clear the search and use the category dropdown to browse other libraries.',shot('image8','Input and Output contains switches, clocks, and LEDs.'),
'6. Arrange three On / Off Toggle Switches, three To links, nine From links, one three-input XOR, three two-input AND gates, and four LEDs as shown. Use the Basic Gates, Small Gates, and Input and Output categories, or search by name. The links will be named in the next lesson.',shot('Picture1','The initial layout, before naming links and connecting wires.')])
page('TO_FROM_Gates.htm','TO/FROM Gates',[
'1. To and From gates are named links. Links with the same label share a signal, including across circuit pages.',shot('Picture2','To and From symbols.'),
'2. Double-click a link to open Gate properties. Enter its name in Label and click OK.',shot('Picture3','Edit a named link in the current properties dialog.'),
'3. Name the input links A, B, and C. Give each From link the matching name shown below. The AND-gate input pairs are A/B, A/C, and B/C.',shot('Picture4','Named input links ready for wiring.')])
page('Connecting_Gates.htm','Connecting Gates',[
'1. Hover over a pin until the small red hotspot square appears.',shot('Picture5','Start at the switch output pin.'),
'2. Hold the left mouse button and drag toward the other pin. A straight green line previews the connection. You can also click the first pin and then click the second.',shot('Picture6','A wire preview follows the pointer.'),
'3. Move onto the target pin. A blue ring identifies an eligible connection target.',shot('Picture7','The target pin is ready to connect.'),
'4. Release on the target pin. The finished wire follows a horizontal and vertical route. Releasing over empty space cancels a held drag.',shot('Picture8','The completed connection.'),
'5. Connect the switches to their To links, the From links to the gate inputs, and each gate output to its LED.',shot('Picture9','The first module connected. Black indicates low; red indicates high. Green is non-driven and blue is unknown.')])
page('Disconnecting_Gates.htm','Disconnecting Gates',[
'1. Hover over a connected pin. The red hotspot square marks the pin; the wire may also show a red drag indicator.',shot('Picture10','A connected switch output.'),
'2. Right-click the pin to disconnect it. Right-clicking a wire segment deletes that wire; right-clicking a gate body rotates the gate. Ctrl+Z undoes the change.',shot('Picture11','The switch and named link after disconnection.')])
page('Selecting_Gates_Wires.htm','Selecting Gates/Wires',[
'1. Click a gate or wire to select it. Selected components use the original stippled appearance. Click empty canvas to clear the selection; Shift-click adds items.',shot('Picture12','A selected XOR gate.'),
'2. Drag from empty canvas to draw a selection rectangle around the gates and wires you want.',shot('Picture13','A selection rectangle around the logic section.'),
'3. Release to select the enclosed components. Ctrl+A selects everything on the current page.',shot('Picture14','The group after releasing the selection rectangle.')])
page('Manipulating_Selections_Of_Gates_Wires.htm','Manipulating Selections Of Gates/Wires',[
'1. Select the gates or wires you want to delete, then press Delete. Removing a gate disconnects its pins and trims the surviving wiring.',shot('Picture15','The XOR section selected.'),shot('Picture16','The selected gates removed. Undo restores them.'),
'2. Drag a selected gate or group to move it. Connected wires adjust their routes as components move. Undo the deletion, then try moving the XOR section.',shot('Picture17','Moving a connected section preserves its connections.')])
page('Wiring.htm','Wiring',[
'CedarLogic routes finished wires horizontally and vertically. Move a segment to adjust the route without disconnecting its pins.',
'1. Place a clock and an LED and connect the clock output to the LED.',shot('Picture18','A routed clock-to-LED connection.'),
'2. Hover over a wire segment until the red indicator appears. Drag the segment perpendicular to its direction.',shot('Picture19','The selected wire and its connected components.'),
'3. Moving a gate also adjusts the connected wire.',shot('Picture20','The LED moved while remaining connected.'),
'4. Continue adjusting the route as needed. Press Escape to cancel an active gesture, or Ctrl+Z to undo a completed move.',shot('Picture21','An adjusted wire route.')])
page('Adding_Text.htm','Adding Text',[
'1. Search for Label in the sidebar and choose the text label component.',shot('image9','Find the Label component.'),
'2. Place the label above the circuit.',shot('Picture22','A text label placed on the canvas.'),
'3. Double-click it to open Gate properties. Set Label to Input, adjust Text Height if needed, and click OK.',shot('Picture23','The current label properties dialog.'),
'4. Labels can be moved and deleted like gates. Try adding a few labels, then delete the extras before continuing.'])
page('Saving_Opening_A_Circuit.htm','Saving/Opening A Circuit',[
'1. Choose File > Save or press Ctrl+S. A new circuit opens the save dialog; choose a folder and a .cdl filename.',shot('image12','The File menu contains Save and Save As.'),shot('image13','The save dialog. Its appearance depends on your operating system.'),
'2. Choose File > Open or press Ctrl+O to open a .cdl circuit.',shot('image23','Open is available in the File menu and toolbar.'),shot('image24','Choose a saved circuit to open.'),
'3. Each window edits one circuit file. Open Circuit in New Window (Ctrl+Shift+O) opens another independent window. Save this exercise before continuing.'])
page('Printing_Exporting_A_Circuit.htm','Printing/Exporting A Circuit',[
'1. Choose File > Export as Image. To print, export a PDF and print it from your PDF viewer.',shot('image15','Export as Image in the current File menu.'),
'2. Choose color or black and white, grid lines, and a resolution. Export to File offers PNG, SVG, and PDF. SVG and PDF preserve scalable circuit drawing; resolution choices control raster output. Copy to Clipboard copies a screen-resolution image.',shot('image16','The current image export dialog.'),
'3. Export includes the complete current-page circuit, fitted to the output. Save the editable .cdl file as well.',shot('image20','The circuit remains editable after exporting.')])
page('Review.htm','Review',[
'Complete the one-bit full adder below. The three-input XOR produces Sum. Three AND gates detect the A/B, A/C, and B/C pairs; a three-input OR combines their outputs to produce Carry.',shot('image3','A complete one-bit full adder.'),
'A and B are the input bits; C is carry-in. Sum = A XOR B XOR C. Carry = (A AND B) OR (A AND C) OR (B AND C). Toggle the switches to check all eight input combinations.'])
page('Copying_Pasting.htm','Copying/Pasting',[
'1. Select the input switches and their To links, then press Ctrl+C. Copy is also available in Edit and the toolbar.',shot('image4-copy','Select the input section to copy.'),
'2. Press Ctrl+V. The pasted selection follows the pointer until you click to place it. Escape cancels.',shot('image5-copy','A second input section pasted onto the canvas.'),
'3. Move the copied section into free space. Links retain their labels, so copies named A, B, or C still share the original signals. Avoid conflicting switch drivers on the same named net.',shot('image6-copy','The copied section moved below the original.'),
'4. Copy and paste works between circuit pages and separate CedarLogic windows. Delete the extra input section before continuing.',shot('image9-copy','Fit circuit shows both sections.')])
page('Undo_Redo.htm','Undo/Redo',[
'1. Undo reverses an edit. Use Ctrl+Z, Edit > Undo, or the toolbar. Save often as you work.',shot('image38','Start with the complete adder.'),
'2. Select the logic section.',shot('image12-undo','The gates selected for deletion.'),
'3. Press Delete.',shot('image13-undo','The input section remains after deletion.'),
'4. Press Ctrl+Z to restore the deleted gates and wires.',shot('image14-undo','Undo restores the logic section.'),
'5. Press Ctrl+Shift+Z or Ctrl+Y to redo the deletion. Undo once more to restore the adder before continuing.',shot('image15-undo','Redo reapplies the deletion.')])
page('Advanced_Navigation.htm','Advanced Navigation',[
'1. Use the toolbar magnifiers, + and - keys, or the mouse wheel to zoom. The wheel zooms around the pointer.',shot('image27','The full circuit fitted into the current workspace.'),
'2. Zoom in to inspect a small section.',shot('image28','A closer view of the circuit.'),
'3. Pan with a middle-button drag or the arrow keys. The overview at the lower left shows the circuit and current viewport.',shot('image29','Navigation at a closer zoom.'),
'4. Click or drag within the overview to move the main view. Its accent-colored frame tracks the visible area.',shot('image30','A different portion of the circuit in view.'),
'5. Press Space or Ctrl+0, or choose View > Fit circuit, to return to the complete circuit.',shot('image32','Fit circuit restores the complete view.')])
page('Stepping.htm','Stepping',[
'1. Replace the C input switch with a clock, then connect it to the C named link.',shot('image33','A clock drives the carry-in signal.'),
'2. Pause with F5 or the Run/Pause toolbar button. The status bar shows Paused.',shot('image34','Simulation paused for inspection.'),
'3. Press F6 or the Step toolbar button to advance one simulation tick. Several ticks may pass before a clock edge occurs, and additional ticks let changes propagate through gates. Step works while simulation is paused.',shot('image35','The same circuit after stepping.'),
'4. Press F5 to resume. The Sim step interval controls the time between simulation updates.'])
page('Paging.htm','Paging',[
'1. Replace the clock with an On / Off Toggle Switch and restore the full adder.',shot('image16-page','The full adder with three input switches.'),
'2. Keep one copy of the full adder. The switches will stay on Page 1 and the logic will move to Page 2.',shot('image17-page','The circuit before separating it across pages.'),
'3. Add a page with Ctrl+T or the + button next to the page tabs. Click a tab to switch pages.',shot('image36','A second page added to the circuit.'),
'4. Select the logic section, including its From links, and copy it with Ctrl+C.',shot('image18-page','The logic section selected for transfer.'),
'5. Switch to Page 2.',shot('image37','A blank second page.'),
'6. Press Ctrl+V and click to place the circuit. Return to Page 1 and delete the original logic section, leaving the switches and To links. Matching A/B/C labels carry signals between pages.',shot('image40','The adder logic on Page 2.')])
page('Oscope_Mode.htm','Oscope Mode',[
'1. Return to Page 1, which contains the input switches and To links.',shot('image65','The inputs on Page 1.'),
'2. Replace the A and B switches with clocks and reconnect them to their named links.',shot('image64','Clocks drive A and B.'),
'3. Double-click the A clock. Set Half-period to 10 and click OK. Leave B at 5.',shot('image66','The current clock properties dialog.'),
'4. On Page 2, connect a To link named Sum to the XOR output net.',shot('image67','A named Sum link makes the output available to the oscilloscope.'),
'5. Choose View > Oscilloscope or press Ctrl+G.',shot('image69','The Oscilloscope command in View.'),
'6. The oscilloscope opens below the canvas. Drag the divider to resize it.',shot('image72','The docked oscilloscope before adding feeds.'),
'7. Choose A from the signal dropdown and click Add. Run the simulation, or step it while paused, to collect samples.',shot('image73','A single named signal in the oscilloscope.'),
'8. Add B and Sum the same way. Each named feed gets a waveform row.',shot('image71','Several signal feeds displayed together.'),
'9. Pause freezes the scope display; Resume / Reset starts a new capture. Use the feed selector and Remove to delete a row. The toolbar also copies the scope image and opens or saves .cdo layouts.',shot('image74','Compare input and output waveforms while debugging the adder.')])
page('Final_Project.htm','Final Project',[
'Build the circuit below using a 4-Bit Counting Register. Connect output bit 2 to A, bit 1 to B, and bit 0 to C. This keeps the three named links in top-to-bottom order without crossing their wires. Drive the register clock with a clock gate and hold Count Enable and Count Up high. Connect a low switch to Load and Reset. The high switch supplies both Count Enable and Count Up. The existing adder uses the same A/B/C links.',shot('image40-final','The register drives the full-adder inputs. Named links expose Sum and Carry.'),
'Open the oscilloscope and add A, B, C, Sum, and Carry. Run the simulation to compare the register count with the adder outputs. Allow for propagation delay between input edges and output changes.',shot('image77','The current oscilloscope with all five named feeds.'),
'Congratulations on completing the tutorial. Save your circuit so you can experiment with it later.'])
page('Oscope.htm','Oscilloscope',['Choose View > Oscilloscope or press Ctrl+G to show the waveform panel below the canvas. Named To/From links provide the signals available in the feed dropdown. Select a signal and click Add. Run or step the simulation to collect samples.',shot('image77','The docked oscilloscope in the current CedarLogic interface.'),'See <a href="Oscope_Mode.htm">Oscope Mode</a> for the full exercise.'])
page('Print.htm','Print',['To print a circuit, choose File > Export as Image, export a PDF, then open it in a PDF viewer and print it there. The current frontend does not include a direct Print command. See <a href="Printing_Exporting_A_Circuit.htm">Printing/Exporting A Circuit</a>.'])
page('Print_Preview.htm','Print Preview',['Export a PDF using File > Export as Image, then open it in a PDF viewer to preview and print it. See <a href="Printing_Exporting_A_Circuit.htm">Printing/Exporting A Circuit</a>.'])
page('Pause_Simulation.htm','Pause Simulation',['Press F5 or click the Run/Pause toolbar button to pause or resume. The status bar shows Paused when simulation is paused. Press F6 to advance one tick while paused.'])
page('Step_Through_Simulation.htm','Step Through Simulation',['Pause simulation with F5, then press F6 or the Step toolbar button to advance one simulation tick. Repeat to observe clock edges and signal propagation.'])
page('Export_Bitmap.htm','Export as Image',['Choose File > Export as Image to export the complete circuit on the current page. Choose PNG for a raster image, or SVG/PDF for scalable output. Color, black and white, and optional grid lines are supported. Resolution choices apply to raster output; Copy to Clipboard uses screen resolution.',shot('image16','The current image export controls.')])
page('Exit.htm','Exit',['Choose File > Exit or press Ctrl+Q. If the circuit has unsaved edits, save or discard them, or cancel to keep working.'])

commands={
 'New.htm':('New','Press Ctrl+N or choose File > New to create a circuit. Save, discard, or cancel any unsaved edits when prompted.'),
 'Open.htm':('Open','Press Ctrl+O or choose File > Open to open a saved .cdl circuit. Ctrl+Shift+O opens a circuit in a new independent window.'),
 'Save.htm':('Save','Press Ctrl+S or click Save to save the editable .cdl circuit. Use Save As (Ctrl+Shift+S) to choose another filename.'),
 'Save_As.htm':('Save As','Press Ctrl+Shift+S or choose File > Save As to save the circuit under another name.'),
 'Copy.htm':('Copy','Press Ctrl+C or choose Edit > Copy to copy the selected gates and wires to the system clipboard. The copy can be pasted onto another page or into another CedarLogic window.'),
 'Paste.htm':('Paste','Press Ctrl+V or choose Edit > Paste. Move the preview and click to place the copied gates and wires. Escape cancels placement.'),
 'Undo.htm':('Undo','Press Ctrl+Z or choose Edit > Undo to reverse the previous edit.'),
 'Redo.htm':('Redo','Press Ctrl+Shift+Z or Ctrl+Y, or choose Edit > Redo, to reapply an edit that was undone.'),
 'Zoom_In.htm':('Zoom In','Use the toolbar magnifier, + or Ctrl+=, or the mouse wheel to zoom in. The mouse wheel keeps the point beneath the pointer in place.'),
 'Zoom_Out.htm':('Zoom Out','Use the toolbar magnifier, - or Ctrl+-, or the mouse wheel to zoom out. Space or Ctrl+0 fits the complete circuit.')
}
for file,(title,text) in commands.items():page(file,title,[text])


command_icons={
 'New.htm':('new','New'), 'Open.htm':('open','Open'), 'Save.htm':('save','Save'),
 'Copy.htm':('copy','Copy'), 'Paste.htm':('paste','Paste'), 'Undo.htm':('undo','Undo'),
 'Redo.htm':('redo','Redo'), 'Zoom_In.htm':('zoomin','Zoom in'), 'Zoom_Out.htm':('zoomout','Zoom out'),
 'Pause_Simulation.htm':('pause','Pause simulation'), 'Step_Through_Simulation.htm':('step','Simulation step')
}
for file,(name,caption) in command_icons.items():pages[file][1].insert(0,('icon',name,caption))
page('Open_New_Window.htm','Open Circuit in New Window',[
 ('icon','open-circuit','Open circuit in new window'),
 'Choose File > Open in new window or press Ctrl+Shift+O. Select a .cdl file to open it in an independent CedarLogic window. Copy and paste works between windows.'
])
page('Signing_Circuits.htm','Signing Circuits',[
 '1. Open Preferences with Ctrl+, or the settings button. Select Files, enter your name in Sign username, then click Apply or OK.',
 shot('preferences-files','The Files preferences contain Sign username and the autosave interval.'),
 '2. Choose File > Sign circuit. If you have not entered a username yet, CedarLogic opens the Files preferences and asks for one. Apply it, then choose Sign circuit again.',
 '3. Choose This circuit works properly, This circuit does not work properly, or Other. You can edit the status text. Click OK to add your name and the declared status as text labels.',
 shot('sign-circuit','Choose a circuit status before adding your signature labels.'),
 '4. Save the circuit with Ctrl+S. The name and status labels can be moved, edited, deleted, or undone like other text labels.',
 shot('signed-circuit','A circuit with the example author and status labels.')
])
page('Appearance.htm','Appearance and Dark Mode',[
 ('icon','settings','Preferences'),
 'Open Preferences with Ctrl+, or the settings button, and select Appearance.',
 'Under Theme, choose Follow system, Light, or Dark. Follow system tracks the desktop appearance. Click Apply to preview the change or OK to apply it and close Preferences.',
 shot('preferences-appearance','Dark mode selected in the current Appearance preferences.'),
 'Choose one of six accents: Teal, Blue, Purple, Orange, Green, or Rose. Accents color controls, selections, and the overview frame. Circuit symbols, wires, and signal-state colors keep their original meanings.',
 'Appearance choices are remembered for later launches. See <a href="Editor_Preferences.htm">Editor Preferences</a> for gridlines and sidebar names.'
])
page('Editor_Preferences.htm','Editor Preferences',[
 ('icon','settings','Preferences'),
 'Open Preferences with Ctrl+, select Editor, make your changes, then click Apply or OK.',
 shot('preferences-editor','The current Editor preferences.'),
 'Show gridlines controls the canvas grid. Show sidebar part names adds captions beneath library symbols. Show wire connection points controls connection-point display. These choices are also available in the View menu.',
 'Connection radius adjusts proximity connections. Right-click rotates gates controls rotation on the gate body; connected pins still support disconnection.',
 'Help touchpad speed adjusts tutorial scrolling from 1× to 8×. The default is 3×; increase it if your touchpad scrolls too slowly, then click Apply or OK.',
 'Refresh rate (FPS) limits display updates. Step interval (ms) sets the interval between simulation updates. Pause or resume with F5, and single-step with F6 while paused.',
 'Use the middle mouse button to pan, the wheel to zoom, and Escape to cancel a placement or wiring gesture. See <a href="Advanced_Navigation.htm">Advanced Navigation</a>.'
])
page('Autosave_Recovery.htm','Autosave and Recovery',[
 'Open Preferences > Files to choose the Autosave interval in minutes. The default is three minutes; set it to 0 to disable autosave. Click Apply or OK to save the setting.',
 shot('preferences-files','The autosave interval is set in Files preferences.'),
 'Autosave writes separate recovery snapshots of unsaved work. Continue using Ctrl+S to save your named .cdl file.',
 'After an interrupted session, CedarLogic offers an available recovery snapshot on startup. Choose Yes to recover it, inspect the circuit, and save it. Snapshots belonging to a live CedarLogic instance are skipped.',
 'When a circuit is already open for editing elsewhere, CedarLogic uses document locks to protect it. See <a href="Locking_Circuits.htm">Locking Circuit Editing</a>.'
])
page('Locking_Circuits.htm','Locking Circuit Editing',[
 ('icon','locked','Lock circuit editing'),
 'Use the padlock button at the right of the toolbar to lock or unlock circuit editing. This helps protect a circuit from accidental structural changes while you inspect it.',
 'The active padlock indicates that editing is locked. Unlock it before adding, moving, deleting, wiring, pasting, or signing components.',
 'This toolbar control is separate from document locks, which protect files opened in another CedarLogic instance. See <a href="Autosave_Recovery.htm">Autosave and Recovery</a>.'
])

manifest=[]
for file,(title,blocks) in pages.items():
 parts=['<!doctype html>','<html><head><meta charset="utf-8"><title>'+escape(title)+'</title></head><body>','<h1>'+escape(title)+'</h1>']
 for b in blocks:
  if isinstance(b,tuple) and b[0]=='icon':
   _,name,caption=b
   parts.append(f'<p><b>Toolbar icon:</b> <img src="icons/{name}-light.png" width="24" height="24" alt="{escape(caption,quote=True)}"> {escape(caption)}</p>')
  elif isinstance(b,tuple):
   _,name,caption=b; pixels=struct.unpack('>II',(root/'screenshots'/f'{name}.png').read_bytes()[16:24]); width=min(560,pixels[0]);height=round(pixels[1]*width/pixels[0])
   parts.append(f'<p><img src="screenshots/{name}.png" width="{width}" height="{height}" alt="{escape(caption,quote=True)}"></p><p><i>{escape(caption)}</i></p>')
   manifest.append({'page':file,'image':f'screenshots/{name}.png','caption':caption,'pixels':list(pixels)})
  else:parts.append('<p>'+b+'</p>')
 parts.append('</body></html>');(root/file).write_bytes('\n'.join(parts).encode('ascii',errors='xmlcharrefreplace'))
# Unrelated original pages and artwork are preserved verbatim.
(root/'screenshots/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'Updated {len(pages)} pages with {len(manifest)} screenshot references')
