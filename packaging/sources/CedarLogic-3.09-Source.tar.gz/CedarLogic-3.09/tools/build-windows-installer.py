#!/usr/bin/env python3
"""Build a per-user Windows installer from the complete staged Qt runtime."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile


def nsis_path(path):
    return str(path).replace('$', '$$').replace('"', '$\\"')


def installed_path(relative):
    return '$INSTDIR\\' + nsis_path(relative.as_posix().replace('/', '\\'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--payload', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--makensis', default='makensis')
    args = parser.parse_args()
    payload, output = args.payload.resolve(), args.output.resolve()
    source = Path(__file__).resolve().parents[1]
    for name in ['CedarLogic.exe', 'CedarLogic.pdb', 'Qt6Core.dll', 'WinSparkle.dll',
                 'plugins/platforms/qwindows.dll', 'qt.conf',
                 'res/LabelFont.ttf', 'LICENSE-CedarLogic', 'vc_redist.x64.exe']:
        if not (payload / name).is_file():
            parser.error(f'Missing runtime file: {name}')
    if list(payload.glob('test_*.exe')):
        parser.error('Remove test executables from staging before packaging')

    # Delete only shipped files during uninstall. User circuits and files added
    # to runtime subfolders survive; directories are removed only when empty.
    files = sorted(p.relative_to(payload) for p in payload.rglob('*') if p.is_file())
    directories = sorted({parent for file in files for parent in file.parents
                          if parent != Path('.')},
                         key=lambda path: (len(path.parts), str(path)), reverse=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temporary:
        manifest = Path(temporary) / 'uninstall-files.nsh'
        lines = [f'  Delete "{installed_path(file)}"' for file in files]
        lines += [f'  RMDir "{installed_path(directory)}"' for directory in directories]
        manifest.write_text('\n'.join(lines) + '\n')
        subprocess.run([args.makensis, '-V3', f'-DPAYLOAD={payload}',
                        f'-DOUTPUT={output}', f'-DSOURCE={source}',
                        f'-DMANIFEST={manifest}', str(source / 'tools/windows-installer.nsi')],
                       check=True)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_name(output.name + '.sha256').write_text(f'{digest}  {output.name}\n')
    print(output)


if __name__ == '__main__':
    main()
