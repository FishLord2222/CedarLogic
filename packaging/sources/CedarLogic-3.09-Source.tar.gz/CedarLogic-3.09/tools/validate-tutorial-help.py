#!/usr/bin/env python3
"""Check offline topic links, screenshot dimensions, and capture coverage."""
import json
import re
import struct
from html.parser import HTMLParser
from pathlib import Path

root = Path(__file__).resolve().parents[1] / 'res/help'
manifest = json.loads((root / 'screenshots/manifest.json').read_text())
errors = []
references = []

class Page(HTMLParser):
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'img':
            name = attrs.get('src', '')
            if not (root / name).is_file():
                errors.append(f'{self.file}: missing image {name}')
            elif name.startswith('icons/'):
                dark=root/name.replace('-light.png','-dark.png')
                if not dark.is_file():errors.append(f'{self.file}: missing dark icon {dark}')
            elif name.startswith('screenshots/'):
                references.append((self.file.name, name))
                data = (root / name).read_bytes()
                if data[:8] != b'\x89PNG\r\n\x1a\n':
                    errors.append(f'{name}: not a PNG')
                    return
                w, h = struct.unpack('>II', data[16:24])
                shown_w, shown_h = int(attrs['width']), int(attrs['height'])
                if shown_w > 560 or abs(shown_h - h * shown_w / w) > 1:
                    errors.append(f'{self.file}: screenshot aspect ratio or width is incorrect')
                if not attrs.get('alt'):
                    errors.append(f'{self.file}: screenshot needs alternative text')
        elif tag == 'a':
            link = attrs.get('href', '')
            if link and not re.match(r'(?:\w+:|#)', link):
                target = link.split('#')[0]
                if not (root / target).is_file():
                    errors.append(f'{self.file}: broken link {link}')

for file in root.glob('*.htm'):
    parser = Page()
    parser.file = file
    parser.feed(file.read_bytes().decode('cp1252'))
for entry in manifest:
    if (entry['page'], entry['image']) not in references:
        errors.append(f'Unreferenced capture: {entry}')
    path = root / entry['image']
    if list(struct.unpack('>II', path.read_bytes()[16:24])) != entry['pixels']:
        errors.append(f'Stale capture dimensions: {path}')
for target in re.findall(r'<param name="Local" value="([^"]+)"', (root / 'KLS_Logic.hhc').read_text()):
    if not (root / target).is_file():
        errors.append(f'Missing contents topic: {target}')
# Application captures in the exercises must all use the current frontend.
modern_pages = {entry['page'] for entry in manifest}
for file in modern_pages:
    text = (root / file).read_bytes().decode('cp1252')
    for src in re.findall(r'<img\b[^>]*src="([^"]+)"', text):
        if not src.startswith(('screenshots/', 'icons/')):
            errors.append(f'{file}: legacy screenshot still referenced: {src}')
if errors:
    raise SystemExit('\n'.join(errors))
print(f'PASS: {len(list(root.glob("*.htm")))} pages, {len(references)} modern image references, '
      f'{len(set(image for _, image in references))} distinct screenshots; all links and dimensions valid.')
