<!-- footer -->

---

<details>
<summary>Which download do I want?</summary>

| Platform | File |
| --- | --- |
| Windows | `CedarLogic-3.08-Windows-x64.zip` (portable) |
| Linux | `CedarLogic-3.08-Linux-x64.tar.gz` |
| Web / embedding | `CedarLogic-__VERSION__-wasm.tar.gz`, also on [npm](https://www.npmjs.com/package/@cedarville/cedarlogic-engine) |

Desktop downloads bundle Qt. Linux and Windows x64 are the current validated platforms.

</details>

<details>
<summary>Verifying your download</summary>

Download [`checksums.txt`](https://github.com/taciturnaxolotl/CedarLogic/releases/download/__TAG__/checksums.txt) next to the file you grabbed, then:

```bash
sha256sum --ignore-missing -c checksums.txt
```

`OK` means the file is intact.

</details>
