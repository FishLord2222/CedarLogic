# CedarLogic 3.06 → 3.07 audit

Historical note: superseded 3.07 backups mentioned below were removed on
2026-10-11 during final release preparation. The final 3.07 source and downloads,
3.06 releases and this audit are retained.

Compared the backed-up 3.06 frontend sources with the current Qt frontend. This is
an implementation comparison backed by the checks below; it is not a guarantee
that every possible circuit and desktop configuration is bug-free.

## Reported circuit failure

The supplied `Shift Registers-handout safe.cdl` is retained unchanged. The regression
fixture opens its first page, settles the circuit, sets the shift input, pulses the
clock, clears the input and pulses again. Flip-flop 49 must change from 1 to 0 and
flip-flop 59 must become 1 after the second pulse. Both Linux and Windows-under-Wine
editor tests pass this sequence.

The Qt frontend previously represented a clock pulse as a document edit. A repeated
pulse with the same value produced no document difference and was never delivered
to the simulator. Input events now use an explicit command queue. No simulator gate
implementation was rewritten. The worker retains complete runtime parameter
snapshots so register/RAM updates are not lost when UI generations change. Input
wakeups no longer introduce an extra simulation step or postpone its deadline.

Wire states are cached for the entire circuit and reapplied during a paused page
change. A rendered-image regression verifies that switching away and back preserves
the same displayed wire states. The original renderer, router, gate definitions and
signal palette remain in use.

## Preferences comparison

Legacy source: `src/gui/SettingsDialog.cpp`, `include/gui/Settings.h`.
Current: `qt/Appearance.cpp`, `qt/qml/Preferences.qml`.

| 3.06 setting | Current location / range |
| --- | --- |
| Wire connection visibility | Editor; also View menu |
| Wire connection radius | Editor, 0.05–1.00 |
| Grid visibility | Editor; also View menu |
| Right-click rotates rather than pans | Editor |
| Dark mode | Appearance: Follow system, Light, Dark |
| Refresh rate | Editor, original 10–1000 FPS range |
| Autosave | Files, original 0–60 minutes; 0 disables |
| Signature name | Files; required when signing |
| Last open directory | Persisted automatically |
| Simulation interval | Editor and toolbar |
| Window and sidebar geometry | Persisted automatically |

The theme and accent choices are additions. Circuit wire colors are independent of
these choices. All legacy parameter fields are generated from the original library
definitions, including numeric ranges, checkboxes, text and memory file actions.
Invalid numeric values keep the properties dialog open with an error.

## Menus and workflows

Legacy comparison sources (preserved in the pre-cleanup source backup): `src/gui/MainFrame.cpp`, `src/gui/GUICanvas.cpp`,
`src/gui/command/`, `src/gui/Oscope*.cpp`, `src/gui/RAM*.cpp` and original help.
Qt implementations: `qt/qml/Main.qml`, `qt/Keyboard.cpp`, `qt/Canvas.cpp`,
`qt/Editor.cpp`, `qt/Editor_Desktop.cpp`, `qt/ClipboardFormat.h`, `qt/LegacyExport.h`.

| Feature | Current implementation |
| --- | --- |
| New/open/save/save as and save-cancel protection | File menu, native picker, atomic saves |
| Open in another window | File menu / Ctrl+Shift+O; independent process |
| New/close page, original 42-page limit | File menu / Ctrl+T/W and page strip |
| Export image | Preview, grid, color/B&W, quality, clipboard, PNG/SVG/PDF |
| Export legacy V2/V1 | File menu; V1 warns before reducing bus wires |
| Print | Removed at the user’s request |
| Sign circuit | Required username redirects to Files; original proper-working wording |
| Exit | File menu / Ctrl+Q; save protection |
| Undo/redo/cut/copy/paste | Menus and shortcuts; native and 3.06 clipboard formats |
| Interactive paste | Cursor-following group; click places, Escape cancels |
| TO/FROM paste numbering and conversion | Numbered links increment; Shift preserves name; T/F conversion |
| Selection | Click, Shift/Ctrl additive selection, region and select-all |
| Gate placement | Half-unit snap, clockwise rotation and proximity connection |
| Wire connections | Pin click/drag, branch and merge; bus-width checks |
| Disconnection/deletion | Right-click pin disconnects, right-click wire removes net |
| Gate/group/segment movement | Original wire router; internal selected routes translate together |
| Gate rotation | Clockwise; original protection for connected gates |
| Zoom/fit/pan and overview | View menu, arrows, wheel and original shortcuts |
| Page view state | Center and zoom remembered during page switching |
| Sidebar | Search, collapse, resize and persisted layout |
| Properties and RAM contents | Explicit Edit/Ctrl+I, original parameter definitions, hex RAM editor |
| RAM/ROM files | Original simulator READ_FILE/WRITE_FILE commands, including repeated loads |
| Run/pause/step and input widgets | Toolbar/shortcuts, original simulator and input symbols |
| Oscilloscope | Add/remove feeds, pause/resume, reset, clipboard image, legacy .cdo layouts |
| Grid / connection point display | View menu and Preferences |
| Help contents, keyboard reference, download link, changelog | Help menu; original categorized .hhc contents and chapter order |
| A-key quick add and fuzzy search | Original ordered-letter scorer, keyboard navigation and gate preview |
| File ownership locks / recovery | Legacy-compatible locks and separate recovery snapshots |

Prior requested behavior remains: no Simulation menu, one gate per palette choice,
properties through the explicit command or double-click on editable components, and About opens the embedded tutorial. The
original About reference page remains accessible through the help chapter list.

## Current simulation, rendering and reporting

Simulation starts automatically as in 3.06. Open/new preserve Run/Pause. Intentional
Pause freezes time; Step advances one tick. A live XOR regression covers all four
input combinations without manual settling steps. The A-key menu previews original
symbols at the snapped cursor, with rotation and Escape cancellation, without
changing the document or simulator.

Alternate circuit-color settings and recoloring are removed. Old saved choices are
discarded; UI accents leave the circuit, palette previews, placement previews and
image exports at their original colors. Green denotes non-driven (HI_Z); blue
remains unknown. The oscilloscope is a compact bottom panel with a draggable divider.

The Qt app captures native crash traces and offers a next-launch Copy/Open issue/
Dismiss dialog. Reports are not uploaded automatically. Windows packages include
matching PDB symbols. The legacy Windows crash-time dialog is replaced by reporting
on the next healthy launch.

## Verification and limits

Eight Linux suites cover the native picker, actual QML keyboard/layout, UI smoke,
editor workflows, frontend invariants, native crash reporting, original logic and
circuit file formats. Editor tests cover the handout, repeated pulses, original
wire state across page changes, structural edits, live XOR, run/pause state and
single-step behavior. Rendering checks verify that all six UI accents and retired
saved choices leave circuit colors unchanged. Windows UI, editor, frontend and
crash tests run under Wine; native Windows hardware is unavailable.

Gate definitions and original bodies remain unchanged. Decoder output polarity
adds inversion bubbles within the existing pin leads. The current source hashes are:

- `res/cl_gatedefs.xml`: `aba66052dfe4ba13e99fe649963f18b22ebb0782eea65ae55a28840afe2eb830`
- `include/gui/render/RenderStyle.h`: `8dd37303f3b0025fd55b31e053b17cefa29dd5f605ac552443b9a0b230262ed9`

Large-circuit performance and every desktop configuration are not exhaustively
verified. Legacy rendering/router diagnostic CLI options remain in the archived
archived 3.06 frontend. The Qt CLI supports opening circuits, theme override, screenshots
and version/help. Releases expose one build per version; superseded downloads are
retained in `backups/before-version-only-releases/downloads/`.

Connection preview rendering matches the original canvas: a two-point solid green
line anchored at the source hotspot and ending at the mouse, drawn as an overlay.
It follows drag and hover events without changing the document before connection.
Rendered UI checks cover straightness, continuity, zoom anchoring, Escape, and
both click and drag-release connections in both themes. Final routing is unchanged.

Original red hover indicators are restored: a 3-pixel-radius pin outline and wire
segment X, using the legacy hotspot and wire collision checks. Indicators stay
the same screen size through zoom, follow connection targets, and clear after
deleting the hovered object. They are excluded from exports and the overview.

Wire connection drags finish on release even without a valid target, matching the
original drag lifecycle. Preview painting stays inside the canvas. Click-to-connect
remains supported, while interrupted held drags clear on mouse-grab loss.

The original Open Circuit in New Window toolbar action is restored between Open
and Save, with a dedicated overlapping-window icon. Its Qt backend matches the
original separate-process workflow. Fit circuit remains in the View menu and
keyboard shortcuts; it no longer occupies the additional-open toolbar button.

RAM/ROM dialogs match original RamPopupDialog behavior: a 16-column grid with
hexadecimal addresses and values, Show Decimal, read/write highlights, and Open,
Save and Close. Double-click routes memory gates to this custom dialog. Original
CDM/Intel-HEX readers and CDM writer are retained; extensions are normalized for
case and unsupported file types are rejected in Qt. Memory dialogs bind to a
gate ID, refresh on simulation/edit/undo, and close when the component disappears
or the document is replaced. Edit omits RAM Contents and Gate Properties.

Decoders offer an Output polarity dropdown on double-click: Active high sends
the normal decoded output; Active low inverts every output. Standard 2x4, 3x8
and 4x16 decoders default to active high, while the original 3x8 decoder chip
retains its active-low default. The setting persists in circuit files, supports
undo/redo, and updates connected outputs through the existing simulation event
path. Enable inputs retain their original behavior; disabled outputs are low
for active high and high for active low. Pin positions and signal colors are unchanged. Active-low outputs show inversion
bubbles; active-high outputs retain their original straight leads.
The pre-change source and 3.07 downloads are in `backups/before-decoder-polarity/`.

New wire connections and branches use the original guiWire::addConnection and
calcShape/mergeSegments path, replacing Qt's manually assembled segments. This
retains original pin orientation, half-unit trunk placement, nearest-segment
branch routing and trimmed endpoints. A release pixel identifies the target net
and is not stored as an unsnapped permanent junction. Both the start and update
of wire dragging use the original half-unit floor(x/grid+0.5) snap, removing the
sub-grid click offset. Segment IDs remain unique after normalization. Simulation
states, gate drawings and signal colors are unchanged. Existing files retain
their authored routes on opening. The pre-change source and downloads are in
`backups/before-original-wire-routing/`.

Deleting connected components now invokes original guiWire::removeConnection
while their model objects still exist, rather than merely erasing pin references.
Surviving fanouts collapse immediately and retain their wire identities. Nets
with fewer than two remaining connections are removed. Structural disconnection
updates pending wire/junction state through the existing core state calculation
while paused, without consuming timed events or advancing the simulation clock.
Signal meanings remain green for non-driven and blue for unknown. Undo/redo and
reconnection preserve the route and driver behavior. Prior source and 3.07
downloads are saved in `backups/before-wire-removal/`.

Sidebar part names are hidden by default and can be enabled beneath the original symbols. View > Show
sidebar part names and Preferences > Editor toggle the same saved setting. Named
tiles adapt their column count to the sidebar width and wrap captions to two
lines with the full name in the existing tooltip. Hiding names restores the
compact four-column palette. Search, selection and dragging continue to use the
original part identity. The previous source and release downloads are backed up
in `backups/before-sidebar-names/`.

The corner overview now fits the full circuit and the main canvas viewport
together, matching the original navigation behavior. It expands when the main
view pans or zooms beyond the circuit and keeps the aspect ratio with a five-unit
world margin. Its bitmap, viewport frame and mouse navigation share one transform
and refresh on camera/size changes. Left-click or hold and drag to recenter the
main canvas at its current zoom; keyboard focus returns to the canvas. Non-left
clicks do not navigate or edit. Previous source and downloads are retained in
`backups/before-overview-sync/`.
