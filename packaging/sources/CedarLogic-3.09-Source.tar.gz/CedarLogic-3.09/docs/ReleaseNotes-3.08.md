# CedarLogic 3.08

CedarLogic 3.08 brings simulator, wire-routing, parser and recovery stability
fixes to the existing Qt 6 frontend on Linux and Windows.

## Fixes

- Restore blue connection rings when a wire or moved component is over a valid
  pin or wire target. Indicators respect bus widths and clear after cancellation,
  locking, page changes and leaving the canvas.
- Prevent manually routed wires from folding into a switch after the connected
  switch is moved. Preserve the corrected route through cancellation, undo/redo
  and save/reopen in every component orientation.
- Preserve complete internal wire routes when dragging a box-selected group
  of gates, matching the original selection movement behavior. Wires connected
  to gates outside the selection continue to stretch to their fixed endpoints.
- Show only the snapped placement preview when dragging a sidebar component
  over the canvas; restore the thumbnail when dragging back outside.

- Safely ignore queued updates for deleted gates and wires; remove stale
  connections during deletion and prevent damaged-wire deletion from hanging.
- Correct junction reference counts, remove stale junction links, and validate
  bus-pin bounds.
- Harden segment lookup, zero-length segment cleanup, dragging, and collision
  bounds while retaining exact undo/redo and existing signal colors.
- Normalize library XML line endings, terminate cleanly on truncated input,
  and remove the library parser's dangling-pointer lifetime.
- Reject duplicate wire IDs before replacing a document. Keep the first wire
  claiming a pin and warn about conflicting connections removed during loading.
- Validate recovery snapshots and preserve the original until a successful save
  or explicit discard, including after failed autosaves and repeated crashes.

## Local crash diagnostics

Crash diagnostics stay local and can be copied. The upstream GitHub issue button
is removed. No Sentry SDK, reporting address, or automatic crash upload is included.
POSIX handlers write a minimal diagnostic and leave core dumps to the OS.

## Downloads

- Linux: `cedarlogic-3.08-x86_64.rpm`, `CedarLogic-3.08-x86_64.AppImage`.
- Windows x64: `CedarLogic-3.08-Windows-Setup.exe`, `CedarLogic-3.08-Windows-x64.zip`.
- Source: `CedarLogic-3.08-Source.tar.gz`.

Each download has a matching SHA-256 checksum. Windows downloads include the
matching PDB and Microsoft Visual C++ x64 runtime installer. Existing 3.06 and
3.07 downloads are preserved. See `Stability-2026-10-15.md` for backport details.

## Validation

Clean Linux and Windows builds passed 17 Linux regression suites and 15 Windows
regression executables under Wine. The simulator also passed ASan/UBSan checks.
Installer checks cover fresh/repeated installation, upgrades from 3.06 and 3.07,
user-file retention and circuit associations. Extracted Linux packages load and
render existing circuits. Native Windows hardware was not available for testing.
