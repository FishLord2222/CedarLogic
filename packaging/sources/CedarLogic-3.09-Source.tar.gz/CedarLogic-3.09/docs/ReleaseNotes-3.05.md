# CedarLogic for Linux 3.05

This is a draft for the next GitHub release. It includes changes present in the
local Linux source that are not described in the 3.04 notes supplied by the
maintainer. The T/F shortcuts, circuit signing, and missing image-resolution
option belong to 3.04.

- Removed the Windows WinSparkle updater and dependency. The Help menu now opens
  this fork's GitHub releases page for manual downloads.
- Added an offline, scrollable changelog to Help and updated About to 3.05.
- Added a dark theme for the circuit, palette, gates, wires, grid, minimap and
  image exports.
- Improved image export further with content-fitted sizes, a preview and
  updated help.
- Fixed crashes and stale state when replacing circuits or editing wires.
- Fixed gate and wire render-cache updates, including TO/FROM labels.
- Fixed dark-mode register digits and junctions to start red and green,
  respectively; cyan is reserved for short circuits.
- Sized View and Help menus from their themed entries each time they open,
  preventing clipping and excess empty space. Kept the sidebar section
  selector on screen. Its label and down arrow align to the left;
  four gate columns have tight, even spacing and align to the left. The
  selector ends flush with the fourth gate column, and the four thumbnails
  expand to fill the sidebar width while keeping their artwork inside. Added
  a top inset for the first gate row and pointer-following dropdown highlights.
  Sized the section dropdown to its native rows without an empty tail,
  and matched its width to the selector button.
- Fixed parsing and clipboard edge cases in the local source.

The AppImage and Fedora RPM have been rebuilt from this source. The AppImage
still targets Fedora 44 and similarly current distributions; an older glibc
build environment is needed for broader compatibility.
