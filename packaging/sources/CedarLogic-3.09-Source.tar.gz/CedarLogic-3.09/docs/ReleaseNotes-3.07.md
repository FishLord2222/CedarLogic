# CedarLogic 3.07

CedarLogic 3.07 replaces the wxWidgets desktop frontend with Qt 6 on Linux and
Windows. It retains the original simulator, gate definitions, circuit symbols,
signal colors, circuit-file compatibility and wire-routing engine.

## New features

- **Qt 6 frontend:** Replaced wxWidgets completely on Linux and Windows,
  including its active build dependencies.
- **Modern interface:** Added a compact, rounded layout with themed dialogs
  and grouped Preferences.
- **Sidebar search and part names:** Added fuzzy search across gate categories
  and optional names beneath symbols. Names default to off, and the selected
  setting persists across launches.
- **Themes and accent colors:** Added six UI accent choices and system, light
  and dark appearance options.
- **Decoder output polarity:** Added saved active-high/active-low settings in
  double-click properties, with inversion circles on active-low outputs.
- **Crash reports:** Added next-launch reports with copy/report actions and
  matching Windows debug symbols. Reports are not uploaded automatically.
- **Faster sidebar:** Added cached thumbnails, drag previews loaded only while
  dragging, and fewer thumbnail redraws during resizing.
- **Editor and simulation optimizations:** Added indexed gate lookups and wire
  capture, streamlined oscilloscope signal discovery, reusable placement previews,
  and fewer simulation data copies. The affected routines are easier to read.
- **Release downloads:** Provided version-only Linux RPM/AppImage, Windows x64
  installer/portable ZIP and source downloads, with AppData metadata and SHA-256 checksums.

## Bug fixes

These fixes address issues inherited from 3.06:

- Corrected rotated TO/FROM labels for decimal, negative and wrapped angles.
- Corrected memory-file extension parsing, including uppercase .CDM files.
- Refresh disconnected wire states while paused without advancing the clock.

Fixes for regressions introduced during the 3.07 migration are excluded from this
changelog. Original circuit drawings and signal colors are preserved.

## Downloads

| Platform | File |
| --- | --- |
| Linux — Fedora RPM | `cedarlogic-3.07-x86_64.rpm` |
| Linux — portable AppImage | `CedarLogic-3.07-x86_64.AppImage` |
| Windows — x64 installer | `CedarLogic-3.07-Windows-Setup.exe` |
| Windows — portable x64 ZIP | `CedarLogic-3.07-Windows-x64.zip` |
| Source | `CedarLogic-3.07-Source.tar.gz` |

Each file has a matching `.sha256` file. Linux packages include validated AppData
metadata and bundled Qt libraries. The Linux file picker uses the desktop portal.
Install the RPM with `sudo dnf install ./cedarlogic-3.07-x86_64.rpm`.

On Windows, run `CedarLogic-3.07-Windows-Setup.exe` to install for your account,
with Start menu shortcuts, an optional desktop shortcut and optional `.cdl` file
association. Setup includes the Microsoft Visual C++ x64 runtime; installing or
updating this Microsoft component may request administrator permission.

For a portable copy, extract the ZIP and launch `CedarLogic.exe`. Run the bundled
Microsoft runtime installer if needed. Keep `CedarLogic.pdb` beside the executable
for crash-report symbolization.

Public download filenames use only 3.07. The RPM's required internal release field
allows updates from earlier installed 3.07 packages. One final download set remains
for 3.07; 3.06 downloads are preserved. Superseded 3.07 backups were removed during
release preparation.

## Validation

Linux regression suites and Windows checks under Wine cover editing, simulation,
file formats, rendering, keyboard/menu behavior, sidebar settings and crash reports.
Native Windows hardware and every desktop configuration have not been tested.
