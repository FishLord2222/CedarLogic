# CedarLogic 3.09 wire hotfix

This local hotfix keeps the 3.09 interface and repairs the shared wire geometry
and gesture issues also fixed in 4.00 preview 3. The original 3.09 baseline
collapsed rotated junction routes in the regression test before these fixes.

- Use exact quarter-turn pin coordinates and exact grid offsets for rerouting.
- Cancel interrupted drags and discard stale gestures after model rebuilds.
- Recover saved dot-only routes between distinct saved pins, with a review notice.
- Fit large circuits fully on screen.
- Cover ordinary gates, branches, junctions, long spans and repeated mode changes.

The RPM is internally **3.09-7.fc44**. Downloads are under `Linux/`.
The original local release files and published GitHub release are preserved.
Source files are under `Source/`. Install the local RPM to test this hotfix.

All 19 Linux suites pass. Stress coverage includes 1,200 ordinary gate/branch
reroutes plus 1,280 junction reroutes and 440 combined gate moves. Rendering
checks cover 1,344 light/dark switches and 500-unit wire spans.
