# CedarLogic 3.09

CedarLogic 3.09 refreshes the tutorial for the current Qt interface and fixes several editing and scrolling issues.

## Improvements and fixes

- Replace the old Windows XP tutorial screenshots with 76 current Qt captures and update 41 help pages.
- Add help for circuit signing, appearance, editor preferences, autosave/recovery, editing locks and opening another window.
- Restore the original faith-page artwork, consistent text colors and toolbar icons in command help.
- Improve the Final Project diagram and preserve screenshot proportions in smaller windows.
- Improve mouse-wheel and touchpad scrolling in help. Adjust **Help touchpad speed** under **Preferences → Editor**.
- Fix copied TO/FROM components showing the last edited name in their properties dialog.
- Avoid repeated tutorial file reads while resizing or changing appearance.
- Include the installer build tools in the maintained source archive.

## Downloads and installation

| Platform | Download |
| --- | --- |
| Fedora / Linux RPM | `cedarlogic-3.09-x86_64.rpm` |
| Linux portable | `CedarLogic-3.09-x86_64.AppImage` |
| Windows installer | `CedarLogic-3.09-Windows-Setup.exe` |
| Windows portable | `CedarLogic-3.09-Windows-x64.zip` |
| Maintained Qt desktop source | `CedarLogic-3.09-Source.tar.gz` |

On Fedora, install the RPM with `sudo dnf install ./cedarlogic-3.09-x86_64.rpm`. For the AppImage, make it executable and launch it. On Windows, run Setup, or extract the portable ZIP and follow its README.

SHA-256 checksums are provided alongside the downloads and in `SHA256SUMS`.

## Updates

Existing updater-enabled installations can receive 3.09 through the [signed Fedora/DNF repository](https://fishlord2222.github.io/CedarLogic/) and Windows startup update checks. Windows updates remain optional and allow saving or cancelling before installation.

The RPM is internally 3.09-6; the Windows installer is 3.0.9.1. The complete maintained desktop source is the named source archive above, following the previous releases.

Thanks to the CedarLogic contributors and [Kieran / taciturnaxolotl](https://github.com/taciturnaxolotl) for the upstream work on which this release builds.

## Validation

All 17 Linux test suites and 15 Windows regression executables passed. Windows tests ran under Wine; native Windows installation testing remains recommended.
