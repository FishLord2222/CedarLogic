# CedarLogic 3.06

- Added a resizable, collapsible sidebar on Linux and Windows. Drag the divider
  to resize; use the first toolbar button, View > Show Sidebar or Ctrl+B to
  collapse and restore. Width and visibility are saved between launches.
- Kept four gate columns as tiles grow or shrink, retained sidebar contents
  when hidden, and kept the circuit view centred during layout changes.
- Undetermined wires use the same blue in dark and light mode.
- The sidebar section selector has a downward chevron aligned to the right.
- Starting a new circuit or opening a copy releases the previous file's open
  marker. Reopening the current file does not warn about another editor.
- File > Open in New Window and its adjacent toolbar icon open a selected circuit
  in a separate process. The shortcut is Ctrl+Shift+O.
- Canceling Save while replacing a circuit keeps the current project open.

Windows 3.06 now includes these wire-color, sidebar and document fixes, plus
native Windows dark-mode switching and refreshed toolbar icons.
