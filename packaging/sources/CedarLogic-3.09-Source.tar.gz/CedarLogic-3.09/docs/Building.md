# Building CedarLogic 3.08

Qt 6.8+ is the sole desktop frontend. Linux and Windows x64 are the validated
platforms. The retired frontend is available only in previous-version archives
and workspace backups; there is no alternate frontend build flag.

See [the Qt build guide](../qt/README.md) for SDK modules, matching Skia builds,
configure commands, executable locations and tests. Use Visual Studio 2022 x64
or a compatible Windows toolchain; Linux uses GCC/Clang and CMake 3.21+.

For a development run, launch `build-qt/qt/CedarLogic`. Resources are copied
beside the executable automatically. Pass `--theme light` or `--theme dark`
to test an appearance override without changing the saved theme preference.

`ctest --test-dir build-qt --output-on-failure` covers desktop behavior, circuit
files, simulation, wire routing, collisions, command serialization and colors.

## Windows startup updater

Before configuring a Windows desktop build, run `python tools/fetch-winsparkle.py`
and set `WINSPARKLE_ROOT` to the printed SDK directory. The pinned official
WinSparkle 0.9.4 x64 library is linked into the app and its DLL must be deployed
next to CedarLogic.exe. Include its COPYING, COPYING.expat and AUTHORS files
in licenses/WinSparkle. The public update key is in qt/WindowsUpdateKey.h;
never include the private signing key in a build or source archive.
