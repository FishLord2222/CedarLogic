# CedarLogic 3.09

This release refreshes the Qt tutorial, improves help scrolling and fixes stale TO/FROM names in gate properties. It retains the simulator, wire, parser and recovery fixes from 3.08. Crash diagnostics stay local.

See [3.09 release notes](docs/ReleaseNotes-3.09.md), [3.08 release notes](docs/ReleaseNotes-3.08.md) and [building instructions](docs/Building.md). The desktop frontend uses Qt 6.8.3.

# Summary

CedarLogic is a digital logic simulator made for university classroom instruction. It includes all the basic gates, buses, JK and D flip flops, muxes, decoders, and a [Z80 micro-processor](https://en.wikipedia.org/wiki/Zilog_Z80). At [Cedarville University](https://www.cedarville.edu/) it has been used by Computer Architecture 1 students to build and simulate a full [mano-machine](https://en.wikipedia.org/wiki/Mano_machine). 

## Contributing

All improvements, especially to stability, are welcome. Please see [Contributing](./docs/Contributing.md) for more.

## Building

To build the source code yourself, [clone the repo](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository)
and read the [Building](./docs/Building.md) instructions.

Building doc also includes a few notes for development.

## File format

[CDL-Format](./docs/CDL-Format.md) defines the specification for the `.cdl` file
