# Linux-hosted MSVC ABI build using LLVM and an xwin SDK (x64, dynamic CRT for Qt).
# Configure with -DXWIN_ROOT=<xwin splat directory>.
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR AMD64)
set(CMAKE_TRY_COMPILE_CONFIGURATION Release)
set(XWIN_ROOT "$ENV{XWIN_ROOT}" CACHE PATH "xwin SDK/CRT root")
if(NOT EXISTS "${XWIN_ROOT}/crt/include/vcruntime.h")
    message(FATAL_ERROR "Set XWIN_ROOT to an xwin SDK containing crt/ and sdk/.")
endif()
set(CMAKE_C_COMPILER clang-cl-19)
set(CMAKE_CXX_COMPILER clang-cl-19)
set(CMAKE_C_COMPILER_TARGET x86_64-pc-windows-msvc)
set(CMAKE_CXX_COMPILER_TARGET x86_64-pc-windows-msvc)
set(CMAKE_LINKER lld-link-19)
set(CMAKE_AR llvm-lib-19)
set(CMAKE_RC_COMPILER llvm-rc-19)
set(CMAKE_MT llvm-mt-19)
set(CMAKE_RC_FLAGS_INIT "/I ${XWIN_ROOT}/sdk/include/um /I ${XWIN_ROOT}/sdk/include/shared /I ${XWIN_ROOT}/sdk/include/ucrt /I ${XWIN_ROOT}/crt/include")
set(CMAKE_C_STANDARD_INCLUDE_DIRECTORIES
    "${XWIN_ROOT}/crt/include"
    "${XWIN_ROOT}/sdk/include/ucrt"
    "${XWIN_ROOT}/sdk/include/shared"
    "${XWIN_ROOT}/sdk/include/um"
    "${XWIN_ROOT}/sdk/include/winrt")
set(CMAKE_CXX_STANDARD_INCLUDE_DIRECTORIES ${CMAKE_C_STANDARD_INCLUDE_DIRECTORIES})
set(_windows_libs "/libpath:${XWIN_ROOT}/crt/lib/x86_64 /libpath:${XWIN_ROOT}/sdk/lib/ucrt/x86_64 /libpath:${XWIN_ROOT}/sdk/lib/um/x86_64")
set(CMAKE_EXE_LINKER_FLAGS_INIT "${_windows_libs}")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "${_windows_libs}")
set(CMAKE_TRY_COMPILE_PLATFORM_VARIABLES XWIN_ROOT)
# Match native Visual Studio's default C++14 mode; legacy headers use `byte`.
set(CMAKE_CXX_FLAGS_INIT "/std:c++17")
set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreadedDLL)
