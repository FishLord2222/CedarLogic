#include "Editor.h"
#include "DesktopDialogs.h"
#include "Appearance.h"
#include "LegacyExport.h"
#include "Settings.h"
#include "render/SkiaProbe.h"
#include "render/RenderStyle.h"
#include <QApplication>
#include <QCheckBox>
#include <QClipboard>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QLabel>
#include <QLineF>
#include <QMessageBox>
#include <QPainter>
#include <QProcess>
#include <QPushButton>
#include <QSaveFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QWindow>
#include <cmath>

void Editor::openNewWindow() {
  auto path=QFileDialog::getOpenFileName(nullptr,"Open circuit in a new window",appearance->editorSettings()["lastDir"].toString(),"CedarLogic circuits (*.cdl);;All files (*)");
  if(path.isEmpty())return;
  auto executable=qEnvironmentVariable("APPIMAGE");
  if(executable.isEmpty() || !QFileInfo::exists(executable))executable=QCoreApplication::applicationFilePath();
  if(!QProcess::startDetached(executable,{path}))setStatus("Could not start another CedarLogic window.");
}
void Editor::exportLegacyDialog(int version) {
  if(version!=1 && version!=2)return;
  if(version==1) {
    bool buses=false;for(const auto &p:file.pages)for(const auto &w:p.wires)if(w.ids.size()>1)buses=true;
    if(buses && DesktopDialogs::warning(*appearance, nullptr,"V1 export","V1 cannot represent bus wires. Export a copy using only the first bit of each bus?",QMessageBox::Yes|QMessageBox::Cancel,QMessageBox::Cancel)!=QMessageBox::Yes)return;
  }
  auto path=QFileDialog::getSaveFileName(nullptr,QString("Export as V%1").arg(version),{},"CedarLogic circuits (*.cdl)");if(path.isEmpty())return;
  QSaveFile out(path);auto text=QByteArray::fromStdString(legacyExport(runtimeFile(),version,pageIndex));
  if(!out.open(QIODevice::WriteOnly) || out.write(text)!=text.size() || !out.commit())setStatus("Legacy export failed: "+out.errorString());else setStatus(QString("Exported a V%1 copy").arg(version));
}
QImage Editor::circuitImage(int longest,bool color,bool grid) {
  auto b=bounds();double scale=(longest-60)/std::max(b.width(),b.height());
  int w=std::max(100,qRound(b.width()*scale+60)),h=std::max(100,qRound(b.height()*scale+60));
  auto style=cl::render::RenderStyle::print();style.colorOutput=color;style.showLiveState=color;style.showGrid=grid;
  std::vector<unsigned char> pixels(static_cast<size_t>(w)*h*3);
  bool ok=cl::render::skiaRenderToRGB(w,h,[&](auto &scene){
    cl::render::Transform t;t.a=scale;t.d=-scale;t.e=w/2-b.center().x()*scale;t.f=h/2+b.center().y()*scale;scene.setViewport(t);
    if(grid) {
      std::vector<cl::render::Point> points;
      double spacing=std::max(1.0,std::ceil(13.0/scale));
      for(double x=std::floor(b.left()/spacing)*spacing;x<=b.right();x+=spacing){points.push_back({float(x),float(b.top())});points.push_back({float(x),float(b.bottom())});}
      for(double y=std::floor(b.top()/spacing)*spacing;y<=b.bottom();y+=spacing){points.push_back({float(b.left()),float(y)});points.push_back({float(b.right()),float(y)});}
      scene.lines(points,cl::render::Stroke(style.gridColor()));
    }
    draw(scene,style);
  },pixels.data(),style.background(),std::max(1.0,longest/1920.0));
  return ok?QImage(pixels.data(),w,h,w*3,QImage::Format_RGB888).copy():QImage();
}
void Editor::exportDialog() {
  // A Qt Quick main window cannot be a QWidget parent. Give the native utility
  // dialog an explicit transient owner so desktops float it above this window.
  auto owner = QGuiApplication::focusWindow();
  QDialog dialog;
  dialog.setObjectName("imageExportDialog");
  dialog.setWindowTitle("Export as Image");
  dialog.setWindowFlags(Qt::Tool | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
  dialog.setWindowModality(Qt::WindowModal);
  dialog.winId();
  if (owner) dialog.windowHandle()->setTransientParent(owner);
  auto palette = dialog.palette();
  palette.setColor(QPalette::Window, appearance->panel());
  palette.setColor(QPalette::WindowText, appearance->text());
  palette.setColor(QPalette::Base, appearance->background());
  palette.setColor(QPalette::Text, appearance->text());
  palette.setColor(QPalette::Button, appearance->raised());
  palette.setColor(QPalette::ButtonText, appearance->text());
  palette.setColor(QPalette::Highlight, appearance->accent());
  dialog.setPalette(palette);
  auto layout=new QVBoxLayout(&dialog);
  auto preview=new QLabel;preview->setAlignment(Qt::AlignCenter);layout->addWidget(preview);
  auto grid=new QCheckBox("Include grid lines");layout->addWidget(grid);
  auto color=new QComboBox;color->addItems({"Color","Black and White"});layout->addWidget(color);
  auto quality=new QComboBox;quality->addItems({"Screen — 1920 pixels","High resolution — 3600 pixels","Maximum — 6000 pixels"});quality->setCurrentIndex(1);layout->addWidget(quality);
  auto update=[&]{preview->setPixmap(QPixmap::fromImage(circuitImage(560,color->currentIndex()==0,grid->isChecked())).scaled(560,220,Qt::KeepAspectRatio,Qt::SmoothTransformation));};
  connect(grid,&QCheckBox::toggled,&dialog,update);connect(color,&QComboBox::currentIndexChanged,&dialog,update);update();
  auto buttons=new QDialogButtonBox(QDialogButtonBox::Cancel);auto copy=buttons->addButton("Copy to Clipboard",QDialogButtonBox::ActionRole);auto save=buttons->addButton("Export to File…",QDialogButtonBox::AcceptRole);layout->addWidget(buttons);
  connect(buttons,&QDialogButtonBox::rejected,&dialog,&QDialog::reject);
  connect(copy,&QPushButton::clicked,&dialog,[&]{QApplication::clipboard()->setImage(circuitImage(1920,color->currentIndex()==0,grid->isChecked()));setStatus("Copied circuit image");});
  connect(save,&QPushButton::clicked,&dialog,[&]{
    auto path=QFileDialog::getSaveFileName(&dialog,"Export circuit",{},"PNG image (*.png);;SVG drawing (*.svg);;PDF document (*.pdf)");if(path.isEmpty())return;
    int longest=quality->currentIndex()==0?1920:quality->currentIndex()==1?3600:6000;
    bool ok=false;
    if(path.endsWith(".pdf",Qt::CaseInsensitive)||path.endsWith(".svg",Qt::CaseInsensitive)) {
      auto b=bounds();double scale=(longest-60)/std::max(b.width(),b.height());int w=std::max(100,qRound(b.width()*scale+60)),h=std::max(100,qRound(b.height()*scale+60));
      auto style=cl::render::RenderStyle::print();style.colorOutput=color->currentIndex()==0;style.showLiveState=style.colorOutput;
      auto drawExport=[&](auto &scene){cl::render::Transform t;t.a=scale;t.d=-scale;t.e=w/2-b.center().x()*scale;t.f=h/2+b.center().y()*scale;scene.setViewport(t);if(grid->isChecked()){std::vector<cl::render::Point> lines;for(double x=std::ceil(b.left());x<=b.right();++x){lines.push_back({float(x),float(b.top())});lines.push_back({float(x),float(b.bottom())});}for(double y=std::ceil(b.top());y<=b.bottom();++y){lines.push_back({float(b.left()),float(y)});lines.push_back({float(b.right()),float(y)});}scene.lines(lines,cl::render::Stroke(style.gridColor()));}draw(scene,style);};
      auto encoded=QFile::encodeName(path);ok=path.endsWith(".svg",Qt::CaseInsensitive)?cl::render::skiaRenderToSvg(encoded.constData(),w,h,drawExport):cl::render::skiaRenderToPdf(encoded.constData(),w,h,drawExport);
    } else ok=circuitImage(longest,color->currentIndex()==0,grid->isChecked()).save(path,"PNG");
    setStatus(ok?"Exported circuit":"Export failed");if(ok)dialog.accept();
  });
  DesktopDialogs::style(dialog, *appearance);
  dialog.adjustSize();
  if (owner) dialog.move(owner->geometry().center() - dialog.rect().center());
  dialog.exec();
}
bool Editor::memoryFilePath(const QString &gate, const QString &path, bool save) {
  auto id = ids.gates.find(gate.toStdString());
  auto model = id == ids.gates.end() ? gates.end() : gates.find(id->second);
  if (model == gates.end() || !dynamic_cast<guiGateRAM *>(model->second.get())) {
    setStatus("The memory component is no longer available.");
    return false;
  }
  const auto extension = QFileInfo(path).suffix().toLower();
  if (extension != "cdm" && (save || extension != "hex")) {
    setStatus(save ? "Save memory as a .cdm file."
                   : "Open a .cdm or .hex memory file.");
    return false;
  }
  if (!save) {
    QFile input(path);
    if (!input.open(QIODevice::ReadOnly)) {
      setStatus("Could not open memory file: " + input.errorString());
      return false;
    }
  }
  simulation.setGateParameter(id->second, save ? "WRITE_FILE" : "READ_FILE",
                              QFileInfo(path).absoluteFilePath().toStdString());
  return true;
}
void Editor::memoryFileForGate(const QString &gate, bool save, QWidget *parent) {
  const auto filters = save ? "CEDAR Memory files (*.cdm)"
      : "CEDAR Memory files (*.cdm);;INTEL-HEX (*.hex)";
  QFileDialog picker(parent, save ? "Save a memory file" : "Open a memory file",
                     appearance->editorSettings()["lastDir"].toString(), filters);
  picker.setAcceptMode(save ? QFileDialog::AcceptSave : QFileDialog::AcceptOpen);
  picker.setFileMode(save ? QFileDialog::AnyFile : QFileDialog::ExistingFile);
  if (save) picker.setDefaultSuffix("cdm");
  if (picker.exec() != QDialog::Accepted || picker.selectedFiles().isEmpty()) return;
  if (!memoryFilePath(gate, picker.selectedFiles().first(), save))
    DesktopDialogs::warning(*appearance, parent, "Memory file", status());
}
void Editor::memoryFile(bool save) {
  if (selected.size() == 1) memoryFileForGate(*selected.begin(), save, nullptr);
}
void Editor::convertToFrom(bool to) {
  if (locked) return;
  auto before = file;
  std::set<std::string> converted;
  for (auto &gate : file.pages[pageIndex].gates) {
    if (!selected.contains(QString::fromStdString(gate.uuid))) continue;
    auto &model = gates.at(ids.gates.at(gate.uuid));
    if (model->getGUIType() != (to ? "FROM" : "TO")) continue;
    // Preserve implicit defaults as well as authored labels during conversion.
    gate.params.clear();
    for (const auto &param : *model->getAllGUIParams())
      if (param.first != "angle") gate.params.push_back({param.first, param.second, true});
    for (const auto &param : *model->getAllLogicParams())
      gate.params.push_back({param.first, param.second, false});
    gate.libName = to ? "DE_TO" : "DA_FROM";
    converted.insert(gate.uuid);
  }
  if (converted.empty()) return;
  rebuild(false);
  for (auto &wire : wires) {
    std::vector<std::pair<unsigned long, std::string>> endpoints;
    for (const auto &[id, segment] : wire->getSegmentMap())
      for (const auto &connection : segment.connections)
        for (const auto &gate : converted)
          if (ids.gates.at(gate) == connection.gid)
            endpoints.push_back({connection.gid, connection.connection});
    for (const auto &endpoint : endpoints)
      wire->updateConnectionPos(endpoint.first, endpoint.second);
  }
  captureWires();
  auto after = file;
  file = before;
  edit(to ? "Convert to TO" : "Convert to FROM", [&](auto &document) { document = after; });
}

bool Editor::disconnectPin(const QVariantMap &pin) {
  if(locked || pin.isEmpty())return false;
  auto gateId=pin["gate"].toString().toStdString(),name=pin["pin"].toString().toStdString();
  for(size_t i=0;i<file.pages[pageIndex].wires.size();++i) {
    bool found=false;std::set<std::pair<std::string,std::string>> connections;
    for(const auto &seg:file.pages[pageIndex].wires[i].segments)for(auto c:seg.connects){connections.insert({c.gateUuid,c.pin});if(c.gateUuid==gateId&&c.pin==name)found=true;}
    if(!found)continue;
    auto before=file;
    if(connections.size()>2){wires[i]->removeConnection(gates.at(ids.gates.at(gateId)).get(),name);captureWires();}
    else file.pages[pageIndex].wires.erase(file.pages[pageIndex].wires.begin()+i);
    auto after=file;file=before;edit("Disconnect pin",[&](auto &f){f=after;});return true;
  }
  return false;
}
std::vector<Editor::PinPair> Editor::automaticConnections(guiGate *preview) const {
  struct Pin { QVariantMap data; QPointF point; bool active; };
  std::vector<Pin> pins;
  auto append = [&](guiGate &model, const QString &gate, bool active) {
    const auto &definition = gateLibrary().libraries.at(model.getLibraryName()).at(model.getLibraryGateName());
    const auto locations = model.getHotspotList();
    for (const auto &pin : definition.hotspots) {
      if (model.isConnected(pin.name)) continue;
      const auto point = locations.at(pin.name);
      pins.push_back({{{"gate", gate}, {"pin", QString::fromStdString(pin.name)},
                       {"bits", pin.busLines}, {"x", point.x}, {"y", point.y}},
                      {point.x, point.y}, active});
    }
  };
  for (const auto &gate : file.pages[pageIndex].gates) {
    const auto id = QString::fromStdString(gate.uuid);
    append(*gates.at(ids.gates.at(gate.uuid)), id, !preview && selected.contains(id));
  }
  if (preview) append(*preview, QStringLiteral("@placement"), true);

  // Only moved/placed pins need comparison. Keep the original document-order
  // pairing so multiple coincident pins are connected in the same order.
  std::map<std::pair<size_t, size_t>, PinPair> matches;
  for (size_t i = 0; i < pins.size(); ++i) {
    if (!pins[i].active) continue;
    for (size_t j = 0; j < pins.size(); ++j) {
      if (pins[i].data["gate"] == pins[j].data["gate"] ||
          pins[i].data["bits"] != pins[j].data["bits"] ||
          (pins[i].point - pins[j].point).manhattanLength() >= .01) continue;
      const auto first = std::min(i, j), last = std::max(i, j);
      matches.emplace(std::make_pair(first, last), PinPair{pins[first].data, pins[last].data});
    }
  }
  std::vector<PinPair> result;
  for (const auto &match : matches) result.push_back(match.second);
  return result;
}
QVariantList Editor::pendingAutoConnections(QPointF point) {
  if (locked || (placing.isEmpty() && !moving)) return {};
  QVariantList result;
  for (const auto &pair : automaticConnections(preparePlacement(point)))
    result.append(QVariantMap{{"x", pair.first["x"]}, {"y", pair.first["y"]}});
  return result;
}
void Editor::autoConnect() {
  if (locked) return;
  for (const auto &pair : automaticConnections())
    if (wireForPin(pair.first) < 0 && wireForPin(pair.second) < 0)
      connectPins(pair.first, pair.second);
}
void Editor::refreshSignals() {
  // Signal naming needs definition metadata, not a rendered gate. Resolve each
  // named link once instead of scanning/reconstructing gates per connection.
  std::map<std::string, QString> junctionNames;
  for (const auto &page : file.pages) {
    for (const auto &gate : page.gates) {
      const auto &library = gateLibrary().gateNameToLibrary.at(gate.libName);
      const auto &definition = gateLibrary().libraries.at(library).at(gate.libName);
      if (definition.guiType != "TO" && definition.guiType != "FROM") continue;
      const auto defaultName = definition.logicParams.find("JUNCTION_ID");
      std::string name = defaultName == definition.logicParams.end()
                             ? std::string() : defaultName->second;
      for (const auto &param : gate.params)
        if (!param.gui && param.name == "JUNCTION_ID") name = param.value;
      if (!name.empty()) junctionNames.emplace(gate.uuid, QString::fromStdString(name));
    }
  }

  signalWires.clear();
  for (const auto &page : file.pages) {
    for (const auto &wire : page.wires) {
      if (wire.ids.empty()) continue;
      QString name = "Wire " + QString::fromStdString(wire.ids[0]);
      // Preserve the original last-named-connection ordering and bus suffixes.
      for (const auto &segment : wire.segments)
        for (const auto &connection : segment.connects) {
          const auto junction = junctionNames.find(connection.gateUuid);
          if (junction != junctionNames.end()) name = junction->second;
        }
      signalWires[name] = ids.wires.at(wire.ids[0]);
      for (size_t bit = 1; bit < wire.ids.size(); ++bit)
        signalWires[name + QString("[%1]").arg(bit)] = ids.wires.at(wire.ids[bit]);
    }
  }

  QStringList names;
  names.reserve(signalWires.size());
  for (const auto &signal : signalWires) names << signal.first;
  if (signalNames != names) {
    signalNames = std::move(names);
    emit availableSignalsChanged();
  }
  for (int i = feedNames.size() - 1; i >= 0; --i)
    if (!signalWires.count(feedNames[i])) feedNames.removeAt(i);
  emit tracesChanged();
}
QStringList Editor::availableSignals() const { return signalNames; }
void Editor::addScopeFeed(const QString &name) {
  if (signalWires.count(name) && !feedNames.contains(name)) {
    feedNames << name;
    emit tracesChanged();
  }
}
void Editor::removeScopeFeed(int index) {
  if (index >= 0 && index < feedNames.size()) {
    feedNames.removeAt(index);
    emit tracesChanged();
  }
}
void Editor::clearScope() {
  history.clear();
  historyTime = TIME_NONE;
  emit tracesChanged();
}
void Editor::setScopePaused(bool value) {
  if (freezeScope == value) return;
  freezeScope = value;
  if (!value) clearScope();
  emit tracesChanged();
}
QVariantList Editor::traces() const {
  QVariantList out;
  out.reserve(feedNames.size());
  for (const auto &name : feedNames) {
    const auto id = signalWires.find(name);
    if (id == signalWires.end()) continue;
    QVariantList values;
    const auto samples = history.find(id->second);
    if (samples != history.end()) {
      values.reserve(samples->second.size());
      for (auto state : samples->second) values << int(state);
    }
    out << QVariantMap{{"name", name}, {"values", values}};
  }
  return out;
}
bool Editor::saveScopeLayout(const QString &path){QSaveFile out(path);QByteArray text="OSCOPE LAYOUT FILE\n"+QByteArray::number(feedNames.size())+" : following lines are order of inputs\n";for(auto name:feedNames)text+=name.toUtf8()+"\n";return out.open(QIODevice::WriteOnly)&&out.write(text)==text.size()&&out.commit();}
bool Editor::loadScopeLayout(const QString &path){QFile in(path);if(!in.open(QIODevice::ReadOnly))return false;QTextStream text(&in);if(text.readLine()!="OSCOPE LAYOUT FILE")return false;bool ok;int count=text.readLine().section(' ',0,0).toInt(&ok);if(!ok||count<0||count>4096)return false;QStringList names;for(int i=0;i<count;++i){if(text.atEnd())return false;auto name=text.readLine();if(signalWires.count(name)&&!names.contains(name))names<<name;}feedNames=names;clearScope();return true;}
void Editor::scopeLayoutDialog(bool save){auto path=save?QFileDialog::getSaveFileName(nullptr,"Save oscilloscope layout",{},"Cedar oscilloscope (*.cdo)"):QFileDialog::getOpenFileName(nullptr,"Load oscilloscope layout",{},"Cedar oscilloscope (*.cdo)");if(!path.isEmpty())setStatus((save?saveScopeLayout(path):loadScopeLayout(path))?"Oscilloscope layout ready":"Invalid or unreadable oscilloscope layout");}
QImage Editor::scopeImage(int w,int h) const {
  QImage image(w,h,QImage::Format_ARGB32);image.fill(Qt::white);QPainter painter(&image);int row=0;
  for(auto value:traces()){auto trace=value.toMap();auto samples=trace["values"].toList();int y=row*48;painter.setPen(Qt::black);painter.drawText(QRectF(8,y,140,48),Qt::AlignVCenter,trace["name"].toString());double dx=(w-160)/256.0;for(int i=0;i<samples.size();++i){int state=samples[i].toInt();double x=w-(samples.size()-i)*dx,yy=y+(state==ONE?10:state==ZERO?36:23);painter.setPen(state==ONE?QColor(Qt::red):state==UNKNOWN?QColor::fromRgbF(0.3,0.3,1):state==HI_Z?QColor::fromRgbF(0,0.78,0):QColor(Qt::black));if(state==UNKNOWN || state==CONFLICT)painter.fillRect(QRectF(x,y+10,dx,26),state==UNKNOWN?QColor::fromRgbF(0.3,0.3,1):QColor(Qt::cyan));else painter.drawLine(QPointF(x,yy),QPointF(x+dx,yy));}if(++row*48>=h)break;}return image;
}
void Editor::copyScopeImage(){QApplication::clipboard()->setImage(scopeImage());setStatus("Copied oscilloscope image");}

void Editor::parameterFile(const QString &key,const QString &path) {
  if(selected.size()!=1||path.isEmpty())return;
  for(auto field:parameterFields()){auto f=field.toMap();if(f["key"].toString()==key && (f["type"]=="FILE_IN"||f["type"]=="FILE_OUT")){simulation.setGateParameter(ids.gates.at(selected.begin()->toStdString()),key.mid(6).toStdString(),path.toStdString());return;}}
}

bool Editor::deleteWireAt(QPointF point, double radius) {
  if (locked) return false;
  const auto &page = file.pages[pageIndex];
  for (size_t i = 0; i < page.wires.size(); ++i) {
    for (const auto &segment : page.wires[i].segments) {
      QPointF nearest(segment.vertical ? segment.begin.x : std::clamp(point.x(), segment.begin.x, segment.end.x),
                      segment.vertical ? std::clamp(point.y(), segment.begin.y, segment.end.y) : segment.begin.y);
      if (QLineF(nearest, point).length() > radius) continue;
      edit("Delete wire", [&](auto &document) {
        auto &nets = document.pages[pageIndex].wires;
        nets.erase(nets.begin() + i);
      });
      return true;
    }
  }
  return false;
}
