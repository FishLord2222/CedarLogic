#include "Simulation.h"
#include "logic_circuit.h"
#include <QMetaObject>
#include <chrono>
#include <set>
#include <sstream>

namespace {
struct Plan {
  struct Gate {
    std::string type, definition;
    std::map<std::string, std::string> params;
    std::vector<lgHotspot> pins;
  };
  std::map<unsigned long, Gate> gates;
  struct Conn {
    unsigned long gate;
    std::string pin;
    std::vector<IDType> wires;
    bool input;
  };
  std::vector<Conn> conns;
  std::set<IDType> wires;
  std::string topology;
};
Plan plan(const cl::CircuitFile &file) {
  DocumentIds ids(file);
  Plan p;
  std::ostringstream signature;
  for (const auto &page : file.pages) {
    for (const auto &g : page.gates) {
      auto owner = gateLibrary().gateNameToLibrary.find(g.libName);
      if (owner == gateLibrary().gateNameToLibrary.end())
        throw std::runtime_error("Unknown gate: " + g.libName);
      const auto &def = gateLibrary().libraries.at(owner->second).at(g.libName);
      auto &gate = p.gates[ids.gates.at(g.uuid)];
      gate.type = def.logicType;
      gate.definition = g.libName;
      gate.params = def.logicParams;
      gate.pins = def.hotspots;
      for (const auto &param : g.params)
        if (!param.gui && param.name != "PULSE" && param.name != "READ_FILE" && param.name != "WRITE_FILE")
          gate.params[param.name] = param.value;
      // Always include the effective polarity, including the legacy default.
      // Undoing the first edit must also restore an existing simulation gate.
      if (gate.type == "DECODER")
        gate.params["OUTPUT_POLARITY"] = decoderOutputPolarity(def, g);
      signature << g.uuid << ':' << gate.type << ';';
    }
    for (const auto &w : page.wires) {
      std::vector<IDType> wid;
      for (const auto &id : w.ids) {
        auto n = ids.wires.at(id);
        wid.push_back(n);
        p.wires.insert(n);
        signature << id << ',';
      }
      std::set<std::pair<std::string, std::string>> seen;
      for (const auto &s : w.segments)
        for (const auto &conn : s.connects) {
          if (!seen.insert({conn.gateUuid, conn.pin}).second)
            continue;
          auto gid = ids.gates.at(conn.gateUuid);
          auto &gate = p.gates.at(gid);
          auto pin = std::find_if(
              gate.pins.begin(), gate.pins.end(),
              [&](const lgHotspot &h) { return h.name == conn.pin; });
          if (pin == gate.pins.end())
            throw std::runtime_error("Unknown gate pin: " + conn.pin);
          if (wid.size() != static_cast<size_t>(pin->busLines))
            throw std::runtime_error("Wire width does not match gate pin");
          p.conns.push_back({gid, conn.pin, wid, pin->isInput});
          signature << conn.gateUuid << ':' << conn.pin << ';';
        }
    }
  }
  p.topology = signature.str();
  return p;
}
void configure(Circuit &circuit, const Plan &p) {
  for (auto id : p.wires)
    circuit.newWire(id);
  for (const auto &entry : p.gates) {
    if (entry.second.type.empty())
      continue;
    auto id = circuit.newGate(entry.second.type, entry.first);
    if (id == ID_NONE)
      throw std::runtime_error("Unsupported simulation gate: " +
                               entry.second.type);
    for (const auto &param : entry.second.params)
      circuit.setGateParameter(id, param.first, param.second);
    for (const auto &pin : entry.second.pins) {
      if (pin.isInverted) {
        if (pin.isInput)
          circuit.setGateInputParameter(id, pin.name, "INVERTED", "TRUE");
        else
          circuit.setGateOutputParameter(id, pin.name, "INVERTED", "TRUE");
      }
      if (!pin.logicEInput.empty()) {
        if (pin.isInput)
          circuit.setGateInputParameter(id, pin.name, "E_INPUT",
                                        pin.logicEInput);
        else
          circuit.setGateOutputParameter(id, pin.name, "E_INPUT",
                                         pin.logicEInput);
      }
    }
  }
  for (const auto &conn : p.conns) {
    if (p.gates.at(conn.gate).type.empty())
      continue;
    for (size_t i = 0; i < conn.wires.size(); ++i) {
      auto pin = conn.wires.size() == 1 ? conn.pin
                                        : conn.pin + "_" + std::to_string(i);
      if (conn.input)
        circuit.connectGateInput(conn.gate, pin, conn.wires[i]);
      else
        circuit.connectGateOutput(conn.gate, pin, conn.wires[i]);
    }
  }
}
void updateCircuit(Circuit &circuit, const Plan &before, const Plan &after) {
  using Key = std::pair<unsigned long, std::string>;
  std::map<Key, Plan::Conn> oldPins, newPins;
  for (const auto &c : before.conns)
    oldPins[{c.gate, c.pin}] = c;
  for (const auto &c : after.conns)
    newPins[{c.gate, c.pin}] = c;
  auto unchanged = [&](const Key &key) {
    return oldPins.count(key) && newPins.count(key) &&
           oldPins.at(key).wires == newPins.at(key).wires &&
           oldPins.at(key).input == newPins.at(key).input &&
           before.gates.at(key.first).definition ==
               after.gates.at(key.first).definition;
  };
  for (const auto &entry : oldPins)
    if (!unchanged(entry.first) &&
        !before.gates.at(entry.first.first).type.empty()) {
      const auto &c = entry.second;
      for (size_t i = 0; i < c.wires.size(); ++i) {
        auto pin =
            c.wires.size() == 1 ? c.pin : c.pin + "_" + std::to_string(i);
        if (c.input)
          circuit.disconnectGateInput(c.gate, pin);
        else
          circuit.disconnectGateOutput(c.gate, pin);
      }
    }
  for (const auto &g : before.gates)
    if (!g.second.type.empty() &&
        (!after.gates.count(g.first) ||
         after.gates.at(g.first).definition != g.second.definition))
      circuit.deleteGate(g.first);
  for (auto w : before.wires)
    if (!after.wires.count(w))
      circuit.deleteWire(w);
  Plan added = after;
  added.conns.clear();
  for (const auto &g : before.gates)
    if (after.gates.count(g.first) &&
        after.gates.at(g.first).definition == g.second.definition)
      added.gates.erase(g.first);
  for (auto w : before.wires)
    added.wires.erase(w);
  configure(circuit, added);
  for (const auto &g : after.gates)
    if (!g.second.type.empty() && !added.gates.count(g.first))
      for (const auto &p : g.second.params) {
        auto prior = before.gates.at(g.first).params.find(p.first);
        if (prior == before.gates.at(g.first).params.end() ||
            prior->second != p.second)
          circuit.setGateParameter(g.first, p.first, p.second);
      }
  for (const auto &entry : newPins)
    if (!unchanged(entry.first) &&
        !after.gates.at(entry.first.first).type.empty()) {
      const auto &c = entry.second;
      for (size_t i = 0; i < c.wires.size(); ++i) {
        auto pin =
            c.wires.size() == 1 ? c.pin : c.pin + "_" + std::to_string(i);
        if (c.input)
          circuit.connectGateInput(c.gate, pin, c.wires[i]);
        else
          circuit.connectGateOutput(c.gate, pin, c.wires[i]);
      }
    }
}

} // namespace
Simulation::Simulation(QObject *parent) : QObject(parent) {
  worker = std::thread([this] { loop(); });
}
Simulation::~Simulation() {
  {
    std::lock_guard<std::mutex> lock(mutex);
    stopping = true;
  }
  wake.notify_all();
  worker.join();
}
void Simulation::submit(cl::CircuitFile file, unsigned long gen, bool reset) {
  std::lock_guard<std::mutex> lock(mutex);
  next = std::move(file);
  generation = gen;
  pending = true;
  resetRequested = resetRequested || reset;
  if(reset) commands.clear();
  wake.notify_all();
}
void Simulation::setRunning(bool value) {
  std::lock_guard<std::mutex> lock(mutex);
  running = value;
  wake.notify_all();
}
void Simulation::setGateParameter(unsigned long gate, const std::string &name, const std::string &value) {
  std::lock_guard<std::mutex> lock(mutex);
  commands.push_back({gate, name, value});
  wake.notify_all();
}
void Simulation::step(int count) {
  std::lock_guard<std::mutex> lock(mutex);
  steps += qBound(1, count, 1000);
  wake.notify_all();
}
void Simulation::setInterval(int ms) {
  std::lock_guard<std::mutex> lock(mutex);
  interval = qBound(1, ms, 1000);
  wake.notify_all();
}
void Simulation::loop() {
  std::unique_ptr<Circuit> circuit;
  Plan previous;
  unsigned long active = 0;
  bool wasRunning=false;
  auto nextTick=std::chrono::steady_clock::now();
  std::map<unsigned long,std::map<std::string,std::string>> runtime;
  while (true) {
    cl::CircuitFile file;
    bool load = false, reset = false;
    int count = 0, ms;
    std::vector<SimulationFrame::Param> inputCommands;
    {
      std::unique_lock<std::mutex> lock(mutex);
      if (!pending && commands.empty() && !steps && !running && !stopping)
        wake.wait(lock,
                  [&] { return stopping || pending || !commands.empty() || steps || running; });
      if (stopping)
        return;
      load = pending;
      if (load) {
        // The pending document belongs to this load once consumed under lock.
        file = std::move(next);
        active = generation;
        pending = false;
        reset = resetRequested;
        resetRequested = false;
      }
      inputCommands.swap(commands);
      count = steps;
      steps = 0;
      ms = interval;
      if(running) {
        auto now=std::chrono::steady_clock::now();
        if(!wasRunning) nextTick=now;
        if(now>=nextTick) {
          auto due=std::min<long long>(10,1+std::chrono::duration_cast<std::chrono::milliseconds>(now-nextTick).count()/ms);
          count=std::max(count,static_cast<int>(due));
          nextTick=now+std::chrono::milliseconds(ms);
        }
      }
      wasRunning=running;
    }
    SimulationFrame frame;
    frame.generation = active;
    try {
      if (load) {
        auto p = plan(file);
        if (!circuit || reset) {
          runtime.clear();
          circuit.reset();
          circuit = std::make_unique<Circuit>();
          configure(*circuit, p);
        } else
          updateCircuit(*circuit, previous, p);
        previous = std::move(p);
      }
      if (circuit) {
        for (const auto &command : inputCommands) {
          if (!previous.gates.count(command.gate)) continue;
          circuit->setGateParameter(command.gate,command.name,command.value);
          if (command.name != "PULSE") previous.gates[command.gate].params[command.name]=command.value;
        }
        auto captureParams = [&] {
          bool pause = false;
          for (auto param : circuit->getParamUpdateList()) {
            auto value=circuit->getGateParameter(param.gateID,param.paramName);
            if (param.paramName=="PAUSE_SIM") {pause=true;frame.params.push_back({static_cast<unsigned long>(param.gateID),param.paramName,value});}
            else if(param.paramName=="MemoryReset") {runtime[param.gateID].clear();frame.params.push_back({static_cast<unsigned long>(param.gateID),param.paramName,value});}
            else if(!value.empty()) runtime[param.gateID][param.paramName]=value;
          }
          circuit->clearParamUpdateList();
          return pause;
        };
        for (int i = 0; i < count; ++i) {
          ID_SET<IDType> changed;
          circuit->step(&changed);
          if(i>=count-256){std::map<IDType,StateType> sample;for(auto id:previous.wires)sample[id]=circuit->getWireState(id);frame.samples.push_back(std::move(sample));}
          if(captureParams()){setRunning(false);break;}
        }
        if (load && !count) circuit->refreshWireStates();
        if ((load || !inputCommands.empty()) && !count)
          circuit->stepOnlyGates();
        captureParams();
        frame.time = circuit->getSystemTime();
        for (auto id : previous.wires)
          frame.wires[id] = circuit->getWireState(id);
        for(const auto &gate:runtime) if(previous.gates.count(gate.first))
          for(const auto &param:gate.second)
            frame.params.push_back({gate.first,param.first,param.second});
      }
    } catch (const std::exception &e) {
      frame.error = e.what();
      setRunning(false);
    }
    QMetaObject::invokeMethod(
        this,
        [this, frame = std::move(frame)] {
          if (onFrame)
            onFrame(frame);
        },
        Qt::QueuedConnection);
    std::unique_lock<std::mutex> lock(mutex);
    if (running)
      wake.wait_until(lock, nextTick,
                    [&] { return stopping || pending || !commands.empty() || steps || !running; });
  }
}
