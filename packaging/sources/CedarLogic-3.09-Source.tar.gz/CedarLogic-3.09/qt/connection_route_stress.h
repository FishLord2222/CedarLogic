// Exercise the same route operations with ordinary gates and a three-pin net.
inline void checkOrdinaryConnectionStress(Appearance &theme) {
  for(int turns=0;turns<4;++turns)for(double distance:{12.0,48.0,500.0}) {
    auto rotate=[&](QPointF p){for(int i=0;i<turns;++i)p={-p.y(),p.x()};return p;};
    Editor editor(&theme);
    editor.setPlacement("AA_TOGGLE");editor.placeAt({0,0});
    editor.setPlacement("AA_AND2");editor.placeAt({distance,-1});
    editor.edit("Rotate connection test",[&](auto &doc){for(auto &g:doc.pages[0].gates){auto p=rotate({g.at.x,g.at.y});g.at={p.x(),p.y()};g.angle=turns*90;}});
    editor.connectPins(editor.pinAt(rotate({2,0}),.01),editor.pinAt(rotate({distance-3,0}),.01));
    auto reroute=[&](int i){
      const auto route=editor.document().pages[0].wires.at(0).segments;
      auto length=[](const auto &s){return std::hypot(s.end.x-s.begin.x,s.end.y-s.begin.y);};
      const auto segment=std::max_element(route.begin(),route.end(),[&](const auto &a,const auto &b){return length(a)<length(b);});
      check(segment!=route.end() && length(*segment)>1,"Ordinary connection collapsed into endpoint dots");
      const QPointF middle((segment->begin.x+segment->end.x)/2,(segment->begin.y+segment->end.y)/2);
      check(editor.startWireMove(middle+QPointF(.013,.017),.04),"Ordinary gate wire became unpickable");
      const double shift=(i%11-5)*.5;
      editor.moveWire(middle+(segment->vertical?QPointF(shift,.017):QPointF(.013,shift)));
      editor.finishWireMove();checkWireRoutes(editor);
    };
    for(int i=0;i<80;++i) {
      reroute(i);
      if(i%8==0){const auto g=editor.document().pages[0].gates[0];check(editor.selectAt({g.at.x,g.at.y}),"Cannot select connected input");editor.startMove();editor.moveSelected(rotate({0,double(i%3)-1}));editor.finishMove();checkWireRoutes(editor);}
    }
    editor.setPlacement("GA_LED");editor.placeAt(rotate({distance/2,12}));
    auto pin=[&](size_t index){const auto &g=editor.document().pages[0].gates[index];auto model=makeGate(g.libName);model->setGUIParam("angle",std::to_string(g.angle));model->setGLcoords(g.at.x,g.at.y);auto p=model->getHotspotList().begin()->second;return editor.pinAt({p.x,p.y},.01);};
    editor.connectPins(pin(0),pin(2));checkWireRoutes(editor);
    check(editor.document().pages[0].wires.size()==1,"Branch split the original net");
    for(int i=0;i<20;++i)reroute(i);
  }
  std::cerr<<"1200 ordinary-gate/branch reroutes and 120 gate moves at 12/48/500-unit spans passed\n";
}
