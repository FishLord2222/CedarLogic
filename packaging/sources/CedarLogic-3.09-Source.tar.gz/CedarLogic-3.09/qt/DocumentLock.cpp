#include "DocumentLock.h"
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSysInfo>
#ifdef Q_OS_UNIX
#include <errno.h>
#include <signal.h>
#endif
#ifdef Q_OS_WIN
#define NOMINMAX
#include <windows.h>
#endif
namespace {
bool alive(qint64 pid) {
#ifdef Q_OS_UNIX
  return kill(static_cast<pid_t>(pid), 0) == 0 || errno == EPERM;
#elif defined(Q_OS_WIN)
  auto handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE,
                            static_cast<DWORD>(pid));
  if (!handle)
    return GetLastError() == ERROR_ACCESS_DENIED;
  DWORD status = STILL_ACTIVE;
  GetExitCodeProcess(handle, &status);
  CloseHandle(handle);
  return status == STILL_ACTIVE;
#else
  Q_UNUSED(pid);
  return true;
#endif
}
} // namespace
DocumentLock::~DocumentLock() {
  if (marker.isEmpty())
    return;
  QFile file(marker);
  if (file.open(QIODevice::ReadOnly)) {
    auto data = file.readAll();
    file.close();
    if (data.startsWith(owner + "\n"))
      QFile::remove(marker);
  }
}
bool DocumentLock::acquire(const QString &input, QString &error) {
  auto info = QFileInfo(input);
  auto path = info.canonicalFilePath();
  if (path.isEmpty())
    path = info.absoluteFilePath();
  qtLock = std::make_unique<QLockFile>(path + ".qt-lock");
  qtLock->setStaleLockTime(0);
  if (!qtLock->tryLock()) {
    error = "Circuit is open in another Qt instance, or its directory is not "
            "writable.";
    return false;
  }
  QString candidate = QFileInfo(path).absoluteDir().filePath(
      "~" + QFileInfo(path).fileName() + ".lck");
  if (QFile::exists(candidate)) {
    QFile existing(candidate);
    if (!existing.open(QIODevice::ReadOnly)) {
      error = "Cannot read the existing circuit lock.";
      return false;
    }
    auto holder = QString::fromUtf8(existing.readLine()).trimmed();
    existing.close();
    auto host = holder.section('@', 1).section(':', 0, 0);
    bool ok = false;
    auto pid = holder.section(':', -1).toLongLong(&ok);
    if (host == QSysInfo::machineHostName() && ok && pid > 0 && !alive(pid))
      QFile::remove(candidate);
    else {
      error = "Circuit is already open by " + holder +
              ". Close that editor before reopening it here.";
      return false;
    }
  }
  QFile file(candidate);
  if (!file.open(QIODevice::WriteOnly | QIODevice::NewOnly)) {
    error = "Cannot acquire the shared circuit lock.";
    return false;
  }
  auto user =
      qEnvironmentVariable("USER", qEnvironmentVariable("USERNAME", "user"));
  owner = (user + "@" + QSysInfo::machineHostName() + ":" +
           QString::number(QCoreApplication::applicationPid()))
              .toUtf8();
  auto data =
      owner + "\n" +
      QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm").toUtf8() + "\n";
  if (file.write(data) != data.size()) {
    file.close();
    QFile::remove(candidate);
    error = "Cannot write the shared circuit lock.";
    return false;
  }
  marker = candidate;
  return true;
}
