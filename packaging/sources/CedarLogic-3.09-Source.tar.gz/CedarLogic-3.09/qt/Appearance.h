#pragma once
#include <QColor>
#include <QObject>
#include <QSettings>
#include <QVariantMap>
#ifdef CEDAR_PORTAL_THEME
#include <QDBusVariant>
#else
class QDBusVariant;
#endif

class Appearance : public QObject {
  Q_OBJECT
  Q_PROPERTY(QString mode READ mode WRITE setMode NOTIFY changed)
  Q_PROPERTY(
      QString accentName READ accentName WRITE setAccentName NOTIFY changed)
  Q_PROPERTY(QColor accent READ accent NOTIFY changed)
  Q_PROPERTY(bool dark READ dark NOTIFY changed)
  Q_PROPERTY(QColor background READ background NOTIFY changed)
  Q_PROPERTY(QColor panel READ panel NOTIFY changed)
  Q_PROPERTY(QColor raised READ raised NOTIFY changed)
  Q_PROPERTY(QColor border READ border NOTIFY changed)
  Q_PROPERTY(QColor text READ text NOTIFY changed)
  Q_PROPERTY(QColor muted READ muted NOTIFY changed)
  Q_PROPERTY(
      QVariantMap editorSettings READ editorSettings NOTIFY settingsChanged)
public:
  explicit Appearance(QObject *parent = nullptr);
  QString mode() const;
  QString accentName() const;
  QColor accent() const;
  Q_INVOKABLE QColor colorForName(const QString &name) const;
  bool dark() const;
  QColor background() const {
    return dark() ? QColor("#191c20") : QColor("#f5f6f8");
  }
  QColor panel() const {
    return dark() ? QColor("#23272d") : QColor("#ffffff");
  }
  QColor raised() const {
    return dark() ? QColor("#2c3239") : QColor("#e9edf2");
  }
  QColor border() const {
    return dark() ? QColor("#3b424b") : QColor("#cbd2da");
  }
  QColor text() const { return dark() ? QColor("#ecf1f7") : QColor("#202936"); }
  QColor muted() const {
    return dark() ? QColor("#a3adbb") : QColor("#536174");
  }
  void setMode(const QString &value);
  void setAccentName(const QString &value);
  QVariantMap editorSettings() const;
  Q_INVOKABLE void apply(const QString &mode, const QString &accent,
                         const QVariantMap &settings);
  Q_INVOKABLE void resetDefaults();
  Q_INVOKABLE void setStepInterval(int ms);
  Q_INVOKABLE void setSidebarNames(bool visible);
  void synchronize();
  void setSessionMode(const QString &value);
signals:
  void changed();
  void settingsChanged();

private:
  QSettings settings;
  QString sessionMode;
  int portalScheme = 0;
private slots:
#ifdef CEDAR_PORTAL_THEME
  void portalSettingChanged(const QString &group, const QString &key,
                            const QDBusVariant &value);
#endif
private:
  void importLegacy();
};
