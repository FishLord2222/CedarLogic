# Offline tutorial screenshots

The current tutorial uses 76 PNG captures of the Qt frontend in 79 image
placements. Forty-one help pages have current instructions, including the
command reference. The original contents tree and teaching sequence are retained.

The authoring tool uses the production QML, Editor, Canvas, simulator, gate
library, and property/export/file dialogs. QTest stages pointer gestures and
selections. Circuit-only images and scope-only images are cropped from actual
window captures. No interface, circuit, or waveform is painted as a substitute
for the application. The final project requires five changing named signals
before its capture is accepted.

Light-theme captures keep the original tutorial's white circuit background.
Main windows are captured at 1000 x 720 logical pixels; PNGs retain their capture
resolution and the help displays them at up to 560 pixels wide. The tutorial
viewer scales images proportionally when its text column is narrower. File
pickers vary between desktops; the captured Qt picker is an actual application
fallback dialog with an isolated example folder.

## Regenerating

Configure the normal Qt build with `BUILD_TESTING=ON`, then run from the source
root (replace `/path/to/build` with the configured build directory):

```sh
cmake --build /path/to/build --target capture_tutorial
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software /path/to/build/qt/capture_tutorial
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software /path/to/build/qt/capture_tutorial --features
python3 tools/refresh-tutorial-help.py
python3 tools/validate-tutorial-help.py
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software /path/to/build/qt/capture_tutorial --preview
```

The capture tool is an explicit authoring target, excluded from normal builds
and installs. Configuration is isolated in a temporary directory. It does not
change the user's preferences or open circuits. The optional first argument is
an alternate image output directory; `--preview` instead renders the updated
help in normal, narrow, and dark windows.

`res/help/screenshots/manifest.json` records every image's topic, caption, and
pixel dimensions. The validation script checks the entire help's local links,
contents targets, capture coverage, dimensions, aspect ratios, and alt text.
Preview PNGs are review artifacts and are not referenced recursively by help.

The original raster files remain available for historical comparison. Original
project-history and gate-reference illustrations are retained; these are not
screenshots of the current tutorial exercises. Release archives are not rewritten
by this authoring process.

Use `capture_tutorial --features` to refresh the Final Project, Preferences and signing captures and the light/dark toolbar icons. The original faith-page illustration is preserved, including if artwork is wrapped in a heading.
