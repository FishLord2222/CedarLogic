#include "CrashReporter.h"
#include <QApplication>
#include <QClipboard>
#include <QDialog>
#include <QFile>
#include <QProcess>
#include <QPushButton>
#include <QTemporaryDir>
#include <QTimer>
#include <csignal>
#include <iostream>
#ifdef _WIN32
#include <windows.h>
#endif
int main(int argc, char **argv) {
  std::cerr << "Crash test: initializing Qt\n" << std::flush;
  QApplication app(argc,argv); app.setApplicationVersion("3.08");
  if (app.arguments().contains("--crash")) {
    CrashReporter::install(app.arguments().last());
#ifdef _WIN32
    RaiseException(EXCEPTION_ACCESS_VIOLATION,EXCEPTION_NONCONTINUABLE,0,nullptr);
#else
    std::raise(SIGABRT);
#endif
    return 2;
  }
  std::cerr << "Crash test: launching isolated child\n" << std::flush;
  QTemporaryDir temp;
  const auto path=temp.filePath("trace.log");
  QProcess process; process.start(QCoreApplication::applicationFilePath(),{"--crash",path});
  if (!process.waitForFinished(10000)) { process.kill(); return 3; }
  std::cerr << "Crash test: child finished\n" << std::flush;
  QFile file(path);
  if (!file.open(QIODevice::ReadOnly)) { std::cerr << "No crash trace written\n"; return 4; }
  const auto trace=file.readAll(); file.close();
  if (!trace.contains("CedarLogic 3.08") || (!trace.contains("Fatal signal") && !trace.contains("Unhandled exception"))) return 5;
  CrashReporter::install(path);
  bool copied=false;
  bool outgoingAction=false;
  QTimer::singleShot(100,[&] {
    for (auto widget : QApplication::topLevelWidgets()) {
      if(widget->objectName()!="crashReportDialog")continue;
      for (auto button:widget->findChildren<QPushButton*>())
        if (button->text().contains("GitHub")) outgoingAction=true;
      auto copy=widget->findChild<QPushButton*>("copyCrashReport");
      auto dismiss=widget->findChild<QPushButton*>("dismissCrashReport");
      if(copy && dismiss) { copy->click(); copied=app.clipboard()->text().contains("### Crash trace"); dismiss->click(); }
    }
  });
  QTimer::singleShot(5000,&app,[]{for(auto widget:QApplication::topLevelWidgets())if(auto dialog=qobject_cast<QDialog*>(widget))dialog->reject();});
  std::cerr << "Crash test: opening local report\n" << std::flush;
  CrashReporter::showPending();
  if(!copied || outgoingAction || QFile::exists(path))return 6;
  std::cerr << "Crash test: opening local report\n" << std::flush;
  CrashReporter::showPending();
  std::cout << "Isolated fatal crash capture, next-launch dialog, copy and dismissal passed\n";
  return 0;
}
