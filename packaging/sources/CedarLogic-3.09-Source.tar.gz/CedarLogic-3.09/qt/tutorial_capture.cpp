// Repeatable photographs of the real Qt frontend, never painted UI facsimiles.
#include "Appearance.h"
#include "Canvas.h"
#include "Editor.h"
#include "GateLibrary.h"
#include "Keyboard.h"
#include "Settings.h"
#include "circuit_file_io.hpp"
#include "render/SkiaProbe.h"
#include <QApplication>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFontDatabase>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QTemporaryDir>
#include <QTest>
#include <QTimer>
#include <iostream>
#include <stdexcept>

void require(bool ok, const char *message) { if(!ok) throw std::runtime_error(message); }
QQuickItem *visualItem(QQuickItem *item,const QString &name) {
  if(item->objectName()==name && item->isVisible())return item;
  for(auto child:item->childItems())if(auto found=visualItem(child,name))return found;
  return nullptr;
}
struct Capture {
  Editor &e; QQuickWindow *w; Canvas *c; QString out;
  void settle() { QTest::qWait(100); }
  QPoint screen(QPointF world) {
    const auto center=c->visibleWorld().center(); const auto scale=c->zoom()*12;
    return c->mapToScene({c->width()/2+(world.x()-center.x())*scale,
                         c->height()/2-(world.y()-center.y())*scale}).toPoint();
  }
  void image(QString name, QRect area={}) {
    settle(); auto im=w->grabWindow(); if(!area.isNull())im=im.copy(area);
    require(!im.isNull() && im.save(out+"/"+name+".png"),"Cannot save screenshot");
    std::cout<<name.toStdString()<<" "<<im.width()<<"x"<<im.height()<<std::endl;
  }
  void dialog(QString name,QObject *popup) {
    settle();auto parent=popup->property("parent").value<QQuickItem *>();require(parent,"Dialog parent missing");
    auto top=parent->mapToScene({popup->property("x").toDouble(),popup->property("y").toDouble()}).toPoint();
    image(name,QRect(top,QSize(popup->property("width").toInt(),popup->property("height").toInt())).adjusted(-2,-2,2,2));
  }
  void scope(QString name) {
    settle();auto panel=w->findChild<QQuickItem *>("scopePanel");require(panel,"Scope panel missing");
    image(name,QRect(panel->mapToScene({0,0}).toPoint(),QSize(qRound(panel->width()),qRound(panel->height()))));
  }
  void scene(QString name) {
    auto top=c->mapToScene({0,0}).toPoint();
    auto b=e.bounds();auto area=QRect(screen({b.left(),b.top()}),screen({b.right(),b.bottom()})).normalized().adjusted(-18,-18,18,18);
    image(name,area.intersected(QRect(top,QSize(qRound(c->width()),qRound(c->height())))));
  }
  void clean() {
    e.setRunning(false); e.setPlacement("");
    e.edit("Tutorial scene",[](auto &f){f.pages={{}};});e.setCurrentPage(0);
    w->setProperty("scopeVisible",false);e.setScopePaused(false);while(!e.scopeFeeds().isEmpty())e.removeScopeFeed(0);e.selectAt({1000,1000});
  }
  void fit() { e.selectAt({1000,1000});c->fit();QTest::mouseMove(w,{980,705});settle(); }
  QPointF add(QString lib,QPointF at,QString name={}) {
    e.setPlacement(lib);e.placeAt(at);e.setPlacement("");
    if(!name.isEmpty())require(e.applyParameters({{"logic:JUNCTION_ID",name}}),"Cannot label named link");
    return at;
  }
  QPointF pin(QPointF at,QString name) {
    for(const auto &g:e.document().pages[e.currentPage()].gates) {
      if(std::abs(g.at.x-at.x())>.01 || std::abs(g.at.y-at.y())>.01)continue;
      auto model=makeGate(g.libName);require(model->getHotspot(name.toStdString()),"Missing fixture pin");
      float x,y;model->getHotspotCoords(name.toStdString(),x,y);return at+QPointF(x,y);
    } throw std::runtime_error("Missing fixture gate");
  }
  void wire(QPointF a,QString ap,QPointF b,QString bp) {
    const auto before=e.document().pages[e.currentPage()].wires.size();
    e.connectPins(e.pinAt(pin(a,ap),.1),e.pinAt(pin(b,bp),.1));
    require(e.document().pages[e.currentPage()].wires.size()>=before,"Fixture wire failed");
  }
  void tick(int n=50) {
    auto t=e.simulationTime();e.step(n);
    QElapsedTimer timer;timer.start();
    while((e.simulationTime()==TIME_NONE || (t!=TIME_NONE && e.simulationTime()<t+n)) && timer.elapsed()<3000)QTest::qWait(10);
    settle();
  }
  void properties(QString shot,QPointF at) {
    e.selectAt(at);QMetaObject::invokeMethod(w,"openGateProperties");image(shot);
    auto p=w->findChild<QObject *>("gatePropertiesDialog");QMetaObject::invokeMethod(p,"close");settle();
  }
  void menu(QString shot,QString menuName) {
    auto menu=w->findChild<QObject *>(menuName);require(menu,"Missing menu");
    QMetaObject::invokeMethod(menu,"open");image(shot);QMetaObject::invokeMethod(menu,"close");settle();
  }
  void adder(bool connected=true,bool complete=false,bool clocks=false,bool labels=true) {
    clean();
    for(int i=0;i<3;i++) {
      auto s=add(clocks && i<2?"BB_CLOCK":"AA_TOGGLE",{-24.,15.-i*4});
      auto to=add("DE_TO",{-15.,15.-i*4},labels?QString(QChar('A'+i)):QString());
      if(connected)wire(s,clocks && i<2?"CLK":"OUT_0",to,"IN_0");
    }
    auto x=add("AI_XOR3",{7,13});auto led=add("GA_LED",{17,13});
    for(int i=0;i<3;i++) {
      auto f=add("DA_FROM",{-3.,15.-i*2},labels?QString(QChar('A'+i)):QString());
      if(connected)wire(f,"IN_0",x,QString("IN_%1").arg(i));
    }
    if(connected)wire(x,"OUT",led,"N_in0");
    const char *names[]={"AB","AC","BC"};
    for(int row=0;row<3;row++) {
      double y=-1-row*8;auto a=add("AA_AND2",{7,y});
      for(int i=0;i<2;i++) {
        auto f=add("DA_FROM",{-3.,y+1-i*2},labels?QString(names[row][i]):QString());
        if(connected)wire(f,"IN_0",a,QString("IN_%1").arg(i));
      }
      if(!complete) {auto l=add("GA_LED",{17,y});if(connected)wire(a,"OUT",l,"N_in0");}
    }
    if(complete) {
      auto o=add("AE_OR3",{20,-9});auto l=add("GA_LED",{30,-9});
      if(connected){for(int i=0;i<3;i++)wire({7.,-1.-i*8},"OUT",o,QString("IN_%1").arg(i));wire(o,"OUT",l,"N_in0");}
    }
    if(connected)tick();fit();
  }
  void finalProject() {
    clean();
    // A compact, vertically balanced layout like the original tutorial.
    const auto reg=add("AA_REGISTER4",{-26,0});
    const auto clk=add("BB_CLOCK",{-35,-14});wire(clk,"CLK",reg,"clock");
    const auto low=add("AA_TOGGLE",{-35,0});wire(low,"OUT_0",reg,"load");wire(low,"OUT_0",reg,"clear");
    const auto high=add("AA_TOGGLE",{-29,12});e.interactAt(high);
    wire(high,"OUT_0",reg,"count_enable");wire(high,"OUT_0",reg,"count_up");
    for(int i=0;i<3;i++) {
      auto link=add("DE_TO",{-16.,2.-i*2},QString(QChar('A'+i)));
      wire(reg,QString("OUT_%1").arg(2-i),link,"IN_0");
    }
    const auto x=add("AI_XOR3",{4,15});
    for(int i=0;i<3;i++) {
      auto f=add("DA_FROM",{-6.,17.-i*2},QString(QChar('A'+i)));
      wire(f,"IN_0",x,QString("IN_%1").arg(i));
    }
    auto sum=add("DE_TO",{15,15},"Sum");wire(x,"OUT",sum,"IN_0");
    const char *pairs[]={"AB","AC","BC"};const auto o=add("AE_OR3",{17,-9});
    for(int row=0;row<3;row++) {
      const double y=1.-row*10.;auto a=add("AA_AND2",{4,y});
      for(int i=0;i<2;i++) {
        auto f=add("DA_FROM",{-6.,y+1-i*2},QString(pairs[row][i]));
        wire(f,"IN_0",a,QString("IN_%1").arg(i));
      }
      wire(a,"OUT",o,QString("IN_%1").arg(row));
    }
    auto carry=add("DE_TO",{28,-9},"Carry");wire(o,"OUT",carry,"IN_0");
    tick(100);fit();scene("image40-final");w->setProperty("scopeVisible",true);
    bool resized=false;
    for(auto object:w->findChildren<QObject *>())if(object->property("scopeHeight").isValid()){resized=object->setProperty("scopeHeight",350);break;}
    require(resized,"Cannot resize scope");
    for(auto name:{"A","B","C","Sum","Carry"})e.addScopeFeed(name);tick(200);
    require(e.traces().size()==5,"Final project is missing a named signal");
    for(auto row:e.traces()) {
      auto values=row.toMap()["values"].toList();require(values.contains(0) && values.contains(1),"Final project waveform does not toggle");
    }
    scope("image77");
  }
};
int main(int argc,char **argv) {
  QTemporaryDir config;qputenv("XDG_CONFIG_HOME",config.path().toUtf8());
  qputenv("QSG_RENDER_LOOP","basic");QQuickStyle::setStyle("Basic");
  QApplication app(argc,argv);app.setOrganizationName("CedarLogicTutorialCapture");app.setApplicationName("Capture");
  try {
    const QString res=CEDAR_SOURCE_RES;
    appConfig().resourcesDir=res.toStdString();
    gateLibrary().libParser=LibraryParse((res+"/cl_gatedefs.xml").toStdString());
    cl::render::setFontSearchDir((res+"/../").toUtf8().constData());
    QFontDatabase::addApplicationFont(res+"/InterfaceFont-Bold.ttf");
    auto id=QFontDatabase::addApplicationFont(res+"/InterfaceFont.ttf");
    if(id>=0){QFont font(QFontDatabase::applicationFontFamilies(id).first());font.setPixelSize(13);app.setFont(font);}
    Appearance theme;theme.setSessionMode("light");Editor e(&theme);Keyboard keyboard;
    QQmlApplicationEngine engine;
    qmlRegisterType<Canvas>("CedarLogic",1,0,"CircuitCanvas");
    qmlRegisterType<Waveforms>("CedarLogic",1,0,"Waveforms");
    engine.rootContext()->setContextProperty("backend",&e);
    engine.rootContext()->setContextProperty("theme",&theme);
    engine.rootContext()->setContextProperty("keyboard",&keyboard);
    engine.rootContext()->setContextProperty("releaseVersion","3.09");
    engine.addImageProvider("gates",new GateImages);engine.addImageProvider("icons",new Icons);
    engine.load(QUrl("qrc:/qml/Main.qml"));require(!engine.rootObjects().isEmpty(),"Frontend failed to load");
    auto w=qobject_cast<QQuickWindow *>(engine.rootObjects()[0]);w->resize(1000,720);keyboard.setWindow(w);
    require(QTest::qWaitForWindowExposed(w),"Window did not expose");
    const bool features=argc>1 && QString::fromLocal8Bit(argv[1])=="--features";
    const bool preview=argc>1 && QString::fromLocal8Bit(argv[1])=="--preview";
    QString out=argc>1 && !preview && !features?QString::fromLocal8Bit(argv[1]):res+"/help/screenshots";QDir().mkpath(out);
    Capture s{e,w,w->findChild<Canvas *>("circuitCanvas"),out};require(s.c,"Canvas missing");
    s.settle();
    if(features) {
      const auto iconDir=res+"/help/icons";QDir().mkpath(iconDir);Icons icons;
      for(auto mode:{"light","dark"}) {
        theme.setSessionMode(mode);
        for(auto name:{"new","open","open-circuit","save","undo","redo","copy","paste","zoomin","zoomout","pause","step","settings","locked"}) {
          const QString icon=name;
          auto im=icons.requestImage(icon+"/"+theme.text().name().mid(1),nullptr,{48,48});
          require(!im.isNull() && im.save(iconDir+"/"+icon+"-"+mode+".png"),"Toolbar icon capture failed");
        }
      }
      theme.setSessionMode("light");s.finalProject();s.clean();
      s.add("AA_TOGGLE",{0,0});s.add("GA_LED",{12,0});s.wire({0,0},"OUT_0",{12,0},"N_in0");s.tick();s.fit();
      QMetaObject::invokeMethod(w,"openPreferences");auto prefs=w->findChild<QObject *>("preferencesDialog");
      prefs->setProperty("section",2);s.dialog("preferences-files",prefs);QMetaObject::invokeMethod(prefs,"close");
      auto settings=theme.editorSettings();settings["signature"]="Tutorial Author";theme.apply("light","Teal",settings);
      QMetaObject::invokeMethod(w,"requestSign");s.dialog("sign-circuit",w->findChild<QObject *>("signCircuitDialog"));QMetaObject::invokeMethod(w->findChild<QObject *>("signCircuitDialog"),"close");
      e.signCircuit("This circuit works properly");s.fit();s.scene("signed-circuit");
      theme.setMode("dark");theme.setSessionMode("");QMetaObject::invokeMethod(w,"openPreferences");prefs->setProperty("section",0);s.dialog("preferences-appearance",prefs);QMetaObject::invokeMethod(prefs,"close");
      theme.setMode("light");theme.setSessionMode("");QMetaObject::invokeMethod(w,"openPreferences");prefs->setProperty("section",1);s.dialog("preferences-editor",prefs);QMetaObject::invokeMethod(prefs,"close");
      return 0;
    }
    if(preview) {
      auto tutorial=w->findChild<QObject *>("tutorialDialog");QMetaObject::invokeMethod(tutorial,"open");
      for(int i=0;i<e.helpTopics().size();i++)if(e.helpTopics()[i].toMap()["file"]=="Adding_Gates_To_A_Circuit.htm")QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(i)));
      s.image("tutorial-preview");w->resize(760,600);s.image("tutorial-preview-small");theme.setSessionMode("dark");s.image("tutorial-preview-dark");
      w->resize(1000,820);
      for(auto mode:{"light","dark"}) {
        theme.setSessionMode(mode);
        for(const auto &topic:QStringList{"How_To_Have_A_Personal_Relationship_With_God.htm","New.htm","Final_Project.htm","Signing_Circuits.htm","Appearance.htm","Editor_Preferences.htm","Autosave_Recovery.htm"}) {
          int found=-1;for(int i=0;i<e.helpTopics().size();i++)if(e.helpTopics()[i].toMap()["file"]==topic)found=i;
          require(found>=0,"Review topic missing from contents");QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(found)));
          s.image("review-"+topic.left(topic.size()-4)+"-"+mode);
        }
      }
      return 0;
    }
    s.image("image2");
    auto search=w->findChild<QObject *>("gateSearch");search->setProperty("text","3-input xor");s.settle();
    auto xorTile=visualItem(w->contentItem(),"sidebarPartImage1");require(xorTile,"XOR search result missing");QTest::mouseMove(w,xorTile->mapToScene({xorTile->width()/2,xorTile->height()/2}).toPoint());QTest::qWait(600);s.image("image4");
    e.setPlacement("AI_XOR3");QTest::mouseMove(w,s.screen({0,0}));s.image("image6");
    e.placeAt({0,0});e.setPlacement("");s.fit();s.image("image7");
    search->setProperty("text","");auto category=w->findChild<QObject *>("categoryCombo");
    category->setProperty("currentIndex",2);QMetaObject::invokeMethod(w,"refreshPalette");s.image("image8");
    s.adder(false,false,false,false);s.scene("Picture1");
    s.clean();s.add("DE_TO",{0,0});s.add("DA_FROM",{12,0});s.fit();s.scene("Picture2");s.properties("Picture3",{0,0});
    s.adder(false);s.scene("Picture4");
    // Wiring: same source, target, preview and completed connection as the guide.
    s.clean();s.add("AA_TOGGLE",{0,0});s.add("DE_TO",{12,0},"A");s.fit();s.c->zoomBy(.6);
    auto from=s.screen({2,0}),to=s.screen({10,0});QTest::mouseMove(w,from);s.scene("Picture5");
    QTest::mousePress(w,Qt::LeftButton,Qt::NoModifier,from);QTest::mouseMove(w,(from+to)/2);s.scene("Picture6");
    QTest::mouseMove(w,to);s.scene("Picture7");QTest::mouseRelease(w,Qt::LeftButton,Qt::NoModifier,to);s.tick();s.scene("Picture8");
    s.adder();s.scene("Picture9");
    s.clean();s.add("AA_TOGGLE",{0,0});s.add("DE_TO",{12,0},"A");s.wire({0,0},"OUT_0",{12,0},"IN_0");s.tick();s.fit();s.c->zoomBy(.6);
    QTest::mouseMove(w,s.screen({2,0}));s.scene("Picture10");e.disconnectPin(e.pinAt({2,0},.1));s.scene("Picture11");
    s.adder();e.selectAt({7,13});s.scene("Picture12");
    QTest::mousePress(w,Qt::LeftButton,Qt::NoModifier,s.screen({-7,20}));QTest::mouseMove(w,s.screen({21,-22}));s.scene("Picture13");
    QTest::mouseRelease(w,Qt::LeftButton,Qt::NoModifier,s.screen({21,-22}));s.scene("Picture14");
    e.selectAt({1000,1000});e.selectAt({-3,15});e.selectAt({-3,13},true);e.selectAt({-3,11},true);e.selectAt({7,13},true);s.scene("Picture15");
    e.deleteSelection();s.scene("Picture16");e.undo();s.tick();e.startMove();e.moveSelected({4,0});e.finishMove();s.scene("Picture17");
    s.clean();s.add("BB_CLOCK",{0,0});s.add("GA_LED",{20,6});s.wire({0,0},"CLK",{20,6},"N_in0");s.tick();s.fit();s.scene("Picture18");
    e.selectAll();s.scene("Picture19");e.selectAt({1000,1000});
    e.selectAt({20,6});e.startMove();e.moveSelected({0,-8});e.finishMove();s.scene("Picture20");
    e.startWireMove({12,0},1);e.moveWire({15,0});e.finishWireMove();s.scene("Picture21");
    s.adder();search->setProperty("text","label");s.image("image9");s.add("AA_LABEL",{-25,22});s.fit();s.scene("Picture22");s.properties("Picture23",{-25,22});
    s.adder();s.menu("image12","fileMenu");
    // Use the application's actual dialogs; isolate filenames in a temporary folder.
    QTemporaryDir examples;QDir().mkpath(examples.path()+"/Example Circuits");
    const auto exampleDir=examples.path()+"/Example Circuits";const auto circuit=exampleDir+"/Tutorial Adder.cdl";
    {QFile f(circuit);require(f.open(QIODevice::WriteOnly),"Cannot save tutorial fixture");f.write(QByteArray::fromStdString(cl::writeCircuitFile(e.document())));}
    auto fileDialog=[&](QString name,bool save) {
      QTimer::singleShot(150,[&] {
        auto d=qobject_cast<QFileDialog *>(QApplication::activeModalWidget());
        if(!d) {app.exit(4);return;}
        d->setDirectory(exampleDir);d->resize(760,460);s.settle();d->selectFile("Tutorial Adder.cdl");s.settle();
        require(d->grab().save(out+"/"+name+".png"),"Dialog capture failed");d->reject();
      });
      if(save)e.saveAs();else e.openDialog();
    };
    fileDialog("image13",true);s.menu("image23","fileMenu");fileDialog("image24",false);
    s.menu("image15","fileMenu");
    QTimer::singleShot(150,[&]{auto d=QApplication::activeModalWidget();require(d,"Export dialog missing");s.settle();require(d->grab().save(out+"/image16.png"),"Export capture failed");qobject_cast<QDialog *>(d)->reject();});
    e.exportDialog();s.image("image20");
    search->setProperty("text","");category->setProperty("currentIndex",0);QMetaObject::invokeMethod(w,"refreshPalette");
    s.adder(true,true);s.scene("image3");
    e.selectBox(QRectF(-30,6,20,14),false);s.scene("image4-copy");e.copy();e.paste();s.scene("image5-copy");
    e.startMove();e.moveSelected({0,-38});e.finishMove();s.fit();s.scene("image6-copy");
    e.selectAt({1000,1000});s.fit();s.image("image9-copy");
    s.adder(true,true);s.scene("image38");e.selectBox(QRectF(-7,-23,40,43),false);s.scene("image12-undo");
    e.deleteSelection();s.scene("image13-undo");e.undo();s.tick();s.scene("image14-undo");e.redo();s.scene("image15-undo");
    s.adder(true,true);s.image("image27");s.c->zoomBy(2.48832);s.image("image28");
    QTest::keyClick(w,Qt::Key_Down);QTest::keyClick(w,Qt::Key_Down);s.image("image29");
    QTest::keyClick(w,Qt::Key_Right);QTest::keyClick(w,Qt::Key_Right);s.image("image30");s.fit();s.image("image32");
    // A clock on the C input, with explicit pause/single-step states.
    e.selectAt({-24,7});e.deleteSelection();s.add("BB_CLOCK",{-26,7});s.wire({-26,7},"CLK",{-15,7},"IN_0");s.fit();s.tick();e.setRunning(true);s.image("image33");e.setRunning(false);s.image("image34");s.tick(5);s.image("image35");
    s.adder(true,true);s.image("image16-page");s.image("image17-page");e.addPage();e.setCurrentPage(0);s.image("image36");
    e.selectBox(QRectF(-7,-23,40,43),false);s.scene("image18-page");e.copy();e.setCurrentPage(1);s.image("image37");e.paste();e.startMove();e.moveSelected({-5,5});e.finishMove();s.tick();s.fit();s.image("image40");
    e.setCurrentPage(0);e.selectBox(QRectF(-7,-23,40,43),false);e.deleteSelection();s.fit();s.image("image65");
    for(int i=0;i<2;i++){e.selectAt({-24.,15.-i*4});e.deleteSelection();s.add("BB_CLOCK",{-26.,15.-i*4});e.applyParameters({{"logic:HALF_CYCLE",i==0?"10":"5"}});s.wire({-26.,15.-i*4},"CLK",{-15.,15.-i*4},"IN_0");}
    s.tick();s.fit();s.image("image64");s.properties("image66",{-26,15});
    e.setCurrentPage(1);s.add("DE_TO",{23,13},"Sum");s.wire({17,13},"N_in1",{23,13},"IN_0");s.tick();s.fit();s.image("image67");
    s.menu("image69","viewMenu");w->setProperty("scopeVisible",true);s.scope("image72");e.addScopeFeed("A");s.tick(200);s.scope("image73");
    e.addScopeFeed("B");e.addScopeFeed("Sum");s.tick(200);s.scope("image71");e.setScopePaused(true);s.scope("image74");
    s.finalProject();
    // Show the updated tutorial itself, then verify every page resolves its images.
    QMetaObject::invokeMethod(w->findChild<QObject *>("tutorialDialog"),"open");
    auto tutorial=w->findChild<QObject *>("tutorialDialog");
    for(int i=0;i<e.helpTopics().size();i++)if(e.helpTopics()[i].toMap()["file"]=="Adding_Gates_To_A_Circuit.htm")QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(i)));
    s.image("tutorial-preview");
    return 0;
  } catch(const std::exception &ex){std::cerr<<ex.what()<<std::endl;return 1;}
}
