#pragma once
#include "Appearance.h"
#include <QAbstractButton>
#include <QDialog>
#include <QComboBox>
#include <QAbstractItemView>
#include <QGuiApplication>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPushButton>
#include <QProxyStyle>
#include <QStyleFactory>
#include <QStyleOption>
#include <QWindow>

namespace DesktopDialogs {
class ControlStyle final : public QProxyStyle {
public:
  ControlStyle() : QProxyStyle(QStyleFactory::create("Fusion")) {}
  void drawPrimitive(PrimitiveElement element, const QStyleOption *option,
                     QPainter *painter, const QWidget *widget=nullptr) const override {
    if (element==PE_IndicatorCheckBox) {
      painter->save();painter->setRenderHint(QPainter::Antialiasing);
      const auto box=QRectF(option->rect).adjusted(1,1,-1,-1);
      const bool checked=option->state & (State_On|State_NoChange);
      painter->setPen(QPen(option->palette.color(option->state & State_HasFocus ? QPalette::Highlight : QPalette::Mid),1));
      painter->setBrush(option->palette.color(checked ? QPalette::Highlight : QPalette::Base));
      painter->drawRoundedRect(box,3,3);
      if (checked) {
        painter->setPen(QPen(option->palette.color(QPalette::HighlightedText),1.7,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin));
        QPainterPath mark;
        if(option->state & State_NoChange) {
          mark.moveTo(box.left()+3,box.center().y());mark.lineTo(box.right()-3,box.center().y());
        } else {
          mark.moveTo(box.left()+box.width()*.2,box.top()+box.height()*.5);
          mark.lineTo(box.left()+box.width()*.43,box.top()+box.height()*.73);
          mark.lineTo(box.left()+box.width()*.8,box.top()+box.height()*.27);
        }
        painter->drawPath(mark);
      }
      painter->restore();return;
    }
    if(element==PE_IndicatorArrowDown) {
      painter->save();painter->setRenderHint(QPainter::Antialiasing);
      painter->setPen(QPen(option->palette.color(QPalette::ButtonText),1.6,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin));
      const QPointF c=option->rect.center();QPainterPath arrow;
      arrow.moveTo(c+QPointF(-4,-2));arrow.lineTo(c+QPointF(0,2));arrow.lineTo(c+QPointF(4,-2));
      painter->drawPath(arrow);painter->restore();return;
    }
    QProxyStyle::drawPrimitive(element,option,painter,widget);
  }
};
inline void style(QDialog &dialog, const Appearance &theme) {
  auto controlStyle=dialog.findChild<QStyle *>("cedarDialogControlStyle");
  if(!controlStyle) {
    controlStyle=new ControlStyle;controlStyle->setObjectName("cedarDialogControlStyle");
    controlStyle->setParent(&dialog);
  }
  auto palette = dialog.palette();
  palette.setColor(QPalette::Window, theme.panel());
  palette.setColor(QPalette::WindowText, theme.text());
  palette.setColor(QPalette::Base, theme.background());
  palette.setColor(QPalette::Text, theme.text());
  palette.setColor(QPalette::Button, theme.raised());
  palette.setColor(QPalette::ButtonText, theme.text());
  palette.setColor(QPalette::Highlight, theme.accent());
  palette.setColor(QPalette::HighlightedText, theme.dark() ? QColor("#101418") : QColor("#ffffff"));
  palette.setColor(QPalette::Light, theme.panel());
  palette.setColor(QPalette::Midlight, theme.raised());
  palette.setColor(QPalette::Mid, theme.border());
  palette.setColor(QPalette::Dark, theme.border());
  palette.setColor(QPalette::Shadow, theme.border());
  palette.setColor(QPalette::Disabled,QPalette::Text,theme.muted());
  palette.setColor(QPalette::Disabled,QPalette::WindowText,theme.muted());
  palette.setColor(QPalette::Disabled,QPalette::ButtonText,theme.muted());
  dialog.setStyle(controlStyle);
  dialog.setPalette(palette);
  for(auto combo:dialog.findChildren<QComboBox *>()) {
    combo->view()->setStyle(controlStyle);combo->view()->setPalette(palette);
    combo->view()->viewport()->setPalette(palette);
  }
  for(auto widget:dialog.findChildren<QWidget *>()) {
    widget->setStyle(controlStyle);widget->setPalette(palette);
  }
  dialog.setStyleSheet(QString(
      "QDialog { background: %1; color: %2; }"
      "QLabel { color: %2; background: transparent; }"
      "QCheckBox { color: %2; background: transparent; spacing: 8px; }"
      "QComboBox { background: %3; color: %2; border: 1px solid %4; border-radius: 5px; padding: 7px 10px; padding-right: 28px; }"
      "QComboBox:hover, QComboBox:focus { border-color: %5; }"
      "QComboBox::drop-down { width: 26px; border: none; }"
      "QComboBox QAbstractItemView { background: %1; color: %2; selection-background-color: %5; selection-color: %6; border: 1px solid %4; }"
      "QPushButton { background: %3; color: %2; border: 1px solid %4;"
      " border-radius: 5px; padding: 8px 14px; min-width: 68px; }"
      "QPushButton:hover, QPushButton:focus { border-color: %5; }"
      "QPushButton:pressed { background: %1; }"
      "QPushButton:default { background: %5; border-color: %5; color: %6; }"
      "QPushButton:default:focus { border: 2px solid %2; padding: 7px 13px; }"
      "QPushButton:disabled { color: %7; }")
      .arg(theme.panel().name(), theme.text().name(), theme.raised().name(),
           theme.border().name(), theme.accent().name(),
           theme.dark() ? "#101418" : "#ffffff", theme.muted().name()));
  // Desktop styles can attach stock icons to standard dialog buttons.
  for (auto button : dialog.findChildren<QPushButton *>()) button->setIcon(QIcon());
}

inline QPixmap symbol(QMessageBox::Icon kind, const Appearance &theme) {
  // Original outline symbols, matching the weight of the app's toolbar icons.
  QPixmap result(64, 64); result.setDevicePixelRatio(2); result.fill(Qt::transparent);
  QPainter painter(&result); painter.setRenderHint(QPainter::Antialiasing);
  painter.setPen(QPen(theme.accent(), 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
  if (kind == QMessageBox::Warning) {
    QPainterPath triangle; triangle.moveTo(16, 3); triangle.lineTo(30, 28);
    triangle.lineTo(2, 28); triangle.closeSubpath(); painter.drawPath(triangle);
    painter.drawLine(QPointF(16, 11), QPointF(16, 19));
    painter.drawPoint(QPointF(16, 24));
  } else {
    painter.drawEllipse(QRectF(2, 2, 28, 28));
    if (kind == QMessageBox::Critical) {
      painter.drawLine(QPointF(11, 11), QPointF(21, 21));
      painter.drawLine(QPointF(21, 11), QPointF(11, 21));
    } else if (kind == QMessageBox::Question) {
      QPainterPath question; question.moveTo(11, 11);
      question.cubicTo(11, 5, 22, 5, 22, 11);
      question.cubicTo(22, 15, 16, 15, 16, 19); painter.drawPath(question);
      painter.drawPoint(QPointF(16, 24));
    } else {
      painter.drawPoint(QPointF(16, 9));
      painter.drawLine(QPointF(16, 14), QPointF(16, 23));
    }
  }
  return result;
}

inline QMessageBox::StandardButton message(
    Appearance &theme, QMessageBox::Icon kind, QWidget *parent,
    const QString &title, const QString &text,
    QMessageBox::StandardButtons buttons = QMessageBox::Ok,
    QMessageBox::StandardButton defaultButton = QMessageBox::NoButton) {
  auto owner = QGuiApplication::focusWindow();
  QMessageBox dialog(QMessageBox::NoIcon, title, text, buttons, parent);
  dialog.setObjectName("cedarMessageDialog");
  dialog.setTextFormat(Qt::PlainText);
  if (defaultButton != QMessageBox::NoButton) dialog.setDefaultButton(defaultButton);
  if (buttons.testFlag(QMessageBox::Cancel)) dialog.setEscapeButton(QMessageBox::Cancel);
  auto update = [&] {
    style(dialog, theme);
    if (kind != QMessageBox::NoIcon) dialog.setIconPixmap(symbol(kind, theme));
  };
  update();
  QObject::connect(&theme, &Appearance::changed, &dialog, update);
  dialog.winId();
  if (!parent && owner) dialog.windowHandle()->setTransientParent(owner);
  return static_cast<QMessageBox::StandardButton>(dialog.exec());
}
inline QMessageBox::StandardButton question(
    Appearance &theme, QWidget *parent, const QString &title, const QString &text,
    QMessageBox::StandardButtons buttons = QMessageBox::Yes | QMessageBox::No,
    QMessageBox::StandardButton defaultButton = QMessageBox::NoButton) {
  return message(theme, QMessageBox::Question, parent, title, text, buttons, defaultButton);
}
inline QMessageBox::StandardButton warning(
    Appearance &theme, QWidget *parent, const QString &title, const QString &text,
    QMessageBox::StandardButtons buttons = QMessageBox::Ok,
    QMessageBox::StandardButton defaultButton = QMessageBox::NoButton) {
  return message(theme, QMessageBox::Warning, parent, title, text, buttons, defaultButton);
}
}
