#include "Appearance.h"
#include "Settings.h"
#include <QDir>
#include <QFile>
#include <QGuiApplication>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QStyleHints>
#ifdef CEDAR_PORTAL_THEME
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusPendingCallWatcher>
#include <QDBusPendingReply>
#endif

namespace {
const QVariantMap defaults{{"grid", true},
                           {"sidebarNames", false},
                           {"connections", true},
                           {"connectionRadius", 0.18},
                           {"rightClickRotate", true},
                           {"helpTouchpadSpeed", 3},
                           {"fps", 60},
                           {"autosaveMinutes", 3},
                           {"signature", QString()},
                           {"stepMs", 25}, {"lastDir", QString()}};
}
Appearance::Appearance(QObject *parent)
    : QObject(parent),
      settings(QSettings::defaultFormat(), QSettings::UserScope, "CedarLogic",
               "CedarLogic-Qt") {
  importLegacy();
  settings.remove("editor/wireColor"); // Discard the retired circuit-color preference.
  synchronize();
#ifdef CEDAR_PORTAL_THEME
  QDBusConnection::sessionBus().connect(
      "org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
      "org.freedesktop.portal.Settings", "SettingChanged", this,
      SLOT(portalSettingChanged(QString, QString, QDBusVariant)));
  QDBusInterface portal(
      "org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
      "org.freedesktop.portal.Settings", QDBusConnection::sessionBus());
  portal.setTimeout(1000);
  auto watcher = new QDBusPendingCallWatcher(
      portal.asyncCall("Read", "org.freedesktop.appearance", "color-scheme"),
      this);
  connect(watcher, &QDBusPendingCallWatcher::finished, this,
          [this](QDBusPendingCallWatcher *w) {
            QDBusPendingReply<QDBusVariant> reply = *w;
            if (!reply.isError())
              portalSettingChanged("org.freedesktop.appearance", "color-scheme",
                                   reply.value());
            w->deleteLater();
          });
#endif
  connect(qGuiApp->styleHints(), &QStyleHints::colorSchemeChanged, this,
          [this] {
            synchronize();
            emit changed();
          });
}
QString Appearance::mode() const {
  return settings.value("appearance/mode", "system").toString();
}
QString Appearance::accentName() const {
  return settings.value("appearance/accent", "Teal").toString();
}
void Appearance::setSessionMode(const QString &v) {
  sessionMode = v;
  synchronize();
  emit changed();
}
bool Appearance::dark() const {
  if (sessionMode == "dark")
    return true;
  if (sessionMode == "light")
    return false;
  if (mode() == "dark")
    return true;
  if (mode() == "light")
    return false;
  auto scheme = qGuiApp->styleHints()->colorScheme();
  if (scheme == Qt::ColorScheme::Dark)
    return true;
  if (scheme == Qt::ColorScheme::Light)
    return false;
  return portalScheme == 1;
}
QColor Appearance::accent() const { return colorForName(accentName()); }
QColor Appearance::colorForName(const QString &name) const {
  const bool d = dark();
  const QMap<QString, QPair<QString, QString>> colors{
      {"Teal", {"#00c5c8", "#007e83"}},   {"Blue", {"#62a4ff", "#246bd5"}},
      {"Purple", {"#b69aff", "#7843c5"}}, {"Orange", {"#ffb15c", "#a95500"}},
      {"Green", {"#68d996", "#177a43"}},  {"Rose", {"#ff8caf", "#b32e65"}}};
  auto c = colors.value(name, colors.value("Teal"));
  return QColor(d ? c.first : c.second);
}
void Appearance::setMode(const QString &v) {
  if (v != "system" && v != "dark" && v != "light")
    return;
  settings.setValue("appearance/mode", v);
  synchronize();
  emit changed();
}
void Appearance::setAccentName(const QString &v) {
  if (!QStringList{"Teal", "Blue", "Purple", "Orange", "Green", "Rose"}
           .contains(v))
    return;
  settings.setValue("appearance/accent", v);
  emit changed();
}
QVariantMap Appearance::editorSettings() const {
  QVariantMap result = defaults;
  for (auto i = result.begin(); i != result.end(); ++i) {
    auto value = settings.value("editor/" + i.key(), i.value());
    // INI-backed settings lose scalar types across processes. In particular,
    // QML considers the string "false" truthy; expose the schema's actual type.
    if (value.convert(i.value().metaType())) i.value() = value;
  }
  return result;
}
void Appearance::synchronize() {
  auto v = editorSettings();
  auto &s = appConfig().appSettings;
  s.darkMode = dark();
  s.gridlineVisible = v["grid"].toBool();
  s.wireConnVisible = v["connections"].toBool();
  s.wireConnRadius = qBound(0.05, v["connectionRadius"].toDouble(), 1.0);
  s.rightClickRotate = v["rightClickRotate"].toBool();
  s.refreshRate = 1000 / qBound(10, v["fps"].toInt(), 1000);
  s.autosaveSeconds = qBound(0, v["autosaveMinutes"].toInt(), 60) * 60;
  s.signatureName = v["signature"].toString().toStdString();
  s.timePerStep = qBound(1, v["stepMs"].toInt(), 1000);
}
void Appearance::apply(const QString &m, const QString &a,
                       const QVariantMap &v) {
  for (auto i = defaults.begin(); i != defaults.end(); ++i)
    if (v.contains(i.key()))
      settings.setValue("editor/" + i.key(), v[i.key()]);
  setMode(m);
  setAccentName(a);
  settings.sync();
  synchronize();
  emit settingsChanged();
}
void Appearance::resetDefaults() {
  settings.remove("appearance");
  settings.remove("editor");
  synchronize();
  emit changed();
  emit settingsChanged();
}
void Appearance::importLegacy() {
  if (settings.value("migration/legacyImported", false).toBool())
    return;
  // The 3.06 settings format is plain key=value on Linux. Keep it untouched.
  QStringList candidates{QDir::homePath() + "/.CedarLogic",
                         QDir::homePath() + "/.cedarlogic",
                         QDir::homePath() + "/.config/CedarLogic"};
  const QMap<QString, QString> keys{{"WireConnVisible", "connections"},
                                    {"WireConnRadius", "connectionRadius"},
                                    {"GridlineVisible", "grid"},
                                    {"RightClickRotate", "rightClickRotate"},
                                    {"SignatureName", "signature"},
                                    {"TimeStep", "stepMs"}, {"LastDir", "lastDir"}};
  for (const auto &path : candidates) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
      continue;
    for (const auto &line : QString::fromUtf8(file.readAll()).split('\n')) {
      int eq = line.indexOf('=');
      if (eq < 0)
        continue;
      auto key = line.left(eq).trimmed(), value = line.mid(eq + 1).trimmed();
      if (keys.contains(key)) {
        QVariant v = value;
        if (key.endsWith("Visible") || key == "RightClickRotate")
          v = (value == "1" || value == "true");
        settings.setValue("editor/" + keys[key], v);
      }
      if (key == "RefreshRate" && value.toInt() > 0)
        settings.setValue("editor/fps", qBound(10, 1000 / value.toInt(), 1000));
      if (key == "AutosaveSeconds")
        settings.setValue("editor/autosaveMinutes",
                          qBound(0, (value.toInt() + 59) / 60, 60));
    }
    break;
  }
#ifdef Q_OS_WIN
  QSettings legacy("HKEY_CURRENT_USER\\Software\\CedarLogic",
                   QSettings::NativeFormat);
  for (auto i = keys.begin(); i != keys.end(); ++i)
    if (legacy.contains(i.key()))
      settings.setValue("editor/" + i.value(), legacy.value(i.key()));
#endif
  // New frontend defaults to following the OS, regardless of the old checkbox.
  settings.setValue("migration/legacyImported", true);
}

#ifdef CEDAR_PORTAL_THEME
void Appearance::portalSettingChanged(const QString &group, const QString &key,
                                      const QDBusVariant &value) {
#ifdef CEDAR_PORTAL_THEME
  if (group != "org.freedesktop.appearance" || key != "color-scheme")
    return;
  QVariant v = value.variant();
  if (v.canConvert<QDBusVariant>())
    v = v.value<QDBusVariant>().variant();
  portalScheme = v.toInt();
  synchronize();
  emit changed();
#else
  Q_UNUSED(group);
  Q_UNUSED(key);
  Q_UNUSED(value);
#endif
}

#endif

void Appearance::setStepInterval(int ms) {
  settings.setValue("editor/stepMs", qBound(1, ms, 500));
  synchronize();
  emit settingsChanged();
}

void Appearance::setSidebarNames(bool visible) {
  settings.setValue("editor/sidebarNames", visible);
  settings.sync();
  emit settingsChanged();
}
