#pragma once
#include "DocumentLock.h"
#include "SharedModel.h"
#include "Simulation.h"
#include <QObject>
#include <QImage>
#include <QHash>
#include <QPointer>
#include <QPointF>
#include <QSet>
#include <QTimer>
#include <QUndoStack>
#include <QVariantList>
#include <QVariantMap>
#include <deque>
#include <functional>
class Appearance;
class QDialog;
class QWidget;
namespace cl {
namespace render {
class Scene;
struct RenderStyle;
} // namespace render
} // namespace cl
class Editor : public QObject {
  Q_OBJECT
  Q_PROPERTY(bool editingLocked READ editingLocked WRITE setEditingLocked NOTIFY
                 changed)
  Q_PROPERTY(QString title READ title NOTIFY changed)
  Q_PROPERTY(bool dirty READ dirty NOTIFY changed)
  Q_PROPERTY(bool running READ running WRITE setRunning NOTIFY changed)
  Q_PROPERTY(QString status READ status NOTIFY changed)
  Q_PROPERTY(QString placement READ placement WRITE setPlacement NOTIFY changed)
  Q_PROPERTY(QStringList categories READ categories CONSTANT)
  Q_PROPERTY(QStringList pages READ pages NOTIFY pagesChanged)
  Q_PROPERTY(
      int currentPage READ currentPage WRITE setCurrentPage NOTIFY changed)
  Q_PROPERTY(QVariantList traces READ traces NOTIFY tracesChanged)
  Q_PROPERTY(QStringList availableSignals READ availableSignals NOTIFY availableSignalsChanged)
  Q_PROPERTY(QStringList scopeFeeds READ scopeFeeds NOTIFY tracesChanged)
  Q_PROPERTY(bool scopePaused READ scopePaused WRITE setScopePaused NOTIFY tracesChanged)
  Q_PROPERTY(bool canUndo READ canUndo NOTIFY changed)
  Q_PROPERTY(bool canRedo READ canRedo NOTIFY changed)
public:
  Editor(Appearance *appearance, QObject *parent = nullptr);
  ~Editor();
  bool editingLocked() const { return locked; }
  void setEditingLocked(bool value) {
    locked = value;
    emit changed();
  }
  QString title() const;
  bool dirty() const { return !undoStack.isClean(); }
  bool running() const { return isRunning; }
  QString status() const { return message; }
  QString placement() const { return placing; }
  QStringList categories() const;
  QStringList pages() const;
  int currentPage() const { return pageIndex; }
  bool canUndo() const { return undoStack.canUndo(); }
  bool canRedo() const { return undoStack.canRedo(); }
  void setCurrentPage(int value);
  QVariantMap pageView() const {auto i=pageViews.find(pageIndex);return i==pageViews.end()?QVariantMap():i->second;}
  void rememberView(const QVariantMap &view) {pageViews[pageIndex]=view;}
  void setPlacement(const QString &name);
  void setRunning(bool value);
  Q_INVOKABLE QVariantList palette(const QString &query,
                                   const QString &category) const;
  Q_INVOKABLE void newDocument();
  Q_INVOKABLE void openDialog();
  bool openPath(const QString &path, bool showErrors = true);
  Q_INVOKABLE bool save();
  Q_INVOKABLE bool saveAs();
  Q_INVOKABLE bool confirmClose();
  Q_INVOKABLE void undo();
  Q_INVOKABLE void redo();
  Q_INVOKABLE void step(int count = 1);
  TimeType simulationTime() const { return lastSimulationTime; }
  Q_INVOKABLE void addPage();
  Q_INVOKABLE void removePage(int index = -1);
  Q_INVOKABLE void deleteSelection();
  Q_INVOKABLE void rotateSelection();
  Q_INVOKABLE void copy();
  Q_INVOKABLE void cut();
  Q_INVOKABLE void paste(bool interactive=false);
  void finishPaste(bool commit);
  bool isPastePending() const { return pastePending; }
  Q_INVOKABLE void selectAll();
  Q_INVOKABLE void exportDialog();
  Q_INVOKABLE void exportLegacyDialog(int version);
  Q_INVOKABLE void openNewWindow();
  Q_INVOKABLE void convertToFrom(bool to);
  Q_INVOKABLE void memoryFile(bool save);
  bool memoryFilePath(const QString &gate, const QString &path, bool save);
  Q_INVOKABLE void parameterFile(const QString &key, const QString &path);
  Q_INVOKABLE void addScopeFeed(const QString &name);
  Q_INVOKABLE void removeScopeFeed(int index);
  Q_INVOKABLE void scopeLayoutDialog(bool save);
  Q_INVOKABLE void copyScopeImage();
  Q_INVOKABLE void clearScope();
  QStringList availableSignals() const;
  QStringList scopeFeeds() const { return feedNames; }
  bool scopePaused() const { return freezeScope; }
  void setScopePaused(bool value);
  bool saveScopeLayout(const QString &path);
  bool loadScopeLayout(const QString &path);
  QImage circuitImage(int longest, bool color, bool grid);
  QImage scopeImage(int width=1200,int height=500) const;
  bool disconnectPin(const QVariantMap &pin);
  bool deleteWireAt(QPointF point, double radius);
  void autoConnect();
  QVariantList pendingAutoConnections(QPointF placementPoint);
  QVariantMap connectionTarget(const QVariantMap &start, QPointF point, double radius) const;
  Q_INVOKABLE QVariantList parameterFields() const;
  Q_INVOKABLE bool applyParameters(const QVariantMap &values);
  Q_INVOKABLE QString helpUrl() const;
  Q_INVOKABLE QVariantList helpTopics() const;
  Q_INVOKABLE QString helpText(const QString &topic) const;
  Q_INVOKABLE QString helpBaseUrl() const;
  Q_INVOKABLE QString changelogText() const;
  Q_INVOKABLE bool beginSigning();
  Q_INVOKABLE void signCircuit(const QString &response);
  Q_INVOKABLE QString chooseParameterFile(bool save);
  Q_INVOKABLE bool memoryDialog();
  QVariantList traces() const;
  void checkRecovery();
  void draw(cl::render::Scene &scene, const cl::render::RenderStyle &style);
  QRectF bounds() const;
  void drawPlacement(cl::render::Scene &scene, const cl::render::RenderStyle &style, QPointF point);
  bool selectAt(QPointF point, bool additive = false);
  bool selectEditableAt(QPointF point);
  bool startWireMove(QPointF point, double radius);
  bool hasWireAt(QPointF point, double radius) const;
  void moveWire(QPointF point);
  void finishWireMove();
  void selectBox(QRectF rect, bool additive);
  void placeAt(QPointF point);
  void startMove();
  void moveSelected(QPointF delta);
  void finishMove();
  void cancelMove();
  QVariantMap pinAt(QPointF point, double radius) const;
  void connectPins(const QVariantMap &start, const QVariantMap &end);
  bool connectPinToWire(const QVariantMap &start, QPointF end, double radius);
  bool interactAt(QPointF point);
  StateType wireState(const std::string &id) const;
  QString gateValue(const std::string &id, const std::string &name) const;
  void setStatus(const QString &s) {
    message = s;
    emit changed();
  }
  unsigned long revision() const { return generation; }
  const cl::CircuitFile &document() const { return file; }
  void edit(const QString &label,
            const std::function<void(cl::CircuitFile &)> &action);
  void restore(const cl::CircuitFile &value, const cl::CircuitFile &reference);
signals:
  void availableSignalsChanged();
  void pagesChanged();
  void tracesChanged();
  void changed();
  void sceneChanged();
  void frameReady();
  void cameraFitRequested();
  void pageAboutToChange();
  void pageActivated();
  void pastePlacementRequested(QPointF anchor);
  void signatureRequired();

private:
  Appearance *appearance;
  cl::CircuitFile file;
  int publishedPageCount = -1;
  int pageIndex = 0;
  std::map<unsigned long, std::unique_ptr<guiGate>> gates;
  std::vector<std::unique_ptr<guiWire>> wires;
  DocumentIds ids{file};
  QUndoStack undoStack;
  QSet<QString> selected;
  QSet<QString> selectedWires;
  std::map<IDType, std::deque<StateType>> history;
  std::map<IDType, StateType> wireStates;
  TimeType historyTime = TIME_NONE, lastSimulationTime=TIME_NONE;
  int draggingWire = -1;
  std::vector<std::map<long, wireSegment>> moveWireMaps;
  QPointF wireDragPress;
  cl::CircuitFile moveBefore, pasteBefore;
  bool pastePending=false;
  std::map<int,QVariantMap> pageViews;
  QStringList feedNames;
  QStringList signalNames;
  std::map<QString, IDType> signalWires;
  void refreshSignals();
  bool freezeScope=false;
  bool moving = false, isRunning = false, locked = false;
  unsigned long generation = 0;
  Simulation simulation;
  QString filePath, message = "Paused", placing;
  double placementAngle=0;
  std::unique_ptr<guiGate> placementPreview;
  double previewAngle = -1;
  QTimer autosave;
  QString recoveryPath;
  QString recoveredPath;
  std::unique_ptr<QLockFile> recoveredLock;
  std::unique_ptr<QLockFile> recoveryLock;
  std::map<std::string, std::map<std::string, std::string>> runtimeParams;
  cl::CircuitFile runtimeFile() const;
  std::unique_ptr<DocumentLock> lock;
  QHash<QString, QPointer<QDialog>> memoryDialogs;
  void closeMemoryDialogs();
  void memoryFileForGate(const QString &gate, bool save, QWidget *parent);
  void rebuild(bool simulate = true, bool resetSimulation = false);
  void selectionChanged();
  void captureWires();
  guiGate *preparePlacement(QPointF point);
  using PinPair = std::pair<QVariantMap, QVariantMap>;
  std::vector<PinPair> automaticConnections(guiGate *preview = nullptr) const;
  int wireForPin(const QVariantMap &pin) const;
  void captureWire(guiWire &wire, cl::WireInstance &target);
  std::unique_ptr<guiWire> copyWireRoute(int index);
  bool writePath(const QString &path);
  void receive(const SimulationFrame &frame);
  void snapshot();
};
