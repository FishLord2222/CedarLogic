#include "Appearance.h"
#include "Editor.h"
#include "Settings.h"
#include "circuit_file_io.hpp"
#include "migrate.hpp"
#include "LegacyExport.h"
#include "ClipboardFormat.h"
#include <QClipboard>
#include <QMimeData>
#include <QApplication>
#include <QDir>
#include <QEventLoop>
#include <QFile>
#include <QTemporaryDir>
#include <QTimer>
#include <QMessageBox>
#include <QAbstractButton>
#include <QStandardPaths>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <stdexcept>
void check(bool v, const char *message) {
  if (!v)
    throw std::runtime_error(message);
}
void waitFrame(Editor &editor) {
  QEventLoop loop;
  bool received=false;
  auto conn =QObject::connect(&editor,&Editor::frameReady,&loop,[&]{received=true;loop.quit();});
  QTimer::singleShot(2000, &loop, &QEventLoop::quit);
  loop.exec();
  QObject::disconnect(conn);
  check(received,"Simulation frame timed out");
  check(editor.status().startsWith("Paused"),"Editing caused a simulation error");
}
void advance(Editor &editor, int steps) {
  auto target=editor.simulationTime()+steps;
  QEventLoop loop;
  auto conn=QObject::connect(&editor,&Editor::frameReady,&loop,[&]{if(editor.simulationTime()>=target)loop.quit();});
  editor.step(steps);
  QTimer::singleShot(3000,&loop,&QEventLoop::quit);loop.exec();QObject::disconnect(conn);
  check(editor.simulationTime()>=target,"Simulation did not complete requested steps");
}
// Every committed endpoint must be a pin or an actual bend/junction. There
// must be no free tail, fractional drag channel, duplicate ID or stale link.
void checkWireRoutes(const Editor &editor) {
  const auto &page=editor.document().pages[editor.currentPage()];
  for(const auto &wire:page.wires) {
    std::map<std::string,const cl::WireSegment *> segments;
    for(const auto &segment:wire.segments)
      check(segments.emplace(segment.id,&segment).second,"Duplicate segment ID after route cleanup");
    for(const auto &segment:wire.segments) {
      for(auto coordinate:{segment.begin.x,segment.begin.y,segment.end.x,segment.end.y}) {
        if (!std::isfinite(coordinate) || std::abs(coordinate-std::round(coordinate*2)/2)>=1e-5)
          std::cerr << "Invalid route coordinate " << coordinate << " in segment " << segment.id << '\n';
        check(std::isfinite(coordinate) && std::abs(coordinate-std::round(coordinate*2)/2)<1e-5,
              "Committed wire is off the original half-unit grid");
      }
      check(segment.vertical ? segment.begin.x==segment.end.x : segment.begin.y==segment.end.y,
            "Wire segment is not orthogonal");
      double lo=1e20,hi=-1e20;
      for(const auto &connection:segment.connects) {
        auto gate=std::find_if(page.gates.begin(),page.gates.end(),[&](const auto &g){return g.uuid==connection.gateUuid;});
        check(gate!=page.gates.end(),"Wire references a missing gate");
        auto model=makeGate(gate->libName);model->setGUIParam("angle",std::to_string(gate->angle));
        model->setGLcoords(gate->at.x,gate->at.y);
        const auto pin=model->getHotspotList().at(connection.pin);
        check(std::abs((segment.vertical?pin.x:pin.y)-(segment.vertical?segment.begin.x:segment.begin.y))<1e-5,
              "Wire endpoint detached from its original hotspot");
        const double position=segment.vertical?pin.y:pin.x;lo=std::min(lo,position);hi=std::max(hi,position);
      }
      for(const auto &intersection:segment.intersections) {
        check(segments.count(intersection.segment),"Wire has a dangling intersection ID");
        const auto &other=*segments.at(intersection.segment);
        check(other.vertical!=segment.vertical,"Wire junction links parallel segments");
        check(std::abs(intersection.at-(segment.vertical?other.begin.y:other.begin.x))<1e-5,
              "Wire junction coordinate does not match its branch");
        const auto cross=segment.vertical?segment.begin.x:segment.begin.y;
        check(cross>=(other.vertical?other.begin.y:other.begin.x)-1e-5 &&
              cross<=(other.vertical?other.end.y:other.end.x)+1e-5,"Wire junction lies outside its branch");
        bool reciprocal=false;
        for(const auto &back:other.intersections)
          if(back.segment==segment.id && std::abs(back.at-cross)<1e-5) reciprocal=true;
        check(reciprocal,"Wire junction is not reciprocal");
        lo=std::min(lo,intersection.at);hi=std::max(hi,intersection.at);
      }
      check(std::abs(lo-(segment.vertical?segment.begin.y:segment.begin.x))<1e-5 &&
            std::abs(hi-(segment.vertical?segment.end.y:segment.end.x))<1e-5,
            "Wire has an unsupported dangling tail");
    }
  }
}
void checkOriginalRouting(Appearance &theme,const QString &directory) {
  Editor editor(&theme);waitFrame(editor);
  editor.setPlacement("AA_TOGGLE");editor.placeAt({-12,3});
  editor.setPlacement("AA_AND2");editor.placeAt({0,0});
  editor.connectPins(editor.pinAt({-10,3},.1),editor.pinAt({-3,1},.1));
  checkWireRoutes(editor);
  // Original calcShape truncates its midpoint to a half unit, including negatives.
  bool trunk=false;
  for(const auto &segment:editor.document().pages[0].wires[0].segments)
    if(segment.vertical && segment.begin.x==-6.5) trunk=true;
  check(trunk,"Connection did not use the original CedarLogic midpoint router");
  const auto initial=editor.document();
  for(auto release:{QPointF(-4.18,4.24),QPointF(-9.76,-.26),QPointF(-6.5,2)}) {
    check(editor.startWireMove({-6.43,2.07},.15),"Cannot pick the routed trunk near its grid point");
    editor.moveWire(release);editor.finishWireMove();checkWireRoutes(editor);
    if(!(editor.document()==initial)) {
      editor.undo();check(editor.document()==initial,"Wire drag undo changed the original route");
      editor.redo();checkWireRoutes(editor);editor.undo();
    }
  }
  // A horizontal drag must also ignore the sub-grid press offset.
  check(editor.startWireMove({-8.04,3.07},.15),"Cannot pick a horizontal wire");
  editor.moveWire({-7.76,5.24});editor.finishWireMove();checkWireRoutes(editor);
  editor.undo();check(editor.document()==initial,"Horizontal drag undo changed the wire");
  // A hovered target identifies the net; the original router chooses the nearest
  // branch instead of permanently using the arbitrary release pixel.
  editor.setPlacement("GA_LED");editor.placeAt({-12,-4});
  auto led=makeGate("GA_LED");led->setGLcoords(-12,-4);
  auto pin=led->getHotspotList().begin()->second;
  check(editor.connectPinToWire(editor.pinAt({pin.x,pin.y},.1),{-8.13,3.04},.15),"Cannot branch at a sub-grid hover position");
  checkWireRoutes(editor);
  editor.circuitImage(700,true,false).save(directory+"/original-router.png");
  check(cl::readCircuitFile(cl::writeCircuitFile(editor.document()))==editor.document(),"Routed wire failed file roundtrip");
  Editor nand(&theme);waitFrame(nand);nand.setPlacement("DI_NAND8");nand.placeAt({0,0});
  nand.connectPins(nand.pinAt({-3,2.5},.1),nand.pinAt({-3,-1.5},.1));
  check(nand.startWireMove({-2.94,.07},.15),"Cannot pick input-only NAND trunk");
  nand.moveWire({-6.76,.17});nand.finishWireMove();checkWireRoutes(nand);
  check(nand.connectPinToWire(nand.pinAt({-3,.5},.1),{-6.97,.83},.4),"Cannot add the NAND branch from the screenshot");
  checkWireRoutes(nand);
  for(const auto &segment:nand.document().pages[0].wires[0].segments)
    check(segment.begin.y>=-1.5 && segment.end.y<=2.5,"NAND branch leaves an extended free tail");
  nand.circuitImage(700,true,false).save(directory+"/nand-branches.png");
  std::cerr << "Original router, free-tail/junction checks, negative grid, sub-grid press/release, both drag axes, branch placement, NAND fanout and undo/redo passed\n";
}
void checkMovedSwitchRoute(Appearance &theme, const QString &directory) {
  for (int turns = 0; turns < 4; ++turns) {
  std::cerr << "Checking moved switch at " << turns*90 << " degrees\n";
  auto rotate = [turns](QPointF point, bool inverse = false) {
    const int count = inverse ? (4-turns)%4 : turns;
    for (int i = 0; i < count; ++i) point = {-point.y(), point.x()};
    return point;
  };
  Editor editor(&theme); waitFrame(editor);
  editor.setPlacement("AA_TOGGLE"); editor.placeAt({-12,-5});
  editor.setPlacement("AA_AND2"); editor.placeAt({0,0});
  editor.edit("Rotate test circuit", [&](auto &document) {
    for (auto &gate : document.pages[0].gates) {
      const auto point = rotate({gate.at.x, gate.at.y});
      gate.at = {point.x(), point.y()}; gate.angle = turns*90;
    }
  });
  editor.connectPins(editor.pinAt(rotate({-10,-5}),.1),editor.pinAt(rotate({-3,1}),.1));
  check(editor.startWireMove(rotate({-6.5,-2}),.15),"Cannot pick switch connection trunk");
  editor.moveWire(rotate({-15,-2})); editor.finishWireMove();
  const auto routed=editor.document();
  check(editor.selectAt(rotate({-12,-5})),"Cannot select the lower switch");
  editor.startMove(); editor.moveSelected(rotate({0,6}));
  editor.cancelMove(); check(editor.document()==routed,"Canceling switch move changes its route");
  editor.startMove(); editor.moveSelected(rotate({0,6})); editor.finishMove();
  editor.circuitImage(900,true,false).save(directory+QString("/moved-switch-%1.png").arg(turns));
  checkWireRoutes(editor);
  for(const auto &segment:editor.document().pages[0].wires[0].segments) {
    const auto begin = rotate({segment.begin.x,segment.begin.y},true);
    const auto end = rotate({segment.end.x,segment.end.y},true);
    check(begin.x()>=-10-1e-5 && end.x()>=-10-1e-5,
          "Moving switch level with gate leaves a wire folded into its body");
  }
  const auto moved=editor.document();
  check(moved.pages[0].wires[0].ids==routed.pages[0].wires[0].ids,"Moving switch changed wire identity");
  editor.undo(); check(editor.document()==routed,"Switch move undo lost manually routed geometry");
  editor.redo(); check(editor.document()==moved,"Switch move redo changed the cleaned route");
  const auto encoded = cl::writeCircuitFile(moved);
  const auto decoded = cl::readCircuitFile(encoded);
  // Rotated model pins contain tiny sin/cos roundoff; the existing file format
  // writes ten significant digits. Check geometry at the grid tolerance and
  // retain exact identities, pin associations and canonical serialized form.
  check(decoded.pages[0].gates==moved.pages[0].gates &&
        decoded.pages[0].wires[0].ids==moved.pages[0].wires[0].ids &&
        cl::writeCircuitFile(decoded)==encoded,"Moved switch roundtrip changed gates or wire identity");
  const auto &savedSegments = decoded.pages[0].wires[0].segments;
  const auto &liveSegments = moved.pages[0].wires[0].segments;
  check(savedSegments.size()==liveSegments.size(),"Moved switch roundtrip changed segment count");
  for (size_t i = 0; i < liveSegments.size(); ++i) {
    const auto &saved = savedSegments[i], &live = liveSegments[i];
    check(saved.id==live.id && saved.vertical==live.vertical && saved.connects==live.connects &&
          saved.intersections.size()==live.intersections.size(),"Moved switch roundtrip changed topology");
    for (auto delta : {saved.begin.x-live.begin.x,saved.begin.y-live.begin.y,
                       saved.end.x-live.end.x,saved.end.y-live.end.y})
      check(std::abs(delta)<1e-5,"Moved switch roundtrip changed wire geometry");
  }
  }
  std::cerr << "Moved switch cleanup: all four orientations, no folded tail, stable identity, cancel, undo/redo and file roundtrip passed\n";
}
void checkWireRemoval(Appearance &theme) {
  for(bool deleteGate:{true,false}) {
    Editor editor(&theme);waitFrame(editor);
    editor.setPlacement("DI_NAND8");editor.placeAt({0,0});
    editor.connectPins(editor.pinAt({-3,2.5},.1),editor.pinAt({-3,-1.5},.1));
    check(editor.startWireMove({-3,.5},.1),"Cannot move input-only trunk");
    editor.moveWire({-7,.5});editor.finishWireMove();
    editor.connectPins(editor.pinAt({-3,.5},.1),editor.pinAt({-3,2.5},.1));
    checkWireRoutes(editor);
    const auto withoutPower=editor.document();
    editor.setPlacement("EE_VDD");editor.placeAt({-7,7.5});
    check(editor.connectPinToWire(editor.pinAt({-7,6.5},.1),{-7,1},.1),"Cannot connect the fanout to power");
    advance(editor,10);
    const auto powered=editor.document();
    const auto wire=powered.pages[0].wires[0].ids[0];
    check(editor.wireState(wire)==ONE,"Powered fanout did not settle high");
    const auto time=editor.simulationTime();
    if(deleteGate) {editor.selectAt({-7,7.5});editor.deleteSelection();}
    else check(editor.disconnectPin(editor.pinAt({-7,6.5},.1)),"Power disconnect failed");
    // These geometry checks run synchronously, before any mouse interaction or
    // simulation step. The stale source branch must already be gone.
    checkWireRoutes(editor);
    check(editor.document().pages[0].wires.size()==1,"Removing power deleted the input fanout");
    for(const auto &segment:editor.document().pages[0].wires[0].segments)
      check(segment.begin.y>=-1.5 && segment.end.y<=2.5,"Removing power left the old vertical source tail");
    waitFrame(editor);
    check(editor.simulationTime()==time,"Paused structural removal advanced the clock");
    check(editor.wireState(wire)==HI_Z,"Removing the last driver did not immediately resolve a non-driven wire");
    const auto collapsed=editor.document();
    editor.undo();waitFrame(editor);check(editor.document()==powered,"Removal undo did not restore the source route");
    advance(editor,5);check(editor.wireState(wire)==ONE,"Undo did not restore power");
    editor.redo();waitFrame(editor);check(editor.document()==collapsed,"Removal redo changed the collapsed route");
    check(editor.wireState(wire)==HI_Z,"Removal redo left a stale driver state");
    if(!deleteGate) {
      editor.connectPinToWire(editor.pinAt({-7,6.5},.1),{-7,1},.1);advance(editor,5);
      check(editor.wireState(wire)==ONE,"Reconnect did not restore the driver");
    }
    check(withoutPower.pages[0].wires[0].ids==collapsed.pages[0].wires[0].ids,"Wire identity changed after removing power");
  }
  std::cerr << "Power deletion and pin disconnection immediately collapse three-input fanout, preserve wire IDs, resolve paused state without clock advance, and support undo/redo/reconnect\n";
}

void checkStabilityLoadingAndRecovery(Appearance &theme, const QString &directory) {
  cl::CircuitFile good;
  {
    Editor editor(&theme); waitFrame(editor);
    editor.setPlacement("AA_TOGGLE"); editor.placeAt({-12,3});
    editor.setPlacement("AA_AND2"); editor.placeAt({0,0});
    editor.connectPins(editor.pinAt({-10,3},.1),editor.pinAt({-3,1},.1));
    good=editor.document();
  }
  auto write=[&](const QString &path,const cl::CircuitFile &file) {
    QFile output(path); check(output.open(QIODevice::WriteOnly),"Cannot create stability fixture");
    const auto bytes=QByteArray::fromStdString(cl::writeCircuitFile(file));
    check(output.write(bytes)==bytes.size(),"Cannot write stability fixture");
  };
  auto conflicting=good;
  conflicting.pages[0].wires.push_back(conflicting.pages[0].wires.front());
  conflicting.pages[0].wires.back().ids={"90000001"};
  auto path=directory+"/conflicting-pins.cdl";write(path,conflicting);
  {
    Editor editor(&theme); waitFrame(editor);
    if (!editor.openPath(path,false)) throw std::runtime_error("Conflicting pin load failed: "+editor.status().toStdString());
    check(editor.status().contains("conflicting pin connections dropped"),"Missing wiring repair warning");
    check(editor.dirty(),"Repair should require a deliberate save");
    std::set<std::pair<std::string,std::string>> claimed;
    for(const auto &wire:editor.document().pages[0].wires)
      for(const auto &segment:wire.segments)
        for(const auto &c:segment.connects)
          check(claimed.emplace(c.gateUuid,c.pin).second,"Multiple nets still claim a pin");
    waitFrame(editor);
  }
  auto duplicate=good;duplicate.pages[0].wires.push_back(duplicate.pages[0].wires.front());
  path=directory+"/duplicate-wire-id.cdl";write(path,duplicate);
  {
    Editor editor(&theme);waitFrame(editor);const auto before=editor.document();
    check(!editor.openPath(path,false),"Duplicate net IDs should be rejected");
    check(editor.document()==before,"Rejected circuit replaced the live document");
  }
  const auto recoveryDir=QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
  QDir().mkpath(recoveryDir);
  const auto source=recoveryDir+"/recovery-stability-original.cdl";
  write(source,good);
  auto answer=[](QMessageBox::StandardButton button) {
    QTimer::singleShot(0,[button] {
      for(auto widget:QApplication::topLevelWidgets())
        if(auto box=qobject_cast<QMessageBox*>(widget))
          if(auto choice=box->button(button)) choice->click();
    });
  };
  {
    QDir dir(recoveryDir);const auto before=dir.entryList({"recovery*.lock"},QDir::Files);
    Editor editor(&theme);waitFrame(editor);
    QString blocked;
    for(const auto &name:dir.entryList({"recovery*.lock"},QDir::Files))
      if(!before.contains(name)) blocked=dir.filePath(name).chopped(5);
    check(!blocked.isEmpty() && QDir().mkpath(blocked),"Cannot force autosave failure");
    answer(QMessageBox::Yes);editor.checkRecovery();
    check(editor.document()==good,"Valid recovery did not restore circuit");
    check(QFile::exists(source),"Failed replacement snapshot deleted recovery source");
    check(editor.status().startsWith("Autosave failed"),"Failed snapshot was not reported");
    QLockFile second(source+".lock");second.setStaleLockTime(0);
    check(!second.tryLock(),"Recovered source is not protected from another instance");
    QDir().rmdir(blocked);
  } // An unsaved shutdown must leave the original snapshot available.
  check(QFile::exists(source),"Unsaved shutdown deleted recovered work");
  {
    const auto target=directory+"/saved-recovery.cdl";write(target,good);
    Editor editor(&theme);waitFrame(editor);
    check(editor.openPath(target,false),"Cannot open recovery save target");waitFrame(editor);
    answer(QMessageBox::Yes);editor.checkRecovery();
    check(editor.document()==good && QFile::exists(source),"Second recovery lost the original snapshot");
    check(editor.dirty(),"Recovered work should require an explicit save");
    check(editor.save() && !QFile::exists(source),"Successful save did not retire the recovery source");
  }
  write(source,good);
  {
    Editor editor(&theme);waitFrame(editor);
    answer(QMessageBox::Yes);editor.checkRecovery();
    answer(QMessageBox::Discard);editor.newDocument();
    check(!QFile::exists(source),"Explicit discard did not retire the recovered source");
  }
  std::cerr << "Conflicting pins, duplicate wire IDs, failed autosave, repeated recovery and discard passed\n";
}

void checkJunctionRouteStress(Appearance &theme) {
  for(auto kind:{"HA_JUNC_2","HE_JUNC_4"})for(int turns=0;turns<4;++turns)for(int first=0;first<2;++first)for(int last=0;last<2;++last) {
    Editor editor(&theme);
    const QPointF endpoint=turns%2?QPointF(0,12):QPointF(12,0);
    editor.setPlacement(kind);editor.placeAt({0,0});editor.setPlacement(kind);editor.placeAt(endpoint);
    editor.edit("Rotate junctions",[&](auto &doc){for(auto &g:doc.pages[0].gates)g.angle=turns*90;});
    auto gate=makeGate(kind);gate->setGUIParam("angle",std::to_string(turns*90));
    auto pins=gate->getHotspotList();auto a=pins.begin(),b=pins.begin();std::advance(a,first);std::advance(b,last);
    editor.connectPins(editor.pinAt({a->second.x,a->second.y},.01),editor.pinAt({endpoint.x()+b->second.x,endpoint.y()+b->second.y},.01));
    checkWireRoutes(editor);
    for(int i=0;i<40;++i) {
      const auto route=editor.document().pages[0].wires.at(0).segments;
      auto segment=std::find_if(route.begin(),route.end(),[](const auto &seg){return std::hypot(seg.end.x-seg.begin.x,seg.end.y-seg.begin.y)>1;});
      if(segment==route.end()){std::cerr<<"Collapsed junction: "<<kind<<" turns="<<turns<<" first="<<first<<" last="<<last<<" step="<<i<<"\n";QFile bad(qEnvironmentVariable("CEDAR_WIRE_EVIDENCE",QDir::tempPath())+"/collapsed-wire.cdl");if(bad.open(QIODevice::WriteOnly))bad.write(QByteArray::fromStdString(cl::writeCircuitFile(editor.document())));}
      check(segment!=route.end(),"Junction route lost visible segments");
      QPointF middle((segment->begin.x+segment->end.x)/2,(segment->begin.y+segment->end.y)/2);
      check(editor.startWireMove(middle+QPointF(.013,.017),.04),"Junction wire no longer pickable");
      editor.moveWire(middle+(segment->vertical?QPointF((i%7-3)*.5,.017):QPointF(.013,(i%7-3)*.5)));editor.finishWireMove();
      checkWireRoutes(editor);
      if(i%4==0) {
        const auto position=editor.document().pages[0].gates[1].at;
        check(editor.selectAt({position.x,position.y}),"Cannot select junction for move");
        editor.startMove();editor.moveSelected({double(i%3)-1,double(i%5)-2});editor.finishMove();checkWireRoutes(editor);
      }
    }
  }
  {
    Editor editor(&theme);editor.setPlacement("HA_JUNC_2");editor.placeAt({-8,0});editor.setPlacement("HA_JUNC_2");editor.placeAt({8,0});
    editor.connectPins(editor.pinAt({-7,0},.1),editor.pinAt({7,0},.1));
    check(editor.startWireMove({0,0},.1),"Cannot begin interrupted wire drag");
    editor.undo();
    check(editor.document().pages[0].wires.empty(),"Undo did not remove wire during drag");
    editor.moveWire({0,2});editor.finishWireMove();
    check(editor.document().pages[0].wires.empty(),"Interrupted drag restored an undone wire");
  }
  {
    Editor editor(&theme);editor.setPlacement("HA_JUNC_2");editor.placeAt({0,0});editor.setPlacement("HA_JUNC_2");editor.placeAt({0,48});
    editor.edit("Rotate junctions",[&](auto &doc){for(auto &g:doc.pages[0].gates)g.angle=90;});
    editor.connectPins(editor.pinAt({0,1},.01),editor.pinAt({0,47},.01));
    auto collapsed=editor.document();auto &wire=collapsed.pages[0].wires.at(0);
    std::vector<cl::WireConn> endpoints;
    for(const auto &seg:wire.segments)for(const auto &c:seg.connects)endpoints.push_back(c);
    wire.segments.clear();
    int n=0;for(const auto &c:endpoints){cl::WireSegment seg;seg.id=std::to_string(900000+n++);seg.vertical=true;seg.begin=seg.end={0,c.gateUuid==collapsed.pages[0].gates[0].uuid?1.0:47.0};seg.connects.push_back(c);wire.segments.push_back(seg);}
    QTemporaryDir temp;const auto path=temp.filePath("collapsed.cdl");QFile output(path);check(output.open(QIODevice::WriteOnly),"Cannot create collapsed wire fixture");const auto bytes=QByteArray::fromStdString(cl::writeCircuitFile(collapsed));output.write(bytes);output.close();
    Editor reopened(&theme);if(!reopened.openPath(path,false))throw std::runtime_error("Cannot open collapsed wire circuit: "+reopened.status().toStdString());
    check(reopened.dirty(),"Repaired wire was not marked for review and Save");
    check(reopened.document().pages[0].wires[0].ids==wire.ids,"Collapsed route repair changed net identity");
    check(reopened.hasWireAt({0,24},.01),"Saved dot-only wire was not recovered between junctions");
    checkWireRoutes(reopened);
    QFile original(path);check(original.open(QIODevice::ReadOnly)&&original.readAll()==bytes,"Loading a repaired wire overwrote the original file");
  }
  std::cerr<<"1280 junction reroutes and 320 gate moves across pin combinations and rotations passed\n";
}

#include "connection_route_stress.h"

int main(int argc, char **argv) {
  QTemporaryDir temp;
  qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
  qputenv("XDG_DATA_HOME", temp.path().toUtf8());
  QApplication app(argc, argv);
  gateLibrary().libParser =
      LibraryParse(std::string(CEDAR_SOURCE_RES) + "/cl_gatedefs.xml");
  QSettings::setDefaultFormat(QSettings::IniFormat);
  QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, temp.path());
  try {
    {
      QString error;
      auto path = temp.path() + "/locked.cdl";
      auto first = std::make_unique<DocumentLock>();
      check(first->acquire(path, error), "First file lock failed");
      {
        DocumentLock second;
        check(!second.acquire(path, error),
              "Second instance acquired the same circuit");
      }
      first.reset();
      DocumentLock reopened;
      check(reopened.acquire(path, error),
            "Closing a document left its lock behind");
    }
    std::cerr << "File locks passed\n";
    QSettings prefs(QSettings::defaultFormat(),QSettings::UserScope,"CedarLogic","CedarLogic-Qt");
    prefs.setValue("editor/wireColor","Blue"); prefs.setValue("appearance/accent","Blue");
    Appearance theme;
    check(!theme.editorSettings().contains("wireColor") && !prefs.contains("editor/wireColor") && theme.accentName()=="Blue","Removed circuit setting survived or changed the UI accent");
    theme.resetDefaults();
    if(argc==2 && QString(argv[1])=="--junction-stress"){checkOrdinaryConnectionStress(theme);checkJunctionRouteStress(theme);return 0;}
    checkStabilityLoadingAndRecovery(theme,temp.path());
    checkOriginalRouting(theme, temp.path());
    checkMovedSwitchRoute(theme, temp.path());
    checkWireRemoval(theme);
    {
      Editor editor(&theme);
      waitFrame(editor);
      editor.setPlacement("AA_TOGGLE");
      editor.placeAt({-12, 3});
      check(editor.placement().isEmpty(), "Placement remained armed after placing a gate");
      editor.placeAt({99,99});
      check(editor.document().pages[0].gates.size()==1, "Unarmed placement created another gate");
      editor.setPlacement("AA_TOGGLE");
      editor.placeAt({-12, -3});
      editor.setPlacement("AA_AND2");
      editor.placeAt({0, 0});
      editor.setPlacement("");
      auto a = editor.pinAt({-10, 3}, 0.1), b = editor.pinAt({-10, -3}, 0.1),
           in0 = editor.pinAt({-3, 1}, 0.1), in1 = editor.pinAt({-3, -1}, 0.1);
      check(!a.isEmpty() && !b.isEmpty() && !in0.isEmpty() && !in1.isEmpty(),
            "Original pins are not hit-testable");
      editor.connectPins(a, in0);
      editor.connectPins(b, in1);
      waitFrame(editor);
      auto original = editor.document();
      for (const auto &gate : original.pages[0].gates)
        check(std::stoull(gate.uuid) <= 0xffffffffULL,
              "Gate identifier cannot be reopened by the legacy Windows app");
      check(original.pages[0].wires.size() == 2,
            "Two input nets were not created");
      check(cl::readCircuitFile(cl::writeCircuitFile(original)) == original,
            "New circuit is not readable by existing file library");
      editor.setPlacement("GA_LED");
      editor.placeAt({0, 8});
      editor.setPlacement("");
      auto led = editor.pinAt({-2, 8}, 0.2);
      // Use the original library pin position rather than assuming the symbol
      // width.
      auto ledModel = makeGate("GA_LED");
      ledModel->setGLcoords(0, 8);
      auto ledPin = ledModel->getHotspotList().begin()->second;
      led = editor.pinAt({ledPin.x, ledPin.y}, 0.1);
      check(editor.connectPinToWire(led, {-8, 3}, 0.2),
            "Wire branch hit failed");
      waitFrame(editor);
      auto branched = editor.document();
      check(branched.pages[0].wires.size() == 2,
            "Branch created a separate net");
      check(cl::readCircuitFile(cl::writeCircuitFile(branched)) == branched,
            "Branch topology failed round trip");
      editor.undo();
      editor.undo();
      check(editor.document() == original, "Undo branch or placement failed");
      editor.connectPins(a, b);
      waitFrame(editor);
      check(editor.document().pages[0].wires.size() == 1,
            "Joining nets failed");
      check(cl::readCircuitFile(cl::writeCircuitFile(editor.document())) ==
                editor.document(),
            "Joining nets corrupted topology");
      editor.undo();
      check(editor.document() == original, "Undo joining nets failed");
      editor.selectAt({0, 0});
      editor.rotateSelection();
      check(editor.document().pages[0].gates[2].angle == 0,
            "Connected gate rotated despite the legacy restriction");
      check(editor.document() == original,"Blocked rotation changed topology");
      editor.startMove();
      editor.moveSelected({8, 2});
      editor.finishMove();
      auto moved = editor.document();
      check(moved.pages[0].gates[2].at.x == 8, "Gate did not move");
      auto model = makeGate("AA_AND2");
      model->setGLcoords(8, 2);
      for (auto &w : moved.pages[0].wires)
        for (auto &s : w.segments)
          for (auto &c : s.connects)
            if (c.gateUuid == moved.pages[0].gates[2].uuid) {
              auto pin = model->getHotspotList().at(c.pin);
              check(s.vertical ? std::abs(s.begin.x - pin.x) < 0.01
                               : std::abs(s.begin.y - pin.y) < 0.01,
                    "Moving gate detached wire from pin");
            }
      editor.undo();
      check(editor.document() == original,
            "Undo movement did not restore original circuit");
      editor.redo();
      check(editor.document() == moved, "Redo movement changed topology");
      editor.undo();
      editor.selectBox(editor.bounds().adjusted(-1,-1,1,1),false);
      editor.startMove(); editor.moveSelected({-2, 1});
      editor.moveSelected({3, 4}); editor.finishMove();
      auto translated = editor.document();
      for (size_t wi = 0; wi < original.pages[0].wires.size(); ++wi)
        for (size_t si = 0; si < original.pages[0].wires[wi].segments.size(); ++si) {
          const auto &a = original.pages[0].wires[wi].segments[si];
          const auto &b = translated.pages[0].wires[wi].segments[si];
          check(b.begin.x == a.begin.x + 3 && b.begin.y == a.begin.y + 4,
                "Group move changed the authored internal route");
        }
      editor.undo(); check(editor.document() == original, "Group move undo lost the original route");
      editor.selectAll(); editor.copy();
      auto oldClipboard = readClipboard(QApplication::clipboard()->text().toStdString());
      check(oldClipboard.pages[0].gates.size() == 3 && oldClipboard.pages[0].wires.size() == 2,
            "Legacy clipboard lost selected gates or wires");
      editor.paste(true); check(editor.isPastePending(), "Interactive paste committed before placement");
      editor.moveSelected({5, 5}); editor.finishPaste(false);
      check(editor.document() == original, "Cancel paste altered the document");
      editor.selectAll(); editor.copy();
      editor.paste();
      check(editor.document().pages[0].gates.size() == 6,
            "Clipboard paste lost gates");
      check(editor.document().pages[0].wires.size() == 4,
            "Clipboard paste lost internal nets");
      check(cl::readCircuitFile(cl::writeCircuitFile(editor.document())) ==
                editor.document(),
            "Clipboard identifiers are invalid");
      editor.undo();
      check(editor.document() == original, "Undo paste failed");
      editor.selectAt({0, 0});
      editor.deleteSelection();
      check(editor.document().pages[0].gates.size() == 2,
            "Delete selection failed");
      editor.undo();
      check(editor.document() == original, "Undo delete lost wires");
      editor.addPage();
      check(editor.document().pages.size() == 2, "Add page failed");
      editor.undo();
      check(editor.document() == original, "Undo page failed");
      auto results = editor.palette("AND", "does not exist");
      check(!results.isEmpty(), "Search failed across categories");
      check(editor.palette("nonexistent-xyz", " ").isEmpty(),
            "Search returned unexpected gates");
      editor.interactAt({-12, 3});
      check(editor.document().pages[0].gates[0].params.size() > 0,
            "Original toggle is not interactive");
      auto inputId = editor.document().pages[0].gates[0].uuid;
      editor.setPlacement("GA_LED"); editor.placeAt({20, 20});
      editor.interactAt({-12, 3});
      auto inputValue = editor.gateValue(inputId, "OUTPUT_NUM");
      editor.undo();
      check(editor.gateValue(inputId, "OUTPUT_NUM") == inputValue,
            "Structural undo rewound a live input");
      editor.redo();
      check(editor.gateValue(inputId, "OUTPUT_NUM") == inputValue,
            "Structural redo rewound a live input");
    }
    {
      auto path=temp.path()+"/shift-register.cdl";
      const auto handout=qEnvironmentVariable("CEDAR_GROUP_MOVE_HANDOUT",
          QStringLiteral(CEDAR_SOURCE_RES)+"/../qt/shift-register-regression.cdl");
      check(QFile::copy(handout,path),"Cannot copy shift register handout fixture");
      Editor shift(&theme);check(shift.openPath(path,false),"Shift register handout did not open");waitFrame(shift);
      // A marquee selects gates without explicitly selecting their wires.
      // Every internal route must follow the gates, including authored bends.
      const auto beforeMove=shift.document();
      auto checkTranslation=[&](QPointF delta) {
        auto expected=beforeMove.pages[0].wires;
        for(auto &wire:expected) for(auto &segment:wire.segments) {
          segment.begin.x+=delta.x(); segment.end.x+=delta.x();
          segment.begin.y+=delta.y(); segment.end.y+=delta.y();
          for(auto &crossing:segment.intersections)
            crossing.at+=segment.vertical?delta.y():delta.x();
        }
        check(shift.document().pages[0].wires==expected,
              "Box-dragging the handout left internal wire geometry anchored");
      };
      shift.selectBox(shift.bounds().adjusted(-1,-1,1,1),false);
      shift.startMove(); shift.moveSelected({3.5,-4.5});checkTranslation({3.5,-4.5});
      shift.moveSelected({-2,6});checkTranslation({-2,6});
      shift.cancelMove();
      check(shift.document()==beforeMove,"Cancelling a handout group move changed its routes");
      shift.startMove();shift.moveSelected({3.5,-4.5});shift.finishMove();
      checkTranslation({3.5,-4.5});
      const auto afterMove=shift.document();
      shift.undo();check(shift.document()==beforeMove,"Handout group move undo changed its routes");
      shift.redo();check(shift.document()==afterMove,"Handout group move redo changed its routes");
      shift.undo();
      advance(shift,20);
      std::cerr << "Handout initial values " <<shift.gateValue("49","CURRENT_VALUE").toStdString()<<","<<shift.gateValue("59","CURRENT_VALUE").toStdString()<<"\n";
      check(shift.interactAt({-3,-18}),"Page 1 data switch did not respond");
      advance(shift,10);
      check(shift.interactAt({-3.5,-27.5}),"Page 1 clock pulse did not respond");advance(shift,10);
      check(shift.gateValue("49","CURRENT_VALUE")=="1","First clock did not latch page 1 input");
      check(shift.interactAt({-3,-18}),"Page 1 data switch did not toggle back");advance(shift,10);
      check(shift.interactAt({-3.5,-27.5}),"Repeated clock pulse did not respond");advance(shift,10);
      std::cerr<<"Handout repeated pulse "<<shift.gateValue("49","CURRENT_VALUE").toStdString()<<","<<shift.gateValue("59","CURRENT_VALUE").toStdString()<<"\n";
      check(shift.gateValue("49","CURRENT_VALUE")=="0" && shift.gateValue("59","CURRENT_VALUE")=="1","Repeated clock did not shift previous bit");
      auto rendered=shift.circuitImage(600,true,false);
      auto wire=shift.document().pages[0].wires[0].ids[0];auto state=shift.wireState(wire);
      shift.setCurrentPage(1);shift.setCurrentPage(0);
      check(shift.wireState(wire)==state,"Paused page changes discarded wire state");
      check(shift.circuitImage(600,true,false)==rendered,"Page changes changed the paused circuit image");
      auto exported=cl::readLegacyCdl(legacyExport(shift.document(),2,0));
      check(exported.pages.size()==shift.document().pages.size(),"V2 export lost pages");
      check(exported.pages[0].gates.size()==shift.document().pages[0].gates.size() && exported.pages[0].wires==shift.document().pages[0].wires,"V2 export lost wire topology");
      check(cl::detectFormat(legacyExport(shift.document(),1,0))==cl::SourceFormat::XmlV1,"V1 export has the wrong format");
      auto feeds=shift.availableSignals();check(!feeds.isEmpty(),"No scope feeds found in handout");
      shift.addScopeFeed(feeds[0]);check(shift.traces().size()==1,"Scope could not add a feed");
      check(shift.saveScopeLayout(temp.path()+"/feeds.cdo"),"Scope layout save failed");shift.removeScopeFeed(0);
      check(shift.loadScopeLayout(temp.path()+"/feeds.cdo")&&shift.scopeFeeds().size()==1,"Legacy scope layout did not restore feeds");
      shift.setScopePaused(true);auto frozen=shift.traces();advance(shift,3);check(shift.traces()==frozen,"Scope pause did not freeze recording");shift.setScopePaused(false);

      for(const auto &p:shift.document().pages)for(const auto &g:p.gates)for(const auto &v:g.params)check(v.name!="PULSE","Pulse event persisted in circuit");
    }
    {
      Editor links(&theme); waitFrame(links);
      links.setPlacement("AA_TOGGLE"); links.placeAt({0, 0});
      links.setPlacement("DA_FROM"); links.placeAt({8, 0});
      links.connectPins(links.pinAt({2, 0}, .1), links.pinAt({10, 0}, .1));
      links.selectAt({8, 0});
      auto before = links.document(); links.convertToFrom(true);
      auto after = links.document();
      check(after.pages[0].gates[1].libName == "DE_TO", "FROM conversion failed");
      check(links.gateValue(after.pages[0].gates[1].uuid, "JUNCTION_ID") == "F",
            "TO conversion lost the implicit junction label");
      bool endpoint = false;
      for (const auto &segment : after.pages[0].wires[0].segments)
        for (const auto &connection : segment.connects)
          if (connection.gateUuid == after.pages[0].gates[1].uuid)
            endpoint = segment.begin.y == 0 && segment.begin.x <= 6 && segment.end.x >= 6;
      check(endpoint, "TO conversion left the wire at the old FROM pin");
      links.undo(); check(links.document() == before, "TO conversion undo lost its route");
      check(links.availableSignals() == QStringList{"F"},
            "Scope lost the default FROM name");
      int signalUpdates = 0;
      auto signalConnection = QObject::connect(&links, &Editor::availableSignalsChanged,
                                               [&] { ++signalUpdates; });
      check(links.applyParameters({{"logic:JUNCTION_ID", "ScopeName"}}) &&
                links.availableSignals() == QStringList{"ScopeName"} && signalUpdates == 1,
            "Scope did not publish a renamed junction");
      links.addScopeFeed("ScopeName");
      advance(links, 3);
      check(signalUpdates == 1 && links.availableSignals() == QStringList{"ScopeName"},
            "Simulation frames unnecessarily republished the signal selector");
      check(links.applyParameters({{"logic:JUNCTION_ID", ""}}), "Cannot clear junction name");
      const auto fallback = "Wire " + QString::fromStdString(links.document().pages[0].wires[0].ids[0]);
      check(links.availableSignals() == QStringList{fallback} && links.scopeFeeds().isEmpty(),
            "Unnamed junction lost its fallback wire name or retained a stale feed");
      links.undo();
      check(links.availableSignals() == QStringList{"ScopeName"}, "Undo lost scope names");
      QObject::disconnect(signalConnection);
    }
    {
      Editor colors(&theme);waitFrame(colors);
      colors.setPlacement("AA_TOGGLE");colors.placeAt({-8,0});
      colors.setPlacement("AA_AND2");colors.placeAt({0,0});
      colors.connectPins(colors.pinAt({-6,0},.1),colors.pinAt({-3,1},.1));
      advance(colors,10);theme.setMode("light");
      auto original=colors.circuitImage(600,true,false);
      auto blackWhite=colors.circuitImage(600,false,false);
      for (auto accent : {"Teal","Blue","Purple","Orange","Green","Rose"}) {
        auto options=theme.editorSettings(); options["wireColor"]="Purple";
        theme.apply(theme.mode(),accent,options);
        check(colors.circuitImage(600,true,false)==original,"UI accent or retired preference recolored the circuit");
        check(colors.circuitImage(600,false,false)==blackWhite,"UI accent changed monochrome export");
        check(!theme.editorSettings().contains("wireColor"),"Retired preference returned through Apply");
      }
      colors.interactAt({-8,0});advance(colors,10);
      const auto high=colors.circuitImage(600,true,false);
      theme.setAccentName("Teal");
      check(colors.circuitImage(600,true,false)==high,"UI accent recolored a driven signal");
      colors.interactAt({-8,0});advance(colors,10);
      check(colors.circuitImage(600,true,false)==original,"Circuit did not return to its original signal rendering");
    }
    {
      Editor xorCircuit(&theme); waitFrame(xorCircuit);
      for (const auto &gate : std::vector<std::pair<QString,QPointF>>{
          {"AA_TOGGLE",{-12,3}}, {"AA_TOGGLE",{-12,-3}}, {"AI_XOR2",{0,0}}, {"GA_LED",{12,0}}}) {
        xorCircuit.setPlacement(gate.first); xorCircuit.placeAt(gate.second);
      }
      auto led = makeGate("GA_LED"); led->setGLcoords(12,0);
      auto pin = led->getHotspotList().begin()->second;
      xorCircuit.connectPins(xorCircuit.pinAt({-10,3},.1),xorCircuit.pinAt({-3,1},.1));
      xorCircuit.connectPins(xorCircuit.pinAt({-10,-3},.1),xorCircuit.pinAt({-3,-1},.1));
      xorCircuit.connectPins(xorCircuit.pinAt({3,0},.1),xorCircuit.pinAt({pin.x,pin.y},.1));
      waitFrame(xorCircuit);
      // Reproduce the screenshot: paused drivers draw 0/1 before wire events run.
      xorCircuit.interactAt({-12,-3}); waitFrame(xorCircuit);
      const auto nets=xorCircuit.document().pages[0].wires;
      check(xorCircuit.wireState(nets[0].ids[0])==HI_Z && xorCircuit.wireState(nets[1].ids[0])==HI_Z,
            "Paused circuit unexpectedly advanced its drivers");
      std::cerr << "Reproduced paused 0/1 XOR with green non-driven wires\n";
      auto waitStates = [&](StateType a, StateType b, StateType out) {
        QEventLoop loop; QTimer poll; poll.setInterval(5);
        auto matches=[&]{return xorCircuit.wireState(nets[0].ids[0])==a &&
            xorCircuit.wireState(nets[1].ids[0])==b && xorCircuit.wireState(nets[2].ids[0])==out;};
        QObject::connect(&poll,&QTimer::timeout,&loop,[&]{if(matches())loop.quit();});
        QTimer::singleShot(3000,&loop,&QEventLoop::quit); poll.start(); if(!matches())loop.exec();
        check(matches(),"Running XOR failed to propagate without manual steps");
      };
      xorCircuit.setRunning(true); waitStates(ZERO,ONE,ONE);
      xorCircuit.interactAt({-12,3}); waitStates(ONE,ONE,ZERO);
      xorCircuit.interactAt({-12,-3}); waitStates(ONE,ZERO,ONE);
      xorCircuit.interactAt({-12,3}); waitStates(ZERO,ZERO,ZERO);
      const auto saved=temp.path()+"/running-xor.cdl";
      QFile output(saved); check(output.open(QIODevice::WriteOnly),"Cannot save XOR regression");
      output.write(QByteArray::fromStdString(cl::writeCircuitFile(xorCircuit.document()))); output.close();
      Editor reopened(&theme); waitFrame(reopened); reopened.setRunning(true);
      check(reopened.openPath(saved,false) && reopened.running(),"Opening a circuit stopped a running simulation");
      xorCircuit.setRunning(false);
      QEventLoop settle; QTimer::singleShot(100,&settle,&QEventLoop::quit); settle.exec();
      const auto stoppedTime=xorCircuit.simulationTime();
      QEventLoop paused; QTimer::singleShot(100,&paused,&QEventLoop::quit); paused.exec();
      check(xorCircuit.simulationTime()==stoppedTime && xorCircuit.status()=="Paused","Pause did not freeze time or identify its state");
      advance(xorCircuit,1);
      check(xorCircuit.simulationTime()==stoppedTime+1,"Paused Step advanced more than one tick");
      reopened.setRunning(false);
      check(reopened.openPath(saved,false) && !reopened.running(),"Opening a circuit ignored explicit Pause");
      reopened.setRunning(true); reopened.newDocument();
      check(reopened.running(),"New document unexpectedly stopped simulation");
      std::cerr << "Live XOR truth table, open/new run state, pause and step passed\n";
    }
    // Test all decoder symbols through the actual frontend simulation plan,
    // including the legacy chip's inverted pins and undo of an absent parameter.
    for (auto name : {"BA_DECODER_2x4", "BE_DECODER_3x8", "BI_DECODER_4x16", "3x8 Decoder Chip"}) {
      Editor decoder(&theme); waitFrame(decoder);
      decoder.setPlacement(name); decoder.placeAt({0,0});
      auto owner=gateLibrary().gateNameToLibrary.at(name);
      const auto &def=gateLibrary().libraries.at(owner).at(name);
      std::vector<std::pair<int,std::string>> nets;
      for (const auto &pin : def.hotspots) if (!pin.isInput) {
        // Separate LEDs so their extra junction pins cannot auto-connect.
        const auto x=24+6*std::stoi(pin.name.substr(4));
        decoder.setPlacement("GA_LED"); decoder.placeAt({double(x),pin.y});
        auto led=makeGate("GA_LED"); led->setGLcoords(x,pin.y);
        auto target=led->getHotspotList().begin()->second;
        decoder.connectPins(decoder.pinAt({pin.x,pin.y},.1), decoder.pinAt({target.x,target.y},.1));
        nets.push_back({std::stoi(pin.name.substr(4)),decoder.document().pages[0].wires.back().ids[0]});
      }
      for(const auto &pin:def.hotspots) if(pin.isInput && pin.name.rfind("IN_",0)==0) {
        decoder.setPlacement("AA_TOGGLE"); decoder.placeAt({-24,pin.y});
        decoder.connectPins(decoder.pinAt({-22,pin.y},.1),decoder.pinAt({pin.x,pin.y},.1));
      }
      waitFrame(decoder); advance(decoder,10);
      check(decoder.selectEditableAt({0,0}),"Decoder does not offer double-click properties");
      auto fields=decoder.parameterFields();
      const auto original=decoder.document();
      const QString normal=QString(name)=="3x8 Decoder Chip"?"LOW":"HIGH";
      check(fields.size()==1 && fields[0].toMap()["value"]==normal,"Legacy decoder default changed");
      auto checkOutputs=[&](const QString &polarity) {
        for (const auto &net : nets) {
          const auto expected=((net.first==0)!=(polarity=="LOW")?ONE:ZERO);
          if(decoder.wireState(net.second)!=expected)
            std::cerr << name << " polarity " << polarity.toStdString() << " OUT_" << net.first << " got " << int(decoder.wireState(net.second)) << " expected " << int(expected) << " at " << decoder.simulationTime() << '\n';
          check(decoder.wireState(net.second)==expected,"Decoder outputs do not match the chosen polarity");
        }
      };
      checkOutputs(normal);
      check(!decoder.applyParameters({{"logic:OUTPUT_POLARITY","invalid"}}) && decoder.document()==original,
            "Invalid decoder polarity changed the circuit");
      const QString changed=normal=="HIGH"?"LOW":"HIGH";
      check(decoder.applyParameters({{"logic:OUTPUT_POLARITY",changed}}),"Cannot change decoder polarity");
      advance(decoder,10); checkOutputs(changed);
      decoder.undo(); advance(decoder,10);
      check(decoder.document()==original,"Undo decoder polarity did not remove the new setting"); checkOutputs(normal);
      decoder.redo(); advance(decoder,10); checkOutputs(changed);
      const auto saved=temp.filePath(QString(name)+"-polarity.cdl");
      QFile out(saved); check(out.open(QIODevice::WriteOnly),"Cannot write decoder circuit");
      out.write(QByteArray::fromStdString(cl::writeCircuitFile(decoder.document()))); out.close();
      check(cl::readCircuitFile(cl::writeCircuitFile(decoder.document()))==decoder.document(),"Decoder parameter failed file roundtrip");
      Editor reopened(&theme); waitFrame(reopened); check(reopened.openPath(saved,false),"Cannot reopen decoder circuit");
      waitFrame(reopened); advance(reopened,10); reopened.selectEditableAt({0,0});
      check(reopened.parameterFields()[0].toMap()["value"]==changed,"Reopened decoder lost its polarity");
      for(const auto &net:nets)
        check(reopened.wireState(net.second)==((net.first==0)!=(changed=="LOW")?ONE:ZERO),"Reopened decoder output has wrong polarity");
      const auto after=reopened.document();
      for(size_t i=0;i<original.pages[0].wires.size();++i)
        check(original.pages[0].wires[i]==after.pages[0].wires[i],"Polarity setting changed a wire route");
    }
    std::cerr << "All decoder defaults, connected outputs, polarity edits, undo/redo and save/reopen passed\n";
    std::cerr << "Editing workflows passed\n";
    for (auto filename :
         QDir(QStringLiteral(CEDAR_SOURCE_RES) + "/../format/tests/fixtures")
             .entryList({"*.cdl"}, QDir::Files)) {
      QString path = temp.path() + "/" + filename;
      QFile::copy(QStringLiteral(CEDAR_SOURCE_RES) +
                      "/../format/tests/fixtures/" + filename,
                  path);
      Editor fixture(&theme);
      check(fixture.openPath(path, false),
            "Existing circuit fixture did not open");
      waitFrame(fixture);
      check(fixture.status().startsWith("Paused"), "Fixture simulation failed");
      check(cl::readCircuitFile(cl::writeCircuitFile(fixture.document())) ==
                fixture.document(),
            "Fixture geometry or topology changed on save");
    }
    std::cout << "Gate placement, pins, wiring, rotation, move routing, "
                 "undo/redo, clipboard, deletion, pages and search passed\n";
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
