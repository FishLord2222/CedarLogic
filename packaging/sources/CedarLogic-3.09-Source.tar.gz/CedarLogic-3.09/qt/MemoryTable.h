#pragma once
#include "guiGate.h"
#include <QAbstractTableModel>
#include <QColor>
#include <functional>
class MemoryTable : public QAbstractTableModel {
public:
  MemoryTable(int addressBits, int dataBits,
              std::function<guiGateRAM *()> getter,
              std::function<void(unsigned long, unsigned long)> setter,
              QObject *parent = nullptr)
      : QAbstractTableModel(parent), addresses(1 << qBound(1, addressBits, 16)),
        addressDigits((qBound(1, addressBits, 16) + 3) / 4),
        dataBits(qBound(1, dataBits, 32)), getter(std::move(getter)),
        setter(std::move(setter)) {}
  int rowCount(const QModelIndex &parent = {}) const override {
    return parent.isValid() ? 0 : (addresses + 15) / 16;
  }
  int columnCount(const QModelIndex &parent = {}) const override {
    return parent.isValid() ? 0 : qMin(16, addresses);
  }
  QVariant headerData(int section, Qt::Orientation orientation,
                      int role) const override {
    if (role != Qt::DisplayRole) return {};
    if (orientation == Qt::Horizontal)
      return QString::number(section, 16).toUpper();
    return "0x" + QString::number(section, 16).toUpper()
                      .rightJustified(qMax(0, addressDigits - 1), '0') + "X";
  }
  QVariant data(const QModelIndex &index, int role) const override {
    if (!index.isValid()) return {};
    auto ram = getter();
    if (!ram) return {};
    const auto address = index.row() * 16 + index.column();
    if (role == Qt::DisplayRole || role == Qt::EditRole) {
      auto text = QString::number(ram->getValueAt(address), decimal ? 10 : 16).toUpper();
      return decimal ? text : text.rightJustified((dataBits + 3) / 4, '0');
    }
    const bool read = ram->getLastRead() == address;
    const bool written = ram->getLastWritten() == address;
    if (role == Qt::BackgroundRole && (read || written))
      return QColor(read ? Qt::green : Qt::red);
    if (role == Qt::ForegroundRole && (read || written)) return QColor(Qt::black);
    if (role == Qt::TextAlignmentRole) return int(Qt::AlignCenter);
    return {};
  }
  Qt::ItemFlags flags(const QModelIndex &index) const override {
    if (!index.isValid() || !getter()) return Qt::NoItemFlags;
    return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
  }
  bool setData(const QModelIndex &index, const QVariant &value, int role) override {
    if (role != Qt::EditRole || !index.isValid() || !getter()) return false;
    bool ok = false;
    const auto n = value.toString().toULongLong(&ok, decimal ? 10 : 16);
    const quint64 max = dataBits == 32 ? 0xffffffffULL : ((1ULL << dataBits) - 1);
    if (!ok || n > max) return false;
    setter(index.row() * 16 + index.column(), n);
    emit dataChanged(index, index);
    return true;
  }
  void setDecimal(bool value) { decimal = value; refresh(); }
  void refresh() {
    if (addresses) emit dataChanged(index(0, 0), index(rowCount() - 1, columnCount() - 1));
  }
private:
  int addresses, addressDigits, dataBits;
  bool decimal = false;
  std::function<guiGateRAM *()> getter;
  std::function<void(unsigned long, unsigned long)> setter;
};
