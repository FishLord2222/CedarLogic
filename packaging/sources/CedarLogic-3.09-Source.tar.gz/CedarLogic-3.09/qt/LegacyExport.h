#pragma once
#include "SharedModel.h"
#include "XMLParser.h"
#include <sstream>
#include <set>
// Retain the legacy tag syntax and escaping, including gate-side connections
// required by the original application, not only the modern loader.
inline std::string legacyExport(const cl::CircuitFile &file,int version,int currentPage) {
  std::ostringstream out;
  if(version==2) out<<"<circuit><CurrentPage>0</CurrentPage><page 0><gate><ID>0</ID><type>AA_LABEL</type><position>0,0</position><gparam>LABEL_TEXT This circuit requires CedarLogic 2 or newer.</gparam><gparam>TEXT_HEIGHT 2</gparam></gate></page 0></circuit><throw_away></throw_away><version><version>2.4.3</version></version>";
  XMLParser xml(&out);
  auto tag=[&](std::string name,std::string value){xml.openTag(name);xml.writeTag(name,value);xml.closeTag(name);};
  auto number=[](double value){std::ostringstream s;s.precision(17);s<<value;return s.str();};
  xml.openTag("circuit");tag("CurrentPage",std::to_string(currentPage));
  for(size_t index=0;index<file.pages.size();++index) {
    const auto &page=file.pages[index];auto pageTag="page "+std::to_string(index);xml.openTag(pageTag);
    for(const auto &gate:page.gates) {
      auto model=makeGate(gate.libName);
      for(const auto &p:gate.params) if(p.gui)model->setGUIParam(p.name,p.value);else model->setLogicParam(p.name,p.value);
      xml.openTag("gate");tag("ID",gate.uuid);tag("type",gate.libName);tag("position",number(gate.at.x)+","+number(gate.at.y));
      std::set<std::string> seen;
      for(const auto &wire:page.wires) for(const auto &segment:wire.segments) for(const auto &conn:segment.connects)
        if(conn.gateUuid==gate.uuid && seen.insert(conn.pin).second) {
          auto kind=model->isConnectionInput(conn.pin)?"input":"output";xml.openTag(kind);tag("ID",conn.pin);
          std::string wires;for(const auto &id:wire.ids){wires+=id+" ";if(version==1)break;}xml.writeTag(kind,wires);xml.closeTag(kind);
        }
      for(auto param:*model->getAllGUIParams())if(param.first!="angle")tag("gparam",param.first+" "+param.second);
      tag("gparam","angle "+number(gate.angle));
      for(auto param:*model->getAllLogicParams())if(param.first!="PULSE" && param.first!="READ_FILE" && param.first!="WRITE_FILE" && param.first!="MemoryReset" && param.first!="PAUSE_SIM")tag("lparam",param.first+" "+param.second);
      std::vector<std::pair<std::string,std::string>> memory;model->getTypeSpecificParams(memory);for(auto param:memory)tag("lparam",param.first+" "+param.second);
      xml.closeTag("gate");
    }
    for(const auto &wire:page.wires) {
      xml.openTag("wire");std::string ids;for(const auto &id:wire.ids){ids+=id+" ";if(version==1)break;}tag("ID",ids);xml.openTag("shape");
      for(const auto &seg:wire.segments) {
        auto name=seg.vertical?"vsegment":"hsegment";xml.openTag(name);tag("ID",seg.id);tag("points",number(seg.begin.x)+","+number(seg.begin.y)+","+number(seg.end.x)+","+number(seg.end.y));
        for(auto conn:seg.connects){xml.openTag("connection");tag("GID",conn.gateUuid);tag("name",conn.pin);xml.closeTag("connection");}
        for(auto x:seg.intersections)tag("intersection",number(x.at)+" "+x.segment);
        xml.closeTag(name);
      }
      xml.closeTag("shape");xml.closeTag("wire");
    }
    xml.closeTag(pageTag);
  }
  xml.closeTag("circuit");return out.str();
}
