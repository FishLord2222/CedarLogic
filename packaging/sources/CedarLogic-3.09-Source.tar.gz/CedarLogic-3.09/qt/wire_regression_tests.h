// Integration checks for junction routing, rendered wires and theme changes.
#include "circuit_file_io.hpp"
inline void checkJunctionWireRegressions(Appearance &theme, const QString &directory) {
  const int requestedCycles=qEnvironmentVariableIntValue("CEDAR_WIRE_THEME_CYCLES");
  const int cycles=requestedCycles>0?qBound(1,requestedCycles,100):24;
  int switchCount=0;

  const auto originalOptions=theme.editorSettings();auto options=originalOptions;options["grid"]=false;theme.apply(theme.mode(),theme.accentName(),options);
  for(int turns=0;turns<4;++turns)for (const auto &kind : {"HA_JUNC_2", "HE_JUNC_4"}) {
    for (QPointF destination : {QPointF(12,0),QPointF(0,12),QPointF(12,8),QPointF(-12,-8),QPointF(0,48),QPointF(0,500),QPointF(500,0)}) {
      Editor editor(&theme);editor.setRunning(true);
      editor.setPlacement(kind);editor.placeAt({0,0});editor.setPlacement(kind);editor.placeAt(destination);editor.setPlacement("");
      editor.edit("Rotate junctions",[&](auto &doc){for(auto &gate:doc.pages[0].gates)gate.angle=turns*90;});
      auto rotate=[&](QPointF p){for(int i=0;i<turns;++i)p={-p.y(),p.x()};return p;};
      auto before=editor.document();
      const auto a=editor.pinAt(rotate({1,0}),.1), b=editor.pinAt(destination+rotate({-1,0}),.1);
      check(!a.isEmpty() && !b.isEmpty(),"Junction pin not found");
      QQuickWindow window;window.resize(600,400);
      Canvas canvas(window.contentItem());canvas.setWidth(600);canvas.setHeight(400);canvas.setAppearance(&theme);canvas.setEditor(&editor);canvas.fit();
      check(canvas.visibleWorld().contains(editor.bounds()),"Fit clipped a long-distance circuit");
      window.show();check(QTest::qWaitForWindowExposed(&window),"Junction test window did not expose");
      auto screenPoint=[&](const QVariantMap &pin) {auto center=canvas.visibleWorld().center();auto scale=canvas.zoom()*12;return QPointF(300+(pin["x"].toDouble()-center.x())*scale,200-(pin["y"].toDouble()-center.y())*scale).toPoint();};
      QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,screenPoint(a));
      QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,screenPoint(b));
      auto connected=editor.document();
      check(connected.pages[0].wires.size()==1 && !connected.pages[0].wires[0].segments.empty(),"Junction connection lost route");
      canvas.fit();
      for(int iteration=0;iteration<cycles;++iteration){
        ++switchCount;theme.setSessionMode(iteration%2?"dark":"light");
        QTest::qWait(15);
        check(editor.document()==connected,"Theme switch altered circuit topology");
        const auto image=canvas.renderImage(600,400,false);
        const auto screen=window.grabWindow();
        check(!screen.isNull() && screen.pixelColor(0,0)==image.pixelColor(0,0),"Visible canvas retained a stale theme");
        auto noWire=connected;noWire.pages[0].wires.clear();editor.restore(noWire,connected);
        const auto empty=canvas.renderImage(600,400,false);editor.restore(connected,noWire);
        int changed=0;
        for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x)if(image.pixel(x,y)!=empty.pixel(x,y))++changed;
        if(changed<15) {
          image.save(directory+"/junction-missing-wire.png");
          std::cerr<<kind<<" destination "<<destination.x()<<","<<destination.y()<<" iteration "<<iteration<<" changed pixels "<<changed<<'\n';
        }
        check(changed>=15,"Connected junction wire is invisible");
        // Sample the wire itself, away from junction dots and gate bodies.
        bool visible=false;auto center=canvas.visibleWorld().center();auto scale=canvas.zoom()*12;
        for(const auto &segment:connected.pages[0].wires[0].segments) {
          if(std::hypot(segment.end.x-segment.begin.x,segment.end.y-segment.begin.y)<3)continue;
          const int px=qRound(300+((segment.begin.x+segment.end.x)/2-center.x())*scale);
          const int py=qRound(200-((segment.begin.y+segment.end.y)/2-center.y())*scale);
          for(int y=py-2;y<=py+2;++y)for(int x=px-2;x<=px+2;++x)
            if(screen.rect().contains(x,y) && screen.pixelColor(x,y)!=screen.pixelColor(0,0))visible=true;
        }
        check(visible,"Live canvas cache lost the visible wire after a theme change");
      }
      editor.undo();check(editor.document()==before,"Junction wire undo failed");editor.redo();check(editor.document()==connected,"Junction wire redo failed");
      auto path=directory+QString("/junction-%1-%2-%3.cdl").arg(kind).arg(destination.x()).arg(destination.y());
      QFile output(path);check(output.open(QIODevice::WriteOnly),"Cannot save junction circuit");
      output.write(QByteArray::fromStdString(cl::writeCircuitFile(connected)));output.close();
      Editor reopened(&theme);check(reopened.openPath(path,false),"Cannot reload junction circuit");
      check(cl::writeCircuitFile(reopened.document())==cl::writeCircuitFile(connected),"Junction route changed after save/reload");
      for(const auto &g:connected.pages[0].gates){auto model=makeGate(g.libName);model->setGUIParam("angle",std::to_string(g.angle));model->setGLcoords(g.at.x,g.at.y);for(auto pin:model->getHotspotList())check(pin.second.x==std::round(pin.second.x*2)/2 && pin.second.y==std::round(pin.second.y*2)/2,"Quarter-turn rotation moved junction pins off their grid");}
    }
  }
  {
    Editor editor(&theme);editor.setPlacement("HA_JUNC_2");editor.placeAt({-8,0});editor.setPlacement("HA_JUNC_2");editor.placeAt({8,0});
    editor.connectPins(editor.pinAt({-7,0},.1),editor.pinAt({7,0},.1));
    QQuickWindow window;window.resize(600,400);Canvas canvas(window.contentItem());canvas.setWidth(600);canvas.setHeight(400);canvas.setAppearance(&theme);canvas.setEditor(&editor);canvas.fit();
    window.show();check(QTest::qWaitForWindowExposed(&window),"Interrupted drag test window did not expose");
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,{300,200});
    QTest::mouseMove(&window,{300,250});QTest::qWait(20);
    canvas.ungrabMouse();
    auto interrupted=canvas.renderImage(600,400,false);
    editor.cancelMove();
    auto cancelled=canvas.renderImage(600,400,false);
    check(interrupted==cancelled,"Losing the mouse grab leaves an unfinished wire route visible");
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,{300,250});
  }
  theme.setSessionMode("");
  theme.apply(theme.mode(),theme.accentName(),originalOptions);
  std::cerr<<"Junction routes, visible pixels across "<<switchCount<<" theme switches, undo/redo and save/reload passed\n";
}
