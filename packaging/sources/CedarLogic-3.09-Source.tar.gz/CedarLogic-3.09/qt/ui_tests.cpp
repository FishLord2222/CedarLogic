#include "Appearance.h"
#include "Canvas.h"
#include "Editor.h"
#include "GateLibrary.h"
#include "Keyboard.h"
#include "Settings.h"
#include "render/SkiaProbe.h"
#include <QApplication>
#include <QElapsedTimer>
#include <QClipboard>
#include <QDialog>
#include <QFileDialog>
#include <QCheckBox>
#include <QComboBox>
#include <QAbstractItemView>
#include <QPushButton>
#include <QProcess>
#include <QMessageBox>
#include <QTableView>
#include <QTimer>
#include <QWheelEvent>
#include <QPointingDevice>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QTemporaryDir>
#include <QTest>
#include <iostream>
#include <cmath>
#include <stdexcept>
void check(bool value, const char *message) { if (!value) throw std::runtime_error(message); }
QQuickItem *visibleItem(QQuickItem *root, const QString &name, bool requireVisible = true) {
  if (root->objectName() == name && (!requireVisible || root->isVisible())) return root;
  for (auto *child : root->childItems())
    if (auto *found = visibleItem(child, name, requireVisible)) return found;
  return nullptr;
}
// Check the rendered overlay rather than its implementation: it must be a
// continuous straight line anchored at the pin and ending at the live cursor.
void checkConnectionPreview(Appearance &theme) {
  Editor editor(&theme);
  editor.setPlacement("AA_TOGGLE"); editor.placeAt({-12,3});
  editor.setPlacement("AA_AND2"); editor.placeAt({0,0});
  const auto original=editor.document();
  // Leave room outside the canvas, like the sidebar/status bar in the app.
  QQuickWindow window; window.resize(660,440);
  auto canvas=new Canvas(window.contentItem());
  canvas->setWidth(600); canvas->setHeight(400);
  canvas->setEditor(&editor); canvas->setAppearance(&theme);
  window.show(); check(QTest::qWaitForWindowExposed(&window),"Wire-preview window did not expose");
  canvas->fit(); canvas->forceActiveFocus(); QTest::qWait(80);
  auto point=[&](QPointF world) {
    auto center=canvas->visibleWorld().center(); auto scale=canvas->zoom()*12;
    return QPointF(canvas->width()/2+(world.x()-center.x())*scale,
                   canvas->height()/2-(world.y()-center.y())*scale);
  };
  auto green=[](QColor color) { return color.green()>110 && color.green()>color.red()+60 && color.green()>color.blue()+60; };
  auto greenCount=[&] {
    auto image=window.grabWindow(); int count=0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x)if(green(image.pixelColor(x,y)))++count;
    return count;
  };
  auto red=[](QColor color) { return color.red()>120 && color.red()>color.green()+70 && color.red()>color.blue()+70; };
  auto redCount=[&] {
    QTest::qWait(60); auto image=window.grabWindow(); int count=0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x)if(red(image.pixelColor(x,y)))++count;
    return count;
  };
  auto markerAt=[&](QPointF anchor) {
    QTest::qWait(60); auto image=window.grabWindow();
    auto ratio=window.devicePixelRatio(); anchor*=ratio; int count=0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x) {
      if(!red(image.pixelColor(x,y)))continue;
      ++count;
      check(std::abs(x+.5-anchor.x())<=4*ratio && std::abs(y+.5-anchor.y())<=4*ratio,
            "Red interaction marker is detached from its hotspot or changes size with zoom");
    }
    check(count>8,"Red interaction marker is missing");
  };
  auto straight=[&](QPointF cursor) {
    QTest::qWait(60); const auto image=window.grabWindow();
    const auto ratio=window.devicePixelRatio();
    const auto start=point({-10,3})*ratio, end=cursor*ratio, d=end-start;
    const auto length=std::hypot(d.x(),d.y()); int count=0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x) {
      if(!green(image.pixelColor(x,y)))continue;
      ++count; auto p=QPointF(x+.5,y+.5)-start;
      check(std::abs(p.x()*d.y()-p.y()*d.x())/length<=2*ratio,"Connection preview bends instead of following a straight line");
      const auto along=(p.x()*d.x()+p.y()*d.y())/length;
      check(along>=-2*ratio && along<=length+2*ratio,"Connection preview extends beyond the pin or cursor");
    }
    check(count>15,"Connection preview is missing or has the wrong original color");
    for(int sample=0;sample<=10;++sample) {
      const auto p=start+d*(sample/10.0); bool found=false;
      for(int y=qRound(p.y())-2;y<=qRound(p.y())+2;++y)
        for(int x=qRound(p.x())-2;x<=qRound(p.x())+2;++x)
          if(image.rect().contains(x,y) && green(image.pixelColor(x,y)))found=true;
      check(found,"Connection preview is dashed, stale or detached from its endpoint");
    }
    check(editor.document()==original,"Preview changed the document before connection");
  };
  for(auto mode:{"light","dark"}) {
    theme.setSessionMode(mode); canvas->fit(); QTest::qWait(60);
    check(greenCount()==0,"Unconnected scene unexpectedly contains a preview");
    auto source=(point({-10,3})+QPointF(3,1)).toPoint();
    auto cursor=point({-2,-3}).toPoint();
    QTest::mouseMove(&window,source); markerAt(point({-10,3}));
    check(editor.document()==original,"Hover marker changed the circuit");
    editor.setEditingLocked(true); check(redCount()==0,"Locked circuit still shows an editing hotspot");
    editor.setEditingLocked(false); markerAt(point({-10,3}));
    editor.setPlacement("AA_AND2"); check(redCount()==0,"Component placement leaves a misleading wire hotspot");
    editor.setPlacement(""); QTest::mouseMove(&window,source); markerAt(point({-10,3}));
    editor.selectAt({-12,3}); editor.deleteSelection();
    check(redCount()==0,"Deleting the hovered gate leaves a ghost hotspot");
    editor.undo(); markerAt(point({-10,3}));
    QTest::mouseMove(&window,cursor); check(redCount()==0,"Moving off a pin leaves a ghost hotspot");
    // A held drag is finished on release, even if no connection was made.
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); straight(cursor);
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,cursor); QTest::qWait(60);
    check(greenCount()==0 && editor.document()==original,"Releasing over empty space leaves a lingering connection preview");
    QTest::mouseMove(&window,point({-2,5}).toPoint()); QTest::qWait(60);
    check(greenCount()==0,"An unsuccessful drag restarts when the mouse moves");
    const QPoint outside(630,420);
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,outside); QTest::qWait(60);
    check(greenCount()==0 && redCount()==0,"Wire drag leaves an overlay outside the canvas");
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,outside);
    QTest::mouseMove(&window,cursor); QTest::qWait(60);
    check(greenCount()==0 && editor.document()==original,"Releasing outside the canvas leaves a lingering preview");
    // Crossing the edge while still holding may resume and connect on return.
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,outside); QTest::mouseMove(&window,point({-3,-1}).toPoint());
    straight(point({-3,-1}).toPoint()); markerAt(point({-3,-1}));
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,point({-3,-1}).toPoint());
    check(editor.document().pages[0].wires.size()==1,"Returning inside during a held drag cannot connect");
    editor.undo(); QTest::qWait(60);
    // Returning to the source must not turn a completed drag into click mode.
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); QTest::mouseMove(&window,source);
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); QTest::qWait(60);
    check(greenCount()==0 && editor.document()==original,"Drag returning to its source leaves a lingering preview");
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); straight(cursor);
    canvas->ungrabMouse(); QTest::qWait(60);
    check(greenCount()==0,"Losing the mouse grab leaves a lingering preview");
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,cursor);
    // A click gesture can suspend outside, then resume without becoming stale.
    QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); straight(cursor);
    QTest::mouseMove(&window,outside); QTest::qWait(60);
    check(greenCount()==0,"Click-to-connect preview lingers outside the canvas");
    QTest::mouseMove(&window,cursor); straight(cursor);
    QTest::keyClick(&window,Qt::Key_Escape); QTest::qWait(60);
    check(greenCount()==0 && editor.document()==original,"Boundary checks changed the circuit or left a preview");
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,cursor); straight(cursor);
    window.grabWindow().save(QString("CedarLogic-3.08-wire-drag-%1.png").arg(mode));
    QTest::keyClick(&window,Qt::Key_Escape);
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,cursor);QTest::qWait(60);
    check(greenCount()==0 && editor.document()==original,"Escape did not cancel the wire preview");
    // Click then move without a held button: hover events must update the line.
    QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,source);
    cursor=point({-2,5}).toPoint();QTest::mouseMove(&window,cursor);straight(cursor);
    canvas->zoomBy(1.15); straight(cursor);
    const auto target=point({-3,-1}).toPoint();
    QTest::mouseMove(&window,target); straight(target); markerAt(point({-3,-1}));
    window.grabWindow().save(QString("CedarLogic-3.08-pin-highlight-%1.png").arg(mode));
    QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,target);QTest::qWait(80);
    check(editor.document().pages[0].wires.size()==1,"Click connection did not create the original routed wire");
    const auto connected=editor.document(); bool checkedWire=false;
    for(const auto &segment:connected.pages[0].wires[0].segments) {
      QPointF a(segment.begin.x,segment.begin.y), b(segment.end.x,segment.end.y);
      if(std::hypot(a.x()-b.x(),a.y()-b.y())<2)continue;
      auto middle=point((a+b)/2).toPoint();
      QTest::mouseMove(&window,middle); markerAt(middle);
      check(editor.document()==connected,"Wire hover changed the connection");
      // Drag from a pixel offset, rather than the exact grid crossing. The
      // committed route must not inherit that fractional press coordinate.
      const auto pressPoint=middle+QPoint(2,2);
      const auto releasePoint=point((a+b)/2+QPointF(3.17,4.19)).toPoint();
      QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,pressPoint);
      QTest::mouseMove(&window,releasePoint);
      QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,releasePoint);QTest::qWait(60);
      check(!(editor.document()==connected),"Actual mouse wire drag did not move the segment");
      for(const auto &net:editor.document().pages[0].wires)
        for(const auto &routed:net.segments)
          for(auto coordinate:{routed.begin.x,routed.begin.y,routed.end.x,routed.end.y})
            check(std::abs(coordinate*2-std::round(coordinate*2))<1e-5,"Actual mouse drag committed an off-grid wire");
      window.grabWindow().save(QString("CedarLogic-3.08-routing-%1.png").arg(mode));
      editor.undo();QTest::qWait(60);
      check(editor.document()==connected,"Actual wire drag undo changed the connection");
      checkedWire=true;break;
    }
    check(checkedWire,"No wire segment available to check the red drag indicator");
    editor.undo();QTest::qWait(60);
    check(redCount()==0,"Removing the hovered wire leaves a ghost drag indicator");
    check(editor.document()==original && greenCount()==0,"Completed click connection left a ghost preview");
    source=(point({-10,3})+QPointF(3,1)).toPoint();
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,target);straight(target);markerAt(point({-3,-1}));
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,target);QTest::qWait(80);
    check(editor.document().pages[0].wires.size()==1,"Drag-release did not create the original routed wire");
    editor.undo();QTest::qWait(60);
    check(editor.document()==original && greenCount()==0,"Completed drag left a ghost preview");
  }
  theme.setSessionMode("");
  std::cerr << "Straight green preview and red indicators, canvas boundaries, invalid release, lost grab, hover, drag, zoom, lock, deletion, cancel and commit passed in both themes\n";
}
void checkBlueConnections(Appearance &theme) {
  Editor editor(&theme);
  editor.setPlacement("AA_TOGGLE"); editor.placeAt({-12,-5});
  editor.setPlacement("AA_AND2"); editor.placeAt({0,0});
  const auto original = editor.document();
  QQuickWindow window; window.resize(660,440);
  auto canvas = new Canvas(window.contentItem());
  canvas->setWidth(600); canvas->setHeight(400);
  canvas->setEditor(&editor); canvas->setAppearance(&theme);
  window.show(); check(QTest::qWaitForWindowExposed(&window),"Blue-preview window did not expose");
  canvas->fit(); canvas->forceActiveFocus();
  auto point = [&](QPointF world) {
    const auto center = canvas->visibleWorld().center(); const auto scale = canvas->zoom()*12;
    return QPointF(canvas->width()/2+(world.x()-center.x())*scale,
                   canvas->height()/2-(world.y()-center.y())*scale);
  };
  auto blue = [](QColor c) { return c.blue()>150 && c.blue()>c.red()+60 && c.blue()>c.green()+60; };
  auto blueCount = [&] {
    QTest::qWait(60); const auto image = window.grabWindow(); int count = 0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x)
      if(blue(image.pixelColor(x,y))) ++count;
    return count;
  };
  auto ringAt = [&](QPointF world) {
    QTest::qWait(60); const auto image = window.grabWindow();
    const auto ratio = window.devicePixelRatio(); const auto anchor = point(world)*ratio;
    int count = 0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x) {
      if(!blue(image.pixelColor(x,y))) continue;
      const auto distance = std::hypot(x+.5-anchor.x(),y+.5-anchor.y());
      check(distance>=5*ratio && distance<=9*ratio,"Blue connection ring is misplaced or changes size with zoom");
      ++count;
    }
    check(count>20,"Blue connection ring is missing");
  };
  for(auto mode:{"light","dark"}) {
    theme.setSessionMode(mode); canvas->fit();
    const auto source = point({-10,-5}).toPoint(); const auto target = point({-3,1}).toPoint();
    QTest::mouseMove(&window,target);
    check(blueCount()==0,"Idle pin incorrectly promises a connection");
    QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,source);
    QTest::mouseMove(&window,target); ringAt({-3,1});
    check(editor.document()==original,"Blue target preview edits the circuit");
    canvas->zoomBy(1.2);
    QTest::mouseMove(&window,point({-3,1}).toPoint()); ringAt({-3,1});
    window.grabWindow().save(QString("CedarLogic-3.08-blue-connection-%1.png").arg(mode));
    QTest::mouseMove(&window,point({-10,-5}).toPoint());
    check(blueCount()==0,"Source pin is shown as a valid target for itself");
    QTest::mouseMove(&window,point({-3,1}).toPoint()); ringAt({-3,1});
    QTest::mouseMove(&window,{630,420}); check(blueCount()==0,"Blue target lingers outside canvas");
    QTest::mouseMove(&window,point({-3,1}).toPoint()); ringAt({-3,1});
    editor.setEditingLocked(true); check(blueCount()==0,"Locked canvas still shows a blue target");
    editor.setEditingLocked(false); check(blueCount()==0,"Unlocking revives a canceled connection");

    // The sidebar ghost and a moved gate use the same snapped free-pin pairs
    // that will actually connect when placement/movement commits.
    editor.setPlacement("AA_TOGGLE");
    QTest::mouseMove(&window,point({-5,1}).toPoint()); ringAt({-3,1});
    check(editor.document()==original,"Placement connection ring commits a ghost gate");
    QTest::mouseMove(&window,point({-5,2}).toPoint());
    check(blueCount()==0,"Moving the ghost off a pin leaves a blue ring");
    QTest::keyClick(&window,Qt::Key_Escape); check(blueCount()==0,"Cancel leaves a placement ring");
    editor.selectAt({-12,-5}); editor.startMove(); editor.moveSelected({7,6});
    QTest::mouseMove(&window,point({-5,1}).toPoint()); ringAt({-3,1});
    check(editor.document().pages[0].wires.empty(),"Move preview connects before release");
    editor.cancelMove(); check(blueCount()==0,"Cancel leaves a moved-gate ring");
    check(editor.document()==original,"Canceled preview changes geometry");
    auto start = editor.pinAt({-10,-5},.1);
    auto wrongWidth = start; wrongWidth["bits"] = 4;
    check(editor.connectionTarget(wrongWidth,{-3,1},.1).isEmpty(),"Mismatched bus width is shown as a valid target");
    editor.selectAt({-12,-5}); editor.startMove(); editor.moveSelected({7,6});
    editor.finishMove();
    check(editor.document().pages[0].wires.size()==1,"Blue automatic preview does not match the committed connection");
    check(editor.connectionTarget(editor.pinAt({-3,1},.1),{-3,1},.1).isEmpty(),"Existing net is shown as a new connection");
    editor.undo(); check(editor.document()==original,"Automatic connection undo loses original circuit");
    QTest::qWait(60);
  }
  theme.setSessionMode("");
  std::cerr << "Blue rings: valid targets, snapped placement and moved gates, zoom, both themes, boundaries, lock, cancel, bus widths, commit and undo passed\n";
}
void checkOverview(Appearance &theme) {
  Editor editor(&theme);editor.setRunning(false);
  editor.setPlacement("AA_TOGGLE");editor.placeAt({-30,0});
  editor.setPlacement("AA_AND2");editor.placeAt({30,0});
  editor.connectPins(editor.pinAt({-28,0},.1),editor.pinAt({27,1},.1));
  QTest::qWait(100); // Capture the initial paused frame, not its pending load.
  const auto document=editor.document();const auto time=editor.simulationTime();
  QQuickWindow window;window.resize(900,650);
  Canvas main(window.contentItem()),map(window.contentItem());
  main.setWidth(640);main.setHeight(440);main.setEditor(&editor);main.setAppearance(&theme);
  map.setX(655);map.setY(475);map.setWidth(230);map.setHeight(130);
  map.setEditor(&editor);map.setAppearance(&theme);map.setOverview(true);map.setMainCanvas(&main);
  window.show();check(QTest::qWaitForWindowExposed(&window),"Overview window did not expose");
  auto point=[&](QPointF pixel) {return map.mapToScene(pixel).toPoint();};
  auto worldAt=[&](QPointF pixel) {
    const auto box=map.visibleWorld();
    return QPointF(box.left()+pixel.x()*box.width()/map.width(),box.bottom()-pixel.y()*box.height()/map.height());
  };
  auto contains=[&] {
    const auto box=map.visibleWorld().adjusted(-.001,-.001,.001,.001);
    check(box.contains(editor.bounds()) && box.contains(main.visibleWorld()),
          "Overview omits the circuit or main viewport after navigation");
    check(std::isfinite(box.width()) && std::isfinite(box.height()) && box.width()>0 && box.height()>0,
          "Overview has a non-finite or empty projection");
    check(std::abs(box.width()/box.height()-map.width()/map.height())<.001,
          "Overview stretches the original circuit geometry");
  };
  auto fresh=[&] {
    QTest::qWait(80);contains();
    const auto ratio=window.devicePixelRatio();const auto origin=map.mapToScene({0,0})*ratio;
    const int w=qRound(map.width()*ratio),h=qRound(map.height()*ratio);
    const auto actual=window.grabWindow().copy(qRound(origin.x()),qRound(origin.y()),w,h);
    const auto expected=map.renderImage(w,h,false);
    check(!actual.isNull() && !expected.isNull(),"Overview did not render");
    // Compare the painted/cache layer with a fresh thumbnail, excluding only
    // the accent viewport frame drawn over it. A stale camera-fit cache fails.
    const auto fit=map.visibleWorld(),view=main.visibleWorld();
    const double left=(view.left()-fit.left())*w/fit.width(),right=(view.right()-fit.left())*w/fit.width();
    const double top=(fit.bottom()-view.bottom())*h/fit.height(),bottom=(fit.bottom()-view.top())*h/fit.height();
    int mismatch=0;
    for(int y=0;y<h;++y)for(int x=0;x<w;++x) {
      if(((std::abs(x-left)<=3*ratio || std::abs(x-right)<=3*ratio) && y>=top-3*ratio && y<=bottom+3*ratio) ||
         ((std::abs(y-top)<=3*ratio || std::abs(y-bottom)<=3*ratio) && x>=left-3*ratio && x<=right+3*ratio))continue;
      const auto a=actual.pixelColor(x,y),b=expected.pixelColor(x,y);
      if(std::abs(a.red()-b.red())>2 || std::abs(a.green()-b.green())>2 || std::abs(a.blue()-b.blue())>2)++mismatch;
    }
    check(mismatch<10,"Overview viewport frame and cached circuit use different projections");
  };
  for(auto mode:{"light","dark"}) {
    theme.setSessionMode(mode);main.fit();main.zoomBy(8);main.forceActiveFocus();QTest::qWait(80);
    const auto stable=map.renderImage(230,130,false);
    QTest::keyClick(&window,Qt::Key_Right);QTest::qWait(60);
    check(map.renderImage(230,130,false)==stable,"Overview zooms into the main view instead of retaining the whole circuit");
    main.zoomBy(1.0/32);fresh();
    for(int i=0;i<20;++i)QTest::keyClick(&window,Qt::Key_Right);
    for(int i=0;i<12;++i)QTest::keyClick(&window,Qt::Key_Up);
    fresh();
    window.grabWindow().save(QString("CedarLogic-3.08-overview-panned-%1.png").arg(mode));
    const auto zoom=main.zoom();const QPointF click(qRound(map.width()*.45),qRound(map.height()*.55));
    const auto target=worldAt(click);
    QTest::mouseClick(&window,Qt::LeftButton,Qt::NoModifier,point(click));QTest::qWait(60);
    check((main.visibleWorld().center()-target).manhattanLength()<.005 && main.zoom()==zoom,
          "Overview click does not center the selected world position at the existing zoom");
    check(main.hasActiveFocus(),"Overview navigation steals the main canvas keyboard focus");
    QTest::mousePress(&window,Qt::LeftButton,Qt::NoModifier,point({map.width()/2,map.height()/2}));QTest::qWait(60);
    const QPointF drag(qRound(map.width()*.75),qRound(map.height()*.25));const auto dragTarget=worldAt(drag);
    QTest::mouseMove(&window,point(drag));QTest::qWait(60);
    check((main.visibleWorld().center()-dragTarget).manhattanLength()<.005 && main.zoom()==zoom,
          "Holding and dragging the overview does not continuously navigate");
    QTest::mouseRelease(&window,Qt::LeftButton,Qt::NoModifier,point(drag));fresh();
    const auto beforeRight=main.visibleWorld();
    QTest::mouseClick(&window,Qt::RightButton,Qt::NoModifier,point({10,10}));
    check(main.visibleWorld()==beforeRight,"Non-left map clicks unexpectedly pan the main view");
    main.setWidth(600);main.setHeight(420);map.setWidth(200);map.setHeight(140);fresh();
    check(editor.document()==document,"Overview navigation edits the circuit");
    check(editor.simulationTime()==time,"Overview navigation advances paused simulation");
    main.setWidth(640);main.setHeight(440);map.setWidth(230);map.setHeight(130);
  }
  editor.addPage();editor.setPlacement("AA_TOGGLE");editor.placeAt({200,-100});QTest::qWait(80);fresh();
  editor.setCurrentPage(0);QTest::qWait(80);fresh();
  theme.setSessionMode("");
  std::cerr<<"Overview full-circuit/viewport fit, cache sync, zoom, pan, drag, resize, focus and page switching passed in both themes\n";
}
int main(int argc, char **argv) {
  QTemporaryDir tmp;
  qputenv("XDG_CONFIG_HOME", tmp.path().toUtf8());
  qputenv("QSG_RENDER_LOOP", "basic");
  QQuickStyle::setStyle("Basic");
  QApplication app(argc, argv);
  app.setOrganizationName("CedarLogicTests");
  app.setOrganizationDomain("io.github.emonte_cu");
  app.setApplicationName("UI");
  // Isolate both app and QML settings on Windows as well as Linux.
  QSettings::setDefaultFormat(QSettings::IniFormat);
  QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, tmp.path());
  const bool verifySidebarRestart=argc == 4 && QString::fromLocal8Bit(argv[1]) == "--verify-sidebar-names";
  if (verifySidebarRestart)
    QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, QString::fromLocal8Bit(argv[2]));
  try {
    appConfig().resourcesDir = CEDAR_SOURCE_RES;
    gateLibrary().libParser = LibraryParse(std::string(CEDAR_SOURCE_RES) + "/cl_gatedefs.xml");
    cl::render::setFontSearchDir((std::string(CEDAR_SOURCE_RES) + "/../").c_str());
    if (!verifySidebarRestart) {
      GateImages cached, uncached(0);
      const QSize requested(96, 96);
      for (const auto &id : {"AA_TOGGLE/light", "BA_DECODER_2x4/dark", "GA_LED/light"}) {
        QSize actual;
        const auto first = cached.requestImage(id, &actual, requested);
        const auto baseline = uncached.requestImage(id, nullptr, requested);
        check(!first.isNull() && first == baseline && actual == requested,
              "Thumbnail cache changed the original symbol pixels or dimensions");
        check(cached.requestImage(id, nullptr, requested).cacheKey() == first.cacheKey(),
              "Repeated thumbnails are being rasterized again");
        const auto otherSize = cached.requestImage(id, nullptr, {112, 112});
        check(otherSize.size() == QSize(112,112) && otherSize.cacheKey() != first.cacheKey(),
              "Thumbnail cache confuses different requested sizes");
      }
      const auto light = cached.requestImage("AA_TOGGLE/light", nullptr, requested);
      check(light != cached.requestImage("AA_TOGGLE/dark", nullptr, requested),
            "Thumbnail cache confuses light and dark symbols");
      QElapsedTimer timer;
      timer.start();
      for (int i=0; i<100; ++i) uncached.requestImage("AA_TOGGLE/light",nullptr,requested);
      const auto uncachedNs = timer.nsecsElapsed();
      timer.restart();
      for (int i=0; i<100; ++i) cached.requestImage("AA_TOGGLE/light",nullptr,requested);
      std::cerr << "100 repeated thumbnails: uncached " << uncachedNs / 1000000.0
                << " ms, cached " << timer.nsecsElapsed() / 1000000.0 << " ms\n";
    }
    Appearance theme;
    Editor editor(&theme);
    Keyboard keyboard;
    QQmlApplicationEngine engine;
    qmlRegisterType<Canvas>("CedarLogic", 1, 0, "CircuitCanvas");
    qmlRegisterType<Waveforms>("CedarLogic", 1, 0, "Waveforms");
    qmlRegisterUncreatableType<Editor>("CedarLogic",1,0,"Editor","Test-owned");
    qmlRegisterUncreatableType<Appearance>("CedarLogic",1,0,"Appearance","Test-owned");
    engine.rootContext()->setContextProperty("backend", &editor);
    engine.rootContext()->setContextProperty("theme", &theme);
    engine.rootContext()->setContextProperty("keyboard", &keyboard);
    engine.rootContext()->setContextProperty("releaseVersion", "3.08");
    engine.addImageProvider("gates", new GateImages);
    engine.addImageProvider("icons", new Icons);
    engine.load(QUrl("qrc:/qml/Main.qml"));
    check(!engine.rootObjects().isEmpty(), "UI failed to load");
    auto window = qobject_cast<QQuickWindow *>(engine.rootObjects()[0]);
    keyboard.setWindow(window);
    check(QTest::qWaitForWindowExposed(window), "UI did not expose");
    if (verifySidebarRestart) {
      QTest::qWait(80);
      const bool enabled=QString::fromLocal8Bit(argv[3]) == "1";
      auto parts=window->findChild<QQuickItem *>("sidebarParts");
      auto command=window->findChild<QQuickItem *>("sidebarNamesMenuCommand");
      check(parts && parts->property("showNames").toBool()==enabled,
            "Restarted sidebar does not display the saved on/off state");
      check(command && command->property("checked").toBool()==enabled,
            "Restarted View checkbox does not display the saved on/off state");
      check(bool(visibleItem(window->contentItem(),"sidebarPartName0"))==enabled,
            "Restarted sidebar caption visibility differs from the saved state");
      QMetaObject::invokeMethod(window,"openPreferences");
      auto prefs=window->findChild<QObject *>("preferencesDialog");
      check(prefs,"Restarted Preferences is missing");prefs->setProperty("section",1);
      QTest::qWait(80);
      auto checkbox=window->findChild<QQuickItem *>("sidebarNamesPreference");
      check(checkbox && checkbox->property("checked").toBool()==enabled,
            "Restarted Preferences checkbox does not display the saved state");
      window->grabWindow().save(QString("CedarLogic-3.08-sidebar-restart-%1.png").arg(enabled?"on":"off"));
      return 0;
    }
    auto canvas = window->findChild<Canvas *>("circuitCanvas");
    check(canvas && canvas->hasActiveFocus(), "Circuit does not receive initial keyboard focus");
    auto overview=window->findChild<Canvas *>("circuitOverview");
    check(overview && overview->overview() && overview->mainCanvas()==canvas,
          "Sidebar overview is not connected to the active main canvas");
    auto key = [&](Qt::Key key, Qt::KeyboardModifiers modifiers = Qt::NoModifier) {
      QTest::keyClick(window, key, modifiers);
      QCoreApplication::processEvents();
    };
    auto sidebarParts=window->findChild<QQuickItem *>("sidebarParts");
    auto namesMenu=window->findChild<QQuickItem *>("sidebarNamesMenuCommand");
    auto sidebarViewMenu=window->findChild<QObject *>("viewMenu");
    check(sidebarParts && namesMenu && sidebarViewMenu,"Sidebar-name controls are missing");
    auto toggleNames=[&] {
      QMetaObject::invokeMethod(sidebarViewMenu,"open");QTest::qWait(60);
      QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,
        namesMenu->mapToScene({namesMenu->width()/2,namesMenu->height()/2}).toPoint());
      QTest::qWait(60);
    };
    auto verifyRestart=[&](bool enabled) {
      QProcess process;
      process.start(QCoreApplication::applicationFilePath(),
                    {"--verify-sidebar-names", tmp.path(), enabled ? "1" : "0"});
      const bool finished=process.waitForFinished(15000);
      if(!finished || process.exitStatus()!=QProcess::NormalExit || process.exitCode()!=0)
        std::cerr<<process.readAllStandardError().constData();
      check(finished && process.exitStatus()==QProcess::NormalExit && process.exitCode()==0,
            "Rendered sidebar-name choice changed in a fresh process");
    };
    check(!theme.editorSettings()["sidebarNames"].toBool() && !visibleItem(window->contentItem(),"sidebarPartName0"),
          "Fresh launch does not hide sidebar names");
    verifyRestart(false);
    toggleNames();
    check(theme.editorSettings()["sidebarNames"].toBool(),"Cannot enable sidebar names from the default off state");
    verifyRestart(true);
    auto categoryCombo=window->findChild<QQuickItem *>("categoryCombo");
    check(categoryCombo,"Category dropdown is missing");
    for(auto mode:{"light","dark"}) {
      theme.setSessionMode(mode);
      QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,categoryCombo->mapToScene({categoryCombo->width()/2,categoryCombo->height()/2}).toPoint());
      key(Qt::Key_Down);QTest::qWait(70);
      auto option=visibleItem(window->contentItem(),"comboOption1");
      check(option && option->property("highlighted").toBool(),"Category popup does not highlight keyboard selection");
      auto content=qvariant_cast<QQuickItem *>(option->property("contentItem"));
      check(content && content->property("color").value<QColor>()==theme.text(),"Highlighted dropdown text has the wrong theme contrast");
      window->grabWindow().save(QString("CedarLogic-3.08-category-popup-%1.png").arg(mode));
      key(Qt::Key_Escape);
    }
    theme.setSessionMode("");
    auto labelSearch=window->findChild<QQuickItem *>("gateSearch");
    for(auto mode:{"light","dark"}) {
      theme.setSessionMode(mode);QTest::qWait(60);
      auto label=visibleItem(window->contentItem(),"sidebarPartName0");
      auto image=visibleItem(window->contentItem(),"sidebarPartImage0");
      check(label && image && label->property("text").toString()==editor.palette("",editor.categories()[0])[0].toMap()["caption"].toString(),
        "Sidebar does not display the actual part caption");
      check(image->mapToScene({0,image->height()}).y()<=label->mapToScene({0,0}).y(),
        "Sidebar name overlaps the part symbol");
      check(label->width()>80 && label->height()<=32,"Sidebar-name tile is too cramped or oversized");
      QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,label->mapToScene({label->width()/2,label->height()/2}).toPoint());
      check(editor.placement()==editor.palette("",editor.categories()[0])[0].toMap()["name"].toString(),"Clicking a part name cannot select its symbol");
      editor.setPlacement("");
      window->grabWindow().save(QString("CedarLogic-3.08-sidebar-names-%1.png").arg(mode));
      toggleNames();
      check(!theme.editorSettings()["sidebarNames"].toBool() && !visibleItem(window->contentItem(),"sidebarPartName0"),
        "View toggle does not hide sidebar names immediately");
      verifyRestart(false);
      check(std::abs(sidebarParts->property("cellWidth").toDouble()*4-sidebarParts->width())<.1,
        "Hiding sidebar names does not restore the compact four-column palette");
      QTest::qWait(140);
      auto preview = visibleItem(window->contentItem(), "sidebarDragPreview0", false);
      check(preview && preview->property("source").toUrl().isEmpty(),
            "Inactive sidebar drag previews still load gate images");
      const auto originalWidth = sidebarParts->width();
      const auto stableSize = sidebarParts->property("thumbnailSize").toSize();
      for (int i=0; i<12; ++i) sidebarParts->setWidth(originalWidth + i + 1);
      check(sidebarParts->property("thumbnailSize").toSize() == stableSize,
            "Sidebar resizing redraws thumbnails on every width change");
      QTest::qWait(140);
      check(sidebarParts->property("thumbnailSize").toSize().width() ==
            std::max(16,int(std::round((sidebarParts->property("cellWidth").toDouble()-18)*2))),
            "Sidebar thumbnails do not refresh at the final layout size");
      sidebarParts->setWidth(originalWidth);
      QTest::qWait(140);
      toggleNames();
      check(theme.editorSettings()["sidebarNames"].toBool() && visibleItem(window->contentItem(),"sidebarPartName0"),
        "View toggle does not restore sidebar names");
      verifyRestart(true);
      labelSearch->setProperty("text","RAM");QTest::qWait(60);
      label=visibleItem(window->contentItem(),"sidebarPartName0");
      check(label && label->property("text").toString()==editor.palette("RAM","")[0].toMap()["caption"].toString(),
        "Filtered sidebar names do not follow fuzzy search results");
      labelSearch->setProperty("text","");QTest::qWait(60);
    }
    theme.setSessionMode("");
    {
      Appearance reopened;
      check(reopened.editorSettings()["sidebarNames"].toBool(),"Sidebar-name choice did not persist");
    }
    std::cerr<<"Sidebar default off, actual menu toggles, fresh-process persistence, captions and search passed in both themes\n";
    theme.setSidebarNames(false);
    QTest::qWait(160);
    auto part = visibleItem(window->contentItem(), "sidebarPartImage0");
    check(part, "Compact sidebar has no draggable part");
    const auto start = part->mapToScene({part->width()/2, part->height()/2}).toPoint();
    const auto drop = canvas->mapToScene({canvas->width()/2, canvas->height()/2}).toPoint();
    const auto beforeDrop = editor.document().pages[0].gates.size();
    QTest::mousePress(window, Qt::LeftButton, Qt::NoModifier, start);
    QTest::mouseMove(window, start + QPoint(24, 0), 30);
    QTest::qWait(30);
    auto dragPreview = visibleItem(window->contentItem(), "sidebarDragPreview0");
    check(dragPreview && !dragPreview->property("source").toUrl().isEmpty(),
          "Lazy sidebar preview does not appear during a drag");
    QTest::mouseMove(window, drop, 30);
    QTest::qWait(60);
    check(!dragPreview->isVisible() && dragPreview->property("source").toUrl().isEmpty(),
          "Sidebar icon overlaps the canvas placement preview");
    check(!editor.placement().isEmpty(), "Hiding the icon cancels canvas placement");
    window->grabWindow().save("CedarLogic-3.08-sidebar-drag-canvas.png");
    QTest::mouseMove(window, start + QPoint(24, 0), 30);
    QTest::qWait(40);
    check(dragPreview->isVisible() && !dragPreview->property("source").toUrl().isEmpty(),
          "Sidebar icon does not return when dragging back out of the canvas");
    QTest::mouseMove(window, drop, 30);
    QTest::mouseRelease(window, Qt::LeftButton, Qt::NoModifier, drop);
    QTest::qWait(80);
    check(editor.document().pages[0].gates.size() == beforeDrop + 1 && editor.placement().isEmpty(),
          "Sidebar drag no longer places exactly one gate");
    check(dragPreview->property("source").toUrl().isEmpty(),
          "Sidebar preview stays loaded after dragging");
    editor.undo();
    theme.setSidebarNames(true);
    std::cerr << "Compact sidebar lazy preview, one-gate drop, cleanup and undo passed\n";
    // Exercise the actual editor prompts: cancel/Escape preserve the document,
    // Enter saves through the default button, and Discard permits closing.
    for (auto mode : {"light", "dark"}) {
      theme.setSessionMode(mode);
      Editor prompts(&theme);
      auto path=tmp.filePath(QString("prompt-%1.cdl").arg(mode));
      check(QFile::copy(QString(CEDAR_SOURCE_RES)+"/../format/tests/fixtures/lab6.cdl",path),"Cannot prepare saved prompt fixture");
      check(prompts.openPath(path,false),"Cannot open prompt fixture");
      prompts.setPlacement("AA_TOGGLE");prompts.placeAt({100,100});
      const auto document=prompts.document();
      bool styled=false;
      auto interact=[&](QMessageBox::StandardButton answer, bool escape=false, bool enter=false) {
        styled=false;
        window->requestActivate();QTest::qWait(40);
        QTimer::singleShot(100,[&,answer,escape,enter] {
          auto dialog=qobject_cast<QMessageBox *>(QApplication::activeModalWidget());
          if(!dialog)return;
          styled=dialog->objectName()=="cedarMessageDialog" &&
              dialog->palette().color(QPalette::Window)==theme.panel() &&
              dialog->windowHandle()->transientParent()==window &&
              !dialog->styleSheet().isEmpty() && !dialog->iconPixmap().isNull();
          for(auto button:dialog->buttons())styled=styled && button->icon().isNull();
          if(dialog->windowTitle()=="Unsaved circuit") {
            styled=styled && dialog->defaultButton()==dialog->button(QMessageBox::Save);
            dialog->grab().save(QString("CedarLogic-3.08-save-prompt-%1.png").arg(mode));
          } else dialog->grab().save(QString("CedarLogic-3.08-warning-%1.png").arg(mode));
          if(escape)QTest::keyClick(dialog,Qt::Key_Escape);
          else if(enter)QTest::keyClick(dialog,Qt::Key_Return);
          else if(auto button=dialog->button(answer))QTest::mouseClick(button,Qt::LeftButton);
          else dialog->reject();
        });
      };
      window->requestActivate();QTest::qWait(40);
      interact(QMessageBox::Cancel);
      check(!prompts.confirmClose() && styled && prompts.document()==document && prompts.dirty(),"Styled Cancel lost edits or dialog styling");
      interact(QMessageBox::Cancel,true);
      check(!prompts.confirmClose() && styled && prompts.document()==document,"Escape does not cancel the save prompt");
      interact(QMessageBox::Save,false,true);
      check(prompts.confirmClose() && styled && !prompts.dirty(),"Enter does not save using the default button");
      auto savedPath=tmp.filePath(QString("saved-prompt-%1.cdl").arg(mode));
      check(QFile::copy(path,savedPath),"Cannot copy saved prompt result");
      Editor saved(&theme);check(saved.openPath(savedPath,false) && saved.document().pages[0].gates.size()==document.pages[0].gates.size(),"Save prompt did not write the circuit");
      prompts.setPlacement("AA_TOGGLE");prompts.placeAt({110,100});
      interact(QMessageBox::Discard);
      check(prompts.confirmClose() && styled,"Discard does not permit closing");
      interact(QMessageBox::Ok);
      check(!saved.openPath(tmp.filePath("missing.cdl"),true) && styled,"Error warning did not use the themed prompt");
    }
    theme.setSessionMode("");canvas->forceActiveFocus();window->requestActivate();QTest::qWait(40);
    std::cerr<<"Themed save/error prompts, text-only buttons, ownership, Cancel, Escape, default Enter/Save and Discard passed in both themes\n";
    key(Qt::Key_T, Qt::ControlModifier);
    check(editor.document().pages.size() == 2, "Ctrl+T did not add a page");
    key(Qt::Key_Z, Qt::ControlModifier);
    check(editor.document().pages.size() == 1, "Ctrl+Z did not undo");
    key(Qt::Key_Z, Qt::ControlModifier | Qt::ShiftModifier);
    check(editor.document().pages.size() == 2, "Ctrl+Shift+Z did not redo");
    key(Qt::Key_W, Qt::ControlModifier);
    check(editor.document().pages.size() == 1, "Ctrl+W did not close the page");
    key(Qt::Key_Z, Qt::ControlModifier);
    key(Qt::Key_Z, Qt::ControlModifier);
    key(Qt::Key_Y, Qt::ControlModifier);
    check(editor.document().pages.size() == 2, "Ctrl+Y did not redo");
    auto center = canvas->visibleWorld().center();
    key(Qt::Key_Right);
    check(canvas->visibleWorld().center().x() > center.x(), "Right arrow did not pan");
    key(Qt::Key_Left); key(Qt::Key_Up);
    check(canvas->visibleWorld().center().y() > center.y(), "Up arrow did not pan");
    key(Qt::Key_Down);
    check((canvas->visibleWorld().center()-center).manhattanLength() < 0.001, "Arrow panning is inconsistent");
    auto zoom = canvas->zoom();
    key(Qt::Key_Equal); check(canvas->zoom() > zoom, "Equal key did not zoom");
    key(Qt::Key_Minus); check(std::abs(canvas->zoom()-zoom) < 0.001, "Minus key did not zoom out");
    key(Qt::Key_Equal, Qt::ControlModifier); check(canvas->zoom() > zoom, "Ctrl+= did not zoom");
    key(Qt::Key_0, Qt::ControlModifier);
    editor.setPlacement("AA_TOGGLE"); editor.placeAt({0,0}); key(Qt::Key_Escape);
    check(editor.placement().isEmpty(), "Escape did not cancel placement");
    key(Qt::Key_A, Qt::ControlModifier); key(Qt::Key_R);
    check(editor.document().pages[editor.currentPage()].gates[0].angle == 270, "R did not rotate selection");
    key(Qt::Key_C, Qt::ControlModifier); key(Qt::Key_V, Qt::ControlModifier);
    check(editor.document().pages[editor.currentPage()].gates.size() == 2, "Clipboard shortcuts failed");
    check(editor.isPastePending(),"Paste did not enter placement mode");
    editor.finishPaste(true);
    key(Qt::Key_Delete);
    check(editor.document().pages[editor.currentPage()].gates.size() == 1, "Delete did not remove pasted selection");
    key(Qt::Key_Z, Qt::ControlModifier);
    check(editor.document().pages[editor.currentPage()].gates.size() == 2, "Undo delete failed");
    key(Qt::Key_A, Qt::ControlModifier);key(Qt::Key_X, Qt::ControlModifier);
    check(editor.document().pages[editor.currentPage()].gates.empty(), "Ctrl+X did not cut circuit selection");
    key(Qt::Key_Z, Qt::ControlModifier);
    check(editor.document().pages[editor.currentPage()].gates.size() == 2, "Undo cut failed");
    key(Qt::Key_Space);
    check(canvas->visibleWorld().contains(editor.bounds()), "Space did not fit the circuit");
    key(Qt::Key_B, Qt::ControlModifier);
    check(!window->property("sidebarVisible").toBool(), "Ctrl+B did not hide sidebar");
    key(Qt::Key_B, Qt::ControlModifier);
    check(window->property("sidebarVisible").toBool(), "Ctrl+B did not show sidebar");
    key(Qt::Key_G, Qt::ControlModifier);
    check(window->property("scopeVisible").toBool(), "Ctrl+G did not show oscilloscope");
    QTest::qWait(100);
    auto scope=window->findChild<QQuickItem *>("scopePanel");
    auto divider=visibleItem(window->contentItem(),"scopeDivider");
    check(scope && divider && canvas->height()>=180 && scope->height()<=300,"Oscilloscope consumed the circuit workspace");
    check(scope->mapToScene({0,0}).y()>=canvas->mapToScene({0,canvas->height()}).y(),"Oscilloscope is not below the circuit");
    const auto previousCanvasHeight=canvas->height();
    auto dragDivider=[&](int dy) {
      auto point=divider->mapToScene({divider->width()/2,divider->height()/2}).toPoint();
      QTest::mousePress(window,Qt::LeftButton,Qt::NoModifier,point);
      QTest::mouseMove(window,point+QPoint(0,dy),40);
      QTest::mouseRelease(window,Qt::LeftButton,Qt::NoModifier,point+QPoint(0,dy));
      QTest::qWait(100);
    };
    dragDivider(70);
    check(canvas->height()>previousCanvasHeight+40,"Dragging the scope divider down did not enlarge the circuit");
    window->grabWindow().save("CedarLogic-3.08-oscilloscope.png");
    dragDivider(-2000);
    check(canvas->height()>=179 && scope->height()<window->height()-180,"Dragging the scope up hid the circuit");
    auto normalScopeSize=window->size();window->resize(760,500);QTest::qWait(100);
    check(canvas->height()>=160 && scope->height()>=119,"Small-window oscilloscope layout hid a panel");
    window->grabWindow().save("CedarLogic-3.08-oscilloscope-small.png");
    window->resize(normalScopeSize);QTest::qWait(100);

    key(Qt::Key_G, Qt::ControlModifier);
    key(Qt::Key_F5);check(editor.running(), "F5 did not start simulation");
    key(Qt::Key_F5);check(!editor.running(), "F5 did not pause simulation");
    key(Qt::Key_F, Qt::ControlModifier);
    auto search = window->findChild<QQuickItem *>("gateSearch");
    check(search && search->hasActiveFocus(), "Ctrl+F did not focus search");
    search->setProperty("text", "toggle");
    key(Qt::Key_A, Qt::ControlModifier); key(Qt::Key_C, Qt::ControlModifier);
    check(app.clipboard()->text() == "toggle", "Search clipboard was stolen by circuit shortcuts");
    key(Qt::Key_X, Qt::ControlModifier);
    check(search->property("text").toString().isEmpty(), "Search cut shortcut failed");
    key(Qt::Key_V, Qt::ControlModifier);
    check(search->property("text").toString() == "toggle", "Search paste shortcut failed");
    key(Qt::Key_Z, Qt::ControlModifier);
    check(editor.document().pages[editor.currentPage()].gates.size() == 2, "Text undo changed circuit");
    key(Qt::Key_Escape);
    check(canvas->hasActiveFocus(), "Escape did not return search focus to circuit");
    auto tool = window->findChild<QQuickItem *>("zoomInTool");
    auto pos = tool->mapToScene(QPointF(tool->width()/2,tool->height()/2));
    QTest::mouseClick(window, Qt::LeftButton, Qt::NoModifier, pos.toPoint());
    check(canvas->hasActiveFocus(), "Toolbar took keyboard focus from canvas");
    center = canvas->visibleWorld().center();key(Qt::Key_Left);
    check(canvas->visibleWorld().center().x() < center.x(), "Arrows stopped after a toolbar click");
    // The additional-open toolbar command must open a picker, not fit/zoom
    // the current circuit. Canceling leaves the current document/view intact.
    auto extraOpen=window->findChild<QQuickItem *>("openAdditionalCircuitTool");
    auto openTool=window->findChild<QQuickItem *>("openCircuitTool");
    auto saveTool=window->findChild<QQuickItem *>("saveCircuitTool");
    check(extraOpen && openTool && saveTool,"Circuit file toolbar command is missing");
    check(openTool->x()+openTool->width()<=extraOpen->x() &&
          extraOpen->x()+extraOpen->width()<=saveTool->x(),"Additional-open is outside the file-button group");
    const auto beforeOpen=editor.document(); const auto beforeView=canvas->visibleWorld();
    bool newWindowPicker=false;
    const auto nativeDisabled=app.testAttribute(Qt::AA_DontUseNativeDialogs);
    app.setAttribute(Qt::AA_DontUseNativeDialogs,true);
    QTimer::singleShot(100,[&] {
      auto dialog=qobject_cast<QFileDialog *>(QApplication::activeModalWidget());
      if(dialog) {
        newWindowPicker=dialog->windowTitle()=="Open circuit in a new window";
        dialog->reject();
      }
    });
    auto openPos=extraOpen->mapToScene({extraOpen->width()/2,extraOpen->height()/2});
    QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,openPos.toPoint());
    app.setAttribute(Qt::AA_DontUseNativeDialogs,nativeDisabled);
    check(newWindowPicker,"Additional-open toolbar button does not invoke the new-window file picker");
    check(editor.document()==beforeOpen && canvas->visibleWorld()==beforeView,
          "Canceling additional-open changed the current circuit or fit its view");
    canvas->forceActiveFocus();window->requestActivate();QTest::qWait(50);
    window->grabWindow().save("CedarLogic-3.08-file-toolbar.png");
    key(Qt::Key_Comma, Qt::ControlModifier);
    auto prefs = window->findChild<QObject *>("preferencesDialog");
    check(prefs && prefs->property("visible").toBool(), "Preferences shortcut failed");
    auto pages = editor.document().pages.size(); key(Qt::Key_T, Qt::ControlModifier);
    check(editor.document().pages.size() == pages, "Circuit shortcut ran behind a modal dialog");
    QMetaObject::invokeMethod(prefs, "close");
    QCoreApplication::processEvents();
    auto strip = window->findChild<QQuickItem *>("pageStrip");
    auto menu = window->findChild<QQuickItem *>("mainMenu");
    check(strip && strip->height() == 28 && menu && menu->height() == 28, "Compact navigation heights changed");
    check(menu->property("count").toInt() == 4, "Simulation menu was not removed");
    canvas->forceActiveFocus();
    key(Qt::Key_A);
    auto quickAdd = window->findChild<QObject *>("quickAddDialog");
    auto addSearch = window->findChild<QQuickItem *>("quickAddSearch");
    check(quickAdd && quickAdd->property("visible").toBool() && addSearch->hasActiveFocus(), "A did not open Add Component search");
    addSearch->setProperty("text", "tggl");
    QCoreApplication::processEvents();
    check(!editor.palette("tggl", "").isEmpty(), "Fuzzy search lost ordered-letter matching");
    auto addResults=window->findChild<QQuickItem *>("quickAddResults");
    check(addResults && addResults->width()>=200 && addResults->property("count").toInt()>0,"Add Component results are not visible");
    key(Qt::Key_Return);
    check(!quickAdd->property("visible").toBool() && !editor.placement().isEmpty(), "Enter did not choose a component");
    const auto beforePreview=editor.document();
    const auto beforeTime=editor.simulationTime();
    editor.setPlacement("");
    const auto withoutPreview=canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false);
    editor.setPlacement("AA_TOGGLE");
    const auto cursor=canvas->mapToScene({canvas->width()/2,canvas->height()/2}).toPoint();
    QTest::mouseMove(window,cursor); QTest::qWait(50);
    const auto preview=canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false);
    check(preview!=withoutPreview,"A-menu component has no hover preview");
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)==preview,
          "Reusing a placement symbol changed its pixels");
    editor.setPlacement("AA_AND2");
    QTest::mouseMove(window,cursor); QTest::qWait(30);
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)!=preview,
          "Changing a component reused the previous placement symbol");
    editor.setPlacement("AA_TOGGLE");
    QTest::mouseMove(window,cursor); QTest::qWait(30);
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)==preview,
          "Switching back did not restore the original placement symbol");
    QTest::qWait(50); window->grabWindow().save("CedarLogic-3.08-placement.png");
    check(editor.document()==beforePreview && editor.simulationTime()==beforeTime,"Hover preview changed circuit or simulation");
    QTest::mouseMove(window,cursor+QPoint(80,20)); QTest::qWait(30);
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)!=preview,"Placement preview did not follow cursor");
    const auto beforeRotate=canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false);
    key(Qt::Key_R);
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)!=beforeRotate,"Placement preview did not rotate");
    key(Qt::Key_Escape);
    check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)==withoutPreview,"Escape left a ghost preview");
    editor.setPlacement("AA_TOGGLE");
    auto gateCount = editor.document().pages[editor.currentPage()].gates.size();
    int placementNotifications=0;
    auto placementConnection=QObject::connect(&editor,&Editor::changed,[&]{if(editor.placement().isEmpty())++placementNotifications;});
    editor.placeAt({25,25});editor.placeAt({30,30});
    QObject::disconnect(placementConnection);
    check(placementNotifications>0,"Palette did not receive placement reset");
    check(editor.document().pages[editor.currentPage()].gates.size() == gateCount+1 && editor.placement().isEmpty(), "Placement did not stop after one gate");
    auto properties = window->findChild<QObject *>("gatePropertiesDialog");
    editor.setPlacement("AA_AND2");editor.placeAt({40,25});
    editor.setPlacement("BB_CLOCK");editor.placeAt({52,25});
    canvas->fit();QTest::qWait(100);
    auto clickPoint = [&](QPointF world) {
      const auto center=canvas->visibleWorld().center();
      const auto scale=canvas->zoom()*12;
      return canvas->mapToScene({canvas->width()/2+(world.x()-center.x())*scale,
                                canvas->height()/2-(world.y()-center.y())*scale}).toPoint();
    };
    QTest::mouseDClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({40,25}));
    check(properties && !properties->property("visible").toBool(),"Double click opened properties for a gate with no editable fields");
    QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({52,25}));
    check(!properties->property("visible").toBool(),"Single click opened gate properties");
    editor.selectAll();
    QTest::mouseDClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({52,25}));
    QCoreApplication::processEvents();
    check(properties->property("visible").toBool(),"Double click did not open editable clock properties");
    check(editor.parameterFields().size()==1 && editor.parameterFields()[0].toMap()["key"]=="logic:HALF_CYCLE","Double click did not select the individual editable gate");
    window->grabWindow().save("CedarLogic-3.08-properties.png");
    QMetaObject::invokeMethod(properties,"close");QCoreApplication::processEvents();
    editor.setEditingLocked(true);
    QTest::mouseDClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({52,25}));
    check(!properties->property("visible").toBool(),"Double click opened editable properties while locked");
    editor.setEditingLocked(false);
    canvas->forceActiveFocus();key(Qt::Key_I, Qt::ControlModifier);
    check(properties->property("visible").toBool(), "Ctrl+I did not open gate properties");
    QMetaObject::invokeMethod(properties,"close");QCoreApplication::processEvents();
    editor.setPlacement("BA_DECODER_2x4");editor.placeAt({68,25});canvas->fit();QTest::qWait(100);
    auto openDecoder=[&] {
      canvas->forceActiveFocus();
      QTest::mouseDClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({68,25}));QTest::qWait(60);
      check(properties->property("visible").toBool(),"Decoder double-click does not open properties");
    };
    auto findItem=[&](const char *name) {
      std::function<QQuickItem *(QQuickItem *)> find=[&](QQuickItem *item)->QQuickItem * {
        if(item->objectName()==name) return item;
        for(auto child:item->childItems()) if(auto found=find(child)) return found;
        return nullptr;
      };
      return find(window->contentItem());
    };
    auto clickItem=[&](const char *name) {
      auto item=findItem(name);check(item,"Decoder dialog control is missing");
      QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,
                        item->mapToScene({item->width()/2,item->height()/2}).toPoint());QTest::qWait(40);
    };
    auto chooseLow=[&] {
      clickItem("decoderPolarityCombo"); key(Qt::Key_Down); key(Qt::Key_Return);
      check(properties->property("values").value<QJSValue>().toVariant().toMap()["logic:OUTPUT_POLARITY"]=="LOW",
            "Decoder dropdown does not select active low");
    };
    for(auto mode:{"light","dark"}) {
      theme.setSessionMode(mode);openDecoder();
      auto combo=findItem("decoderPolarityCombo");
      check(combo && combo->property("currentIndex").toInt()==0 && combo->property("count").toInt()==2,
            "Decoder dropdown options or original default are wrong");
      chooseLow();
      window->grabWindow().save(QString("CedarLogic-3.08-decoder-%1.png").arg(mode));
      clickItem("gatePropertiesCancel");
      check(editor.parameterFields()[0].toMap()["value"]=="HIGH","Cancel changed decoder polarity");
      const auto highSymbol=canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false);
      openDecoder();chooseLow();clickItem("gatePropertiesApply");
      check(!properties->property("visible").toBool() && editor.parameterFields()[0].toMap()["value"]=="LOW",
            "Applying the decoder dialog does not retain active low");
      const auto lowSymbol=canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false);
      check(lowSymbol!=highSymbol,"Active-low decoder does not add visible output bubbles");
      lowSymbol.save(QString("CedarLogic-3.08-decoder-bubbles-%1.png").arg(mode));
      editor.undo();check(editor.parameterFields()[0].toMap()["value"]=="HIGH","Undo did not restore default decoder polarity");
      check(canvas->renderImage(qRound(canvas->width()),qRound(canvas->height()),false)==highSymbol,"Undo did not restore the original decoder symbol");
    }
    // Reopening identical field metadata must refresh user-edited text too.
    for (auto kind : {"DE_TO", "DA_FROM"}) {
      editor.setPlacement(kind);editor.placeAt({90,25});editor.selectAt({90,25});
      check(editor.applyParameters({{"logic:JUNCTION_ID","A"}}),"Cannot name original junction A");
      auto original=editor.document().pages[editor.currentPage()].gates.back();
      editor.copy();editor.paste();
      auto openJunction=[&] {
        canvas->forceActiveFocus();key(Qt::Key_I,Qt::ControlModifier);QTest::qWait(60);
        check(properties->property("visible").toBool(),"Junction properties did not open");
        auto field=visibleItem(window->contentItem(),"gateParameterText");
        check(field,"Junction name field is missing");return field;
      };
      auto field=openJunction();check(field->property("text")=="A","First copy lost junction name A");
      field->forceActiveFocus();key(Qt::Key_A,Qt::ControlModifier);QTest::keyClick(window,'B');
      check(field->property("text")=="B","Could not edit copied junction name");
      clickItem("gatePropertiesApply");
      check(editor.parameterFields()[0].toMap()["value"]=="B","Copy did not retain renamed junction B");
      editor.selectAt({original.at.x,original.at.y});editor.copy();editor.paste();
      check(editor.parameterFields()[0].toMap()["value"]=="A","Recopying original A copied another junction's data");
      field=openJunction();check(field->property("text")=="A","Recopied junction A shows stale edited text B");
      field->forceActiveFocus();key(Qt::Key_A,Qt::ControlModifier);QTest::keyClick(window,'C');
      clickItem("gatePropertiesCancel");
      field=openJunction();check(field->property("text")=="A","Cancelled junction edit leaked into reopened properties");
      clickItem("gatePropertiesApply");
      check(editor.parameterFields()[0].toMap()["value"]=="A","Unchanged dialog renamed copied junction");
      editor.selectAll();editor.deleteSelection();
    }
    theme.setSessionMode("");
    std::cerr << "Actual decoder double-click, dropdown, Cancel, Apply and undo passed in both themes\n";
    // RAM and ROM use the original memory grid, rather than file-path fields
    // in the generic gate-properties dialog.
    QTemporaryDir memoryFiles;
    auto cdm=memoryFiles.filePath("values.CdM"), hex=memoryFiles.filePath("values.hex");
    auto writeFile=[](const QString &path,const QByteArray &bytes) {
      QFile file(path);check(file.open(QIODevice::WriteOnly),"Could not create memory test file");
      check(file.write(bytes)==bytes.size(),"Could not write memory test file");
    };
    writeFile(cdm,"0 : D\n3 : 7\n");
    writeFile(hex,":020000000A0BE9\n:00000001FF\n");
    for(auto name:{"AA_RAM_4x4","BE_ROM_8x8"}) {
      const QPointF location(name==QString("AA_RAM_4x4")?-20:0,-20);
      editor.setPlacement(name);editor.placeAt(location);canvas->fit();QTest::qWait(100);
      const auto gate=QString::fromStdString(editor.document().pages[editor.currentPage()].gates.back().uuid);
      QTest::mouseDClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint(location));QTest::qWait(60);
      QDialog *memory=nullptr;
      for(auto widget:QApplication::topLevelWidgets())
        if(widget->objectName()=="memoryContentsDialog" && widget->property("memoryGate")==gate)
          memory=qobject_cast<QDialog *>(widget);
      check(memory && memory->isVisible(),"Double click does not open the RAM/ROM value dialog");
      check(!properties->property("visible").toBool(),"Memory double click still opens generic gate options");
      auto values=memory->findChild<QTableView *>("memoryValues");
      auto decimal=memory->findChild<QCheckBox *>("memoryShowDecimal");
      auto table=values?values->model():nullptr;
      check(table && decimal && table->columnCount()==16 &&
            table->rowCount()==(name==QString("AA_RAM_4x4")?1:16),"Memory grid does not match the original 16-column layout");
      check(table->setData(table->index(0,3),"A",Qt::EditRole),"Cannot edit a hexadecimal memory value");
      QTest::qWait(100);decimal->setChecked(true);
      check(table->data(table->index(0,3)).toString()=="10","Show Decimal does not display the original value");
      check(table->setData(table->index(0,3),"15",Qt::EditRole),"Cannot edit a decimal memory value");
      QTest::qWait(100);decimal->setChecked(false);
      check(table->data(table->index(0,3)).toString().toUInt(nullptr,16)==15,"Decimal edit was interpreted as hexadecimal");
      check(!table->setData(table->index(0,3),"10000",Qt::EditRole),"Memory edit accepts values wider than the gate data bus");
      check(table->data(table->index(0,3),Qt::BackgroundRole).value<QColor>()==QColor(Qt::red),"Last-written memory highlight is missing");
      // Selection changes must not redirect file operations to another gate.
      editor.selectAt({40,25});
      check(editor.memoryFilePath(gate,cdm,false),"CDM memory load was rejected");
      QTest::qWait(120);
      check(table->data(table->index(0,0)).toString().toUInt(nullptr,16)==13 &&
            table->data(table->index(0,3)).toString().toUInt(nullptr,16)==7,"CDM contents did not refresh in the correct memory dialog");
      check(editor.memoryFilePath(gate,hex,false),"Intel HEX memory load was rejected");QTest::qWait(120);
      check(table->data(table->index(0,0)).toString().toUInt(nullptr,16)==10 &&
            table->data(table->index(0,1)).toString().toUInt(nullptr,16)==11 &&
            table->data(table->index(0,3)).toString().toUInt(nullptr,16)==0,"Intel HEX load did not replace old memory values");
      check(!editor.memoryFilePath(gate,memoryFiles.filePath("bad.txt"),false),"Memory load accepts unsupported extensions");
      check(!editor.memoryFilePath(gate,memoryFiles.filePath("bad.hex"),true),"Memory save writes CDM data into a HEX file");
      const auto saved=memoryFiles.filePath(QString(name)+".cdm");
      check(editor.memoryFilePath(gate,saved,true),"CDM memory save was rejected");QTest::qWait(120);
      QFile savedFile(saved);check(savedFile.open(QIODevice::ReadOnly),"Memory save did not produce a file");
      const auto savedBytes=savedFile.readAll();
      check(savedBytes.contains("0 : A") && savedBytes.contains("1 : B"),"Saved memory does not contain edited/imported values");
      // Exercise both actual file buttons; their filters must omit All files.
      const auto nativeDisabled=app.testAttribute(Qt::AA_DontUseNativeDialogs);
      app.setAttribute(Qt::AA_DontUseNativeDialogs,true);
      for(auto buttonName:{"memoryOpen","memorySave"}) {
        bool filtered=false;
        QTimer::singleShot(100,[&] {
          auto picker=qobject_cast<QFileDialog *>(QApplication::activeModalWidget());
          if(picker) {
            const auto filters=picker->nameFilters().join(";");
            filtered=filters.contains("*.cdm") && !filters.contains("All files") &&
              (buttonName==QString("memorySave")?!filters.contains("*.hex"):filters.contains("*.hex"));
            picker->reject();
          }
        });
        auto button=memory->findChild<QPushButton *>(buttonName);check(button,"Memory file button is missing");
        button->click();check(filtered,"Memory picker exposes wrong file formats");
      }
      app.setAttribute(Qt::AA_DontUseNativeDialogs,nativeDisabled);
      memory->grab().save(QString("CedarLogic-3.08-%1-memory.png").arg(name));
      theme.setSessionMode("dark");QTest::qWait(60);
      memory->grab().save(QString("CedarLogic-3.08-%1-memory-dark.png").arg(name));
      theme.setSessionMode("");QTest::qWait(60);
      memory->close();QCoreApplication::sendPostedEvents(nullptr,QEvent::DeferredDelete);
      canvas->forceActiveFocus();window->requestActivate();QTest::qWait(60);
    }
    appConfig().appSettings.signatureName.clear();
    QMetaObject::invokeMethod(window,"requestSign");QCoreApplication::processEvents();
    check(prefs->property("visible").toBool() && prefs->property("section").toInt()==2, "Missing signing name did not open settings");
    check(prefs->property("signingRequired").toBool(), "Signing name error was not shown");
    QMetaObject::invokeMethod(prefs,"close");QCoreApplication::processEvents();
    appConfig().appSettings.signatureName="Ada";
    QMetaObject::invokeMethod(window,"requestSign");QCoreApplication::processEvents();
    auto sign = window->findChild<QObject *>("signCircuitDialog");
    check(sign && sign->property("visible").toBool(), "Configured username could not sign");
    check(window->findChild<QObject *>("signatureStatus")->property("text").toString()=="This circuit works properly", "Default circuit status changed");
    QMetaObject::invokeMethod(sign,"close");QCoreApplication::processEvents();
    check(editor.changelogText().contains("3.08") && editor.changelogText().contains("3.06"), "Changelog lost current or older history");
    QMetaObject::invokeMethod(window,"openChangelog");QCoreApplication::processEvents();
    auto changelog = window->findChild<QObject *>("changelogDialog");
    check(changelog && changelog->property("visible").toBool(), "Changelog dialog did not open");
    QMetaObject::invokeMethod(changelog,"close");QCoreApplication::processEvents();
    canvas->forceActiveFocus();key(Qt::Key_F1);
    auto tutorial = window->findChild<QObject *>("tutorialDialog");
    check(tutorial && tutorial->property("visible").toBool(), "F1 did not open embedded tutorial");
    check(!window->findChild<QObject *>("tutorialText")->property("text").toString().isEmpty(), "Tutorial is empty");
    const auto help = editor.helpTopics();
    QStringList roots;
    int intro=-1, adding=-1, gettingStarted=-1;
    for(int i=0;i<help.size();++i) {
      const auto topic=help[i].toMap();
      if(topic["depth"].toInt()==0)roots<<topic["title"].toString();
      if(topic["file"]=="Introduction.htm")intro=i;
      if(topic["file"]=="Adding_Gates_To_A_Circuit.htm")adding=i;
      if(topic["title"]=="Getting Started")gettingStarted=i;
    }
    check(roots==QStringList({"About","How To Know God","Menu Commands","Toolbar Commands","High Level Gate Descriptions","Tutorial"}),
          "Tutorial root categories or original order changed");
    check(intro>=0 && adding==gettingStarted+1 && help[adding+1].toMap()["file"]=="TO_FROM_Gates.htm" &&
          help[adding+2].toMap()["file"]=="Connecting_Gates.htm", "Getting Started order does not match the original contents");
    check(tutorial->property("topicIndex").toInt()==intro,"Tutorial did not start at Introduction");
    QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(adding)));QCoreApplication::processEvents();
    check(tutorial->property("topicIndex").toInt()==adding,"Tree navigation did not change the help page");
    // Drive the real tutorial viewport with mouse-wheel events, not a scroll helper.
    auto helpView=window->findChild<QObject *>("tutorialPage");
    auto helpFlick=helpView->property("contentItem").value<QQuickItem *>();
    check(helpFlick,"Tutorial scroll viewport missing");QTest::qWait(100);
    const auto wheelPosition=helpFlick->mapToScene({helpFlick->width()/2,helpFlick->height()/2});
    auto helpWheel=[&](QPoint angle,QPoint pixels=QPoint(),Qt::ScrollPhase phase=Qt::NoScrollPhase) {
      QWheelEvent event(wheelPosition,window->mapToGlobal(wheelPosition.toPoint()),pixels,angle,
                        Qt::NoButton,Qt::NoModifier,phase,false);
      QCoreApplication::sendEvent(window,&event);QTest::qWait(250);
    };
    helpFlick->setProperty("contentY",0);helpWheel({0,-120});
    const auto helpNotch=helpFlick->property("contentY").toDouble();
    std::cerr<<"Tutorial mouse wheel: "<<helpNotch<<" pixels per notch\n";
    check(std::abs(helpNotch-120)<1,"Tutorial mouse-wheel step is too small or counted twice");
    helpWheel({0,120});check(std::abs(helpFlick->property("contentY").toDouble())<1,"Tutorial wheel cannot reverse to the top");
    for(int i=0;i<6;i++) {
      QWheelEvent event(wheelPosition,window->mapToGlobal(wheelPosition.toPoint()),QPoint(),{0,-120},
                        Qt::NoButton,Qt::NoModifier,Qt::NoScrollPhase,false);
      QCoreApplication::sendEvent(window,&event);
    }
    check(std::abs(helpFlick->property("contentY").toDouble()-720)<1,"Fast wheel events are being dropped or delayed");
    helpFlick->setProperty("contentY",0);
    for(int i=0;i<8;i++)helpWheel({0,-15});
    check(std::abs(helpFlick->property("contentY").toDouble()-120)<1,"High-resolution wheel increments do not add up to a notch");
    helpFlick->setProperty("contentY",helpFlick->property("contentHeight").toDouble()-helpFlick->height());
    const auto bottom=helpFlick->property("contentY").toDouble();helpWheel({0,-120});
    check(std::abs(helpFlick->property("contentY").toDouble()-bottom)<1,"Tutorial wheel scrolls beyond the bottom");
    helpFlick->setProperty("contentY",0);
    // A real TouchPad device takes a different path from a notched mouse on Wayland.
    QPointingDevice touchpad("Tutorial test touchpad",9876,QInputDevice::DeviceType::TouchPad,
        QPointingDevice::PointerType::Finger,QInputDevice::Capability::Position,2,0);
    auto touchWheel=[&](QPoint pixels,QPoint angle={},Qt::ScrollPhase phase=Qt::ScrollUpdate,
                       const QPointingDevice *device=nullptr) {
      QWheelEvent event(wheelPosition,window->mapToGlobal(wheelPosition.toPoint()),pixels,angle,
          Qt::NoButton,Qt::NoModifier,phase,false,Qt::MouseEventSynthesizedBySystem,device?device:&touchpad);
      QCoreApplication::sendEvent(window,&event);
    };
    check(theme.editorSettings()["helpTouchpadSpeed"].toInt()==3,"Touchpad help speed default changed");
    touchWheel({}, {}, Qt::ScrollBegin);
    touchWheel({0,-20},{0,-1});
    check(std::abs(helpFlick->property("contentY").toDouble()-60)<1,"Touchpad pixel movement is ignored or uses its tiny angle delta");
    touchWheel({0,-20},{0,-1},Qt::ScrollMomentum);
    check(std::abs(helpFlick->property("contentY").toDouble()-120)<1,"Touchpad momentum is ignored or scaled twice");
    touchWheel({0,20});check(std::abs(helpFlick->property("contentY").toDouble()-60)<1,"Touchpad cannot reverse");
    helpFlick->setProperty("contentY",0);
    for(int i=0;i<20;i++)touchWheel({0,-2});
    check(std::abs(helpFlick->property("contentY").toDouble()-120)<1,"Small rapid touchpad packets are lost");
    helpFlick->setProperty("contentY",0);touchWheel({}, {0,-10});
    check(std::abs(helpFlick->property("contentY").toDouble()-30)<1,"Angle-only touchpad fallback is too slow");
    auto touchSettings=theme.editorSettings();touchSettings["helpTouchpadSpeed"]=5;theme.apply(theme.mode(),theme.accentName(),touchSettings);
    helpFlick->setProperty("contentY",0);touchWheel({0,-20});
    check(std::abs(helpFlick->property("contentY").toDouble()-100)<1,"Touchpad speed preference is not applied");
    {Appearance restored;check(restored.editorSettings()["helpTouchpadSpeed"].toInt()==5,"Touchpad speed does not persist");}
    touchSettings["helpTouchpadSpeed"]=3;theme.apply(theme.mode(),theme.accentName(),touchSettings);
    // Some Linux pointer devices label a continuous gesture as a Mouse.
    helpFlick->setProperty("contentY",0);touchWheel({0,-20},{0,-1},Qt::ScrollUpdate,QPointingDevice::primaryPointingDevice());
    check(std::abs(helpFlick->property("contentY").toDouble()-60)<1,"Mouse-classified Linux touchpad gesture bypasses the fix");
    helpFlick->setProperty("contentY",helpFlick->property("contentHeight").toDouble()-helpFlick->height());
    const auto touchBottom=helpFlick->property("contentY").toDouble();touchWheel({0,-20});
    check(std::abs(helpFlick->property("contentY").toDouble()-touchBottom)<1,"Touchpad scrolls beyond the end of a page");
    touchWheel({}, {}, Qt::ScrollEnd);
    helpFlick->setProperty("contentY",0);
    std::cerr<<"Touchpad: pixel/angle paths, momentum, rapid packets, reversal, saved speed and bounds passed\n";
    // Title cleanup must preserve artwork wrapped in an old HTML heading.
    QVariant preserved;
    QMetaObject::invokeMethod(tutorial,"fitImages",Q_RETURN_ARG(QVariant,preserved),
        Q_ARG(QVariant,QVariant("<h1><img src=\"image41.gif\"></h1><p>Original illustration</p>")),Q_ARG(QVariant,QVariant(400)));
    check(preserved.toString().contains("image41.gif"),"Tutorial title cleanup removed an illustration");
    const auto faith=editor.helpText("How_To_Have_A_Personal_Relationship_With_God.htm");
    check(faith.contains("image41.gif") && !faith.contains("#000000"),"Faith page lost artwork or forces a dark-mode text color");
    for(auto file:{"Signing_Circuits.htm","Appearance.htm","Editor_Preferences.htm","Autosave_Recovery.htm","Locking_Circuits.htm","Open_New_Window.htm"}) {
      int found=-1;for(int i=0;i<help.size();i++)if(help[i].toMap()["file"].toString()==file)found=i;
      check(found>=0,"New feature help is missing from contents");
      QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(found)));QCoreApplication::processEvents();
      check(!window->findChild<QObject *>("tutorialText")->property("text").toString().isEmpty(),"Feature help did not render");
    }
    for(auto mode:{"light","dark"}) {
      theme.setSessionMode(mode);QVariant rendered;
      QMetaObject::invokeMethod(tutorial,"fitImages",Q_RETURN_ARG(QVariant,rendered),
          Q_ARG(QVariant,QVariant(editor.helpText("New.htm"))),Q_ARG(QVariant,QVariant(400)));
      check(rendered.toString().contains(QString("icons/new-%1.png").arg(mode)),"Command icon does not follow tutorial theme");
    }
    theme.setSessionMode("");
    QMetaObject::invokeMethod(tutorial,"selectTopic",Q_ARG(QVariant,QVariant(adding)));QCoreApplication::processEvents();
    window->grabWindow().save("CedarLogic-3.08-tutorial.png");
    QMetaObject::invokeMethod(tutorial,"close");QCoreApplication::processEvents();
    auto fileMenu=window->findChild<QObject *>("fileMenu");
    QMetaObject::invokeMethod(fileMenu,"open");QTest::qWait(200);
    auto hint=window->findChild<QQuickItem *>("openMenuCommandShortcut");
    check(hint && hint->property("text").toString()=="Ctrl+O" && hint->isVisible(), "File menu shortcut is not visible");
    window->grabWindow().save("CedarLogic-3.08-menu.png");
    QMetaObject::invokeMethod(fileMenu,"close");
    // Closing an inactive tab must preserve the currently displayed page.
    const auto activePage = editor.currentPage();
    QTest::qWait(100);
    auto tabClose=visibleItem(window->contentItem(),"pageClose0");
    check(tabClose && tabClose->isVisible(),"Page close X is missing");
    if(editor.document().pages.size()>1) {
      auto gatesBefore=editor.document().pages[activePage].gates;
      auto count=editor.document().pages.size();
      auto point=tabClose->mapToScene({tabClose->width()/2,tabClose->height()/2}).toPoint();
      QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,point);QCoreApplication::processEvents();
      check(editor.document().pages.size()==count-1,"Page X did not close the tab");
      if(activePage!=0)check(editor.document().pages[editor.currentPage()].gates==gatesBefore,"Closing an inactive tab changed the active circuit page");
    }
    editor.step();QTest::qWait(50);
    check(!window->findChild<QObject *>("statusLabel")->property("text").toString().contains("Step"),"Bottom step counter remains visible");
    const auto normalSize=window->size();
    window->resize(760,500);QTest::qWait(100);
    auto shortcuts=window->findChild<QObject *>("shortcutHelpDialog");
    check(shortcuts,"Structured shortcuts dialog is missing");
    QMetaObject::invokeMethod(shortcuts,"open");QTest::qWait(100);
    auto keyLabel=visibleItem(window->contentItem(),"shortcutKeys0");
    auto actionLabel=visibleItem(window->contentItem(),"shortcutAction0");
    check(keyLabel && actionLabel && keyLabel->mapToScene({keyLabel->width(),0}).x()<actionLabel->mapToScene({0,0}).x(),"Shortcut keys and descriptions overlap");
    window->grabWindow().save("CedarLogic-3.08-shortcuts.png");
    QMetaObject::invokeMethod(shortcuts,"close");QCoreApplication::processEvents();
    QMetaObject::invokeMethod(prefs,"open");prefs->setProperty("section",0);QTest::qWait(100);
    check(!theme.editorSettings().contains("wireColor") && !visibleItem(window->contentItem(),"wireColorPurple"),"Removed circuit color controls remain available");
    window->grabWindow().save("CedarLogic-3.08-preferences.png");
    QMetaObject::invokeMethod(prefs,"close");QCoreApplication::processEvents();
    window->resize(normalSize);QTest::qWait(100);
    auto viewMenu=window->findChild<QObject *>("viewMenu");
    QMetaObject::invokeMethod(viewMenu,"open");QTest::qWait(100);
    const QStringList viewItems{"zoomInMenuCommand","zoomOutMenuCommand","gridMenuCommand",
      "connectionMenuCommand","sidebarMenuCommand","scopeMenuCommand","fitMenuCommand","searchMenuCommand"};
    qreal last=-1;
    for(const auto &name:viewItems) {
      auto item=window->findChild<QQuickItem *>(name);
      check(item && item->y()>last,"View menu order differs from 3.06");last=item->y();
      if(item->property("checkable").toBool()) {
        auto mark=window->findChild<QQuickItem *>(name+"Check");
        auto label=window->findChild<QQuickItem *>(name+"Label");
        check(label && !label->property("truncated").toBool(),"View command label is truncated");
        check(mark && label && mark->mapToScene({mark->width(),0}).x()<=label->mapToScene({0,0}).x(),
              "View checkmark overlaps its command label");
      }
    }
    window->grabWindow().save("CedarLogic-3.08-view.png");
    QMetaObject::invokeMethod(viewMenu,"close");
    check(editor.metaObject()->indexOfMethod("printDialog()")==-1,"Printing is still exposed");
    canvas->forceActiveFocus();window->requestActivate();QTest::qWait(50);
    key(Qt::Key_P,Qt::ControlModifier);
    check(!QApplication::activeModalWidget(),"Ctrl+P still opens printing");
    bool exportFloating=false;
    const auto desktopPalette=app.palette();
    auto darkDesktop=desktopPalette;darkDesktop.setColor(QPalette::Window,QColor("#202020"));darkDesktop.setColor(QPalette::Button,QColor("#303030"));darkDesktop.setColor(QPalette::Base,QColor("#151515"));darkDesktop.setColor(QPalette::Text,Qt::white);darkDesktop.setColor(QPalette::WindowText,Qt::white);darkDesktop.setColor(QPalette::ButtonText,Qt::white);
    app.setPalette(darkDesktop);
    for(auto mode:{"light","dark"}) {
    theme.setSessionMode(mode);window->requestActivate();QTest::qWait(40);
    bool exportThemed=false;
    QTimer::singleShot(100,[&] {
      auto dialog=qobject_cast<QDialog *>(QApplication::activeModalWidget());
      if(!dialog)for(auto widget:QApplication::topLevelWidgets())
        if(widget->objectName()=="imageExportDialog")dialog=qobject_cast<QDialog *>(widget);
      if(dialog) {
        exportFloating=dialog->isWindow() && dialog->isVisible() &&
          (dialog->windowFlags() & Qt::WindowType_Mask)==Qt::Tool &&
          dialog->windowHandle()->transientParent()==window && dialog->windowModality()==Qt::WindowModal;
        auto checkbox=dialog->findChild<QCheckBox *>();auto combos=dialog->findChildren<QComboBox *>();
        exportThemed=checkbox && checkbox->palette().color(QPalette::WindowText)==theme.text() && combos.size()==2;
        if(checkbox)QTest::mouseClick(checkbox,Qt::LeftButton);
        for(auto combo:combos)exportThemed=exportThemed && combo->palette().color(QPalette::ButtonText)==theme.text() && combo->view()->palette().color(QPalette::Text)==theme.text();
        dialog->grab().save(QString("CedarLogic-3.08-export-%1.png").arg(mode));
        if(!combos.isEmpty()) {
          combos[0]->showPopup();QTest::qWait(50);
          combos[0]->view()->window()->grab().save(QString("CedarLogic-3.08-export-options-%1.png").arg(mode));
          combos[0]->hidePopup();
        }
        dialog->reject();
      }
    });
    editor.exportDialog();
    check(exportFloating,"Image export is not an owned floating utility window");
    check(exportThemed,"Export checkbox or dropdown still inherits dark desktop colors in light mode");
    }
    app.setPalette(desktopPalette);theme.setSessionMode("");
    // Actual Delete/right-click paths must repaint collapsed fanout without a
    // follow-up click, in either theme, even with the simulation paused.
    for(auto mode:{"light","dark"}) for(bool deleteGate:{true,false}) {
      theme.setSessionMode(mode);editor.setRunning(false);
      if(editor.dirty()) QTimer::singleShot(0,[] {
        if(auto dialog=qobject_cast<QMessageBox *>(QApplication::activeModalWidget()))
          dialog->done(QMessageBox::Discard);
      });
      editor.newDocument();
      editor.setPlacement("DI_NAND8");editor.placeAt({0,0});
      editor.connectPins(editor.pinAt({-3,2.5},.1),editor.pinAt({-3,-1.5},.1));
      check(editor.startWireMove({-3,.5},.1),"Cannot prepare UI fanout trunk");
      editor.moveWire({-7,.5});editor.finishWireMove();
      editor.connectPins(editor.pinAt({-3,.5},.1),editor.pinAt({-3,2.5},.1));
      editor.setPlacement("EE_VDD");editor.placeAt({-7,7.5});
      check(editor.connectPinToWire(editor.pinAt({-7,6.5},.1),{-7,1},.1),"Cannot prepare powered UI fanout");
      editor.step(10);QTest::qWait(100);canvas->fit();QTest::qWait(60);
      const auto wire=editor.document().pages[0].wires[0].ids[0];
      const auto time=editor.simulationTime();
      check(editor.wireState(wire)==ONE,"UI fanout was not powered");
      canvas->forceActiveFocus();window->requestActivate();
      if(deleteGate) {
        QTest::mouseClick(window,Qt::LeftButton,Qt::NoModifier,clickPoint({-7,7.5}));key(Qt::Key_Delete);
      } else QTest::mouseClick(window,Qt::RightButton,Qt::NoModifier,clickPoint({-7,6.5}));
      QTest::qWait(80);
      check(editor.document().pages[0].wires.size()==1,"UI removal erased the remaining fanout");
      for(const auto &segment:editor.document().pages[0].wires[0].segments)
        check(segment.begin.y>=-1.5 && segment.end.y<=2.5,"UI removal leaves a source tail until another click");
      check(editor.simulationTime()==time && editor.wireState(wire)==HI_Z,"UI removal did not refresh the paused wire state correctly");
      window->grabWindow().save(QString("CedarLogic-3.08-removal-%1-%2.png").arg(mode).arg(deleteGate?"delete":"disconnect"));
    }
    theme.setSessionMode("");
    std::cerr << "Actual Delete and right-click removal collapse and repaint three-input fanout with no extra click or clock advance in both themes\n";
    checkConnectionPreview(theme);
    checkBlueConnections(theme);
    checkOverview(theme);
    std::cout << "Real QML keyboard, text focus, toolbar focus, modal isolation and compact navigation checks passed\n";
  } catch (const std::exception &e) { std::cerr << e.what() << '\n';return 1; }
}
