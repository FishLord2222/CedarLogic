#!/bin/sh
set -eu
exec dbus-run-session -- sh -c '
  "$1" --server "$2" > "$3" 2>&1 &
  portal_pid=$!
  trap "kill $portal_pid 2>/dev/null || true" EXIT
  tries=0
  while ! grep -q "Portal ready" "$3"; do
    tries=$((tries+1))
    [ "$tries" -lt 50 ] || exit 1
    sleep 0.05
  done
  "$1" "$2"
' sh "$1" "$2" "$3"
