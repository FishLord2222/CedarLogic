#pragma once
#include <QObject>
#include <QPointer>
#include <QQuickWindow>
class Keyboard : public QObject {
  Q_OBJECT
  Q_PROPERTY(bool blocked READ blocked WRITE setBlocked)
public:
  using QObject::QObject;
  void setWindow(QQuickWindow *value);
  bool blocked() const { return modal; }
  void setBlocked(bool value) { modal = value; }
signals:
  void command(const QString &name);
protected:
  bool eventFilter(QObject *object, QEvent *event) override;
private:
  QPointer<QQuickWindow> window;
  bool modal = false;
  QString commandFor(QKeyEvent *event) const;
};
