#include "Appearance.h"
#include "SharedModel.h"
#include "Simulation.h"
#include "circuit_file_io.hpp"
#include "migrate.hpp"
#include "render/RenderStyle.h"
#include "render/SkiaProbe.h"
#include <QEventLoop>
#include <QGuiApplication>
#include <QStandardPaths>
#include <QTemporaryDir>
#include <QTimer>
#include <fstream>
#include <iostream>
#include <stdexcept>
void require(bool value, const char *message) {
  if (!value)
    throw std::runtime_error(message);
}

struct Capture : cl::render::Scene {
  cl::render::Color color;
  std::vector<cl::render::Color> colors;
  std::vector<std::pair<cl::render::Point,float>> bubbles;
  bool drawn = false;
  int depth = 0, textDepth = 0;
  void setViewport(const cl::render::Transform &) override {}
  void pushTransform(const cl::render::Transform &) override { ++depth; }
  void popTransform() override { --depth; }
  void lines(const cl::render::Point *, size_t,
             const cl::render::Stroke &s) override {
    color = s.color;colors.push_back(s.color);
    drawn = true;
  }
  void polyline(const cl::render::Point *, size_t, const cl::render::Stroke &s,
                bool) override { colors.push_back(s.color); }
  void fillPolygon(const cl::render::Point *, size_t,
                   const cl::render::Color &c) override { colors.push_back(c); }
  void fillCircle(cl::render::Point, float,
                  const cl::render::Color &c) override { colors.push_back(c); }
  void strokeCircle(cl::render::Point point, float radius,
                    const cl::render::Stroke &s) override { colors.push_back(s.color);bubbles.push_back({point,radius}); }
  void fillRect(cl::render::Point, cl::render::Point,
                const cl::render::Color &c) override { colors.push_back(c); }
  void text(cl::render::Point, const char *, float,
            const cl::render::Color &c) override { textDepth = depth;colors.push_back(c); }
};
int main(int argc, char **argv) {
  QTemporaryDir tmp;
  qputenv("XDG_CONFIG_HOME", tmp.path().toUtf8());
  QGuiApplication app(argc, argv);
  QSettings::setDefaultFormat(QSettings::IniFormat);
  QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, tmp.path());
  try {
    gateLibrary().libParser =
        LibraryParse(std::string(CEDAR_SOURCE_RES) + "/cl_gatedefs.xml");
    cl::render::setFontSearchDir((std::string(CEDAR_SOURCE_RES) + "/").c_str());
    for (auto &lib : gateLibrary().libraries)
      for (auto &g : lib.second) {
        auto model = makeGate(g.first);
        require(!model->getModelDrawBBox().empty(), "Gate geometry missing");
      }
    Appearance appearance;
    require(!appearance.editorSettings()["sidebarNames"].toBool(),
            "Sidebar names are not hidden by default");
    // The Qt document stores angles as doubles, including decimal spellings.
    // Rotated named links need the same text counter-rotation as integer angles.
    for (auto type : {"DA_FROM", "DE_TO"})
      for (auto angle : {"90", "90.000000", "180", "180.000000",
                         "-180.000000", "540.000000", "0.000000", "270.000000"}) {
        auto gate = makeGate(type);
        gate->setGUIParam("angle", angle);
        gate->setGLcoords(0, 0);
        Capture capture;
        gate->drawToScene(capture, cl::render::RenderStyle::screen(true));
        bool flipped = std::string(angle) != "0.000000" &&
                       std::string(angle) != "270.000000";
        require(capture.textDepth == (flipped ? 2 : 1) && capture.depth == 0,
                "Named-link text lost its rotation correction");
      }
    auto beforeDark = cl::render::RenderStyle::screen(true),
         beforeLight = cl::render::RenderStyle::screen(false);
    for (auto accent : {"Teal", "Blue", "Purple", "Orange", "Green", "Rose"})
      for (auto mode : {"dark", "light"}) {
        appearance.setMode(mode);
        appearance.setAccentName(accent);
        auto style = cl::render::RenderStyle::screen(appearance.dark());
        auto baseline = appearance.dark() ? beforeDark : beforeLight;
        for (auto state :
             {cl::render::WireState::Low, cl::render::WireState::High,
              cl::render::WireState::HiZ, cl::render::WireState::Unknown,
              cl::render::WireState::Conflict}) {
          auto a = style.wire(state, false).color,
               b = baseline.wire(state, false).color;
          require(a.r == b.r && a.g == b.g && a.b == b.b && a.a == b.a,
                  "Accent changed signal palette");
        }
      }
    auto source = makeGate("AA_TOGGLE", 1), sink = makeGate("GA_LED", 2);
    sink->setGLcoords(12, 0);
    guiWire wire;
    wire.setIDs({1});
    wire.setGateResolver(
        [&](unsigned long id) { return id == 1 ? source.get() : sink.get(); });
    wire.addConnection(source.get(), source->getHotspotList().begin()->first);
    wire.addConnection(sink.get(), sink->getHotspotList().begin()->first);
    source->addConnection(source->getHotspotList().begin()->first,&wire);
    sink->addConnection(sink->getHotspotList().begin()->first,&wire);
    const std::vector<cl::render::Color> expected = {
        {0, 0, 0}, {1, 0, 0}, {0, 0.78f, 0}, {0.3f, 0.3f, 1}, {0, 1, 1}};
    const std::vector<StateType> states = {ZERO, ONE, HI_Z, UNKNOWN, CONFLICT};
    for (auto accent : {"Teal", "Blue", "Purple", "Orange", "Green", "Rose"}) {
      appearance.setAccentName(accent);
      for (size_t i = 0; i < states.size(); ++i) {
        wire.setSubState(1, states[i]);
        Capture capture;
        wire.drawToScene(capture, beforeLight);
        auto a = capture.color, b = expected[i];
        require(capture.drawn && a.r == b.r && a.g == b.g && a.b == b.b,
                "Original wire draw colors changed");
      }
    }
    for(bool dark:{false,true}) for(size_t i=0;i<states.size();++i) {
      auto style=cl::render::RenderStyle::screen(dark);
      wire.setSubState(1,states[i]);
      Capture net,led;wire.drawToScene(net,style);sink->drawToScene(led,style);
      auto wanted=expected[i];
      if(dark && states[i]==ZERO)wanted=style.circuitColor();
      if(dark && states[i]==ONE)wanted=style.wireOnColor();
      auto matches=[&](cl::render::Color c){return c.r==wanted.r && c.g==wanted.g && c.b==wanted.b;};
      require(net.drawn && matches(net.color),"Wire signal colors differ from the original state meanings");
      require(!led.colors.empty() && matches(led.colors.back()),"Connected LED color disagrees with its driving wire");
    }
    for(auto name:{"BA_DECODER_2x4","BE_DECODER_3x8","BI_DECODER_4x16","3x8 Decoder Chip"}) {
      const auto &def=gateLibrary().libraries.at(gateLibrary().gateNameToLibrary.at(name)).at(name);
      const auto outputs=std::count_if(def.hotspots.begin(),def.hotspots.end(),[](const auto &pin){return !pin.isInput;});
      auto decoder=makeGate(name);
      require(decoder->getCircles().size()==(std::string(name)=="3x8 Decoder Chip"?size_t(outputs):0),"Default decoder symbol does not match its output polarity");
      for(auto angle:{0,90,180,270}) {
        decoder->setGUIParam("angle",std::to_string(angle));
        decoder->setLogicParam("OUTPUT_POLARITY","HIGH");
        const auto pins=decoder->getHotspotList();const auto hash=decoder->geometryHash();
        require(decoder->getCircles().empty(),"Active-high decoder still has inversion bubbles");
        decoder->setLogicParam("OUTPUT_POLARITY","LOW");
        require(decoder->geometryHash()!=hash,"Polarity does not invalidate the overview geometry cache");
        require(decoder->getCircles().size()==size_t(outputs),"Active-low decoder does not have one bubble per output");
        const auto lowPins=decoder->getHotspotList();
        for(const auto &pin:pins)require(pin.second.x==lowPins.at(pin.first).x && pin.second.y==lowPins.at(pin.first).y,"Polarity moved a connection hotspot off its original grid");
        for(auto style:{beforeDark,beforeLight,cl::render::RenderStyle::print()}) {
          Capture captured;decoder->drawToScene(captured,style);
          require(captured.bubbles.size()==size_t(outputs),"Decoder inversion bubbles are missing from a rendering/export path");
        }
        for(const auto &bubble:decoder->getCircles()) {
          bool output=false;
          for(const auto &pin:def.hotspots)if(!pin.isInput && std::abs(pin.y-bubble.cy)<1e-5 && std::abs(pin.x-bubble.cx)<1)output=true;
          require(output,"Decoder bubble was added to an input or the body");
          for(size_t i=0;i+1<decoder->getVertices().size();i+=2) {
            const auto a=decoder->getVertices()[i],b=decoder->getVertices()[i+1];
            if(std::abs(a.y-bubble.cy)<1e-5 && std::abs(b.y-bubble.cy)<1e-5)
              require(!(std::min(a.x,b.x)<bubble.cx && std::max(a.x,b.x)>bubble.cx),"Output lead crosses through its inversion bubble");
          }
        }
        decoder->setLogicParam("OUTPUT_POLARITY","LOW");
        require(decoder->getCircles().size()==size_t(outputs),"Repeated updates accumulate decoder bubbles");
      }
    }
    auto preferences = appearance.editorSettings();
    preferences["fps"] = 75;
    preferences["autosaveMinutes"] = 4;
    preferences["sidebarNames"] = false;
    appearance.apply("dark", "Purple", preferences);
    {
      Appearance restarted;
      require(restarted.mode() == "dark" &&
                  restarted.accentName() == "Purple" &&
                  !restarted.editorSettings()["sidebarNames"].toBool() &&
                  restarted.editorSettings()["fps"].toInt() == 75,
              "Preferences did not persist");
    }
    appearance.setMode("system");
    require(appearance.mode() == "system", "System mode missing");
    cl::CircuitFile file;
    file.pages.push_back({});
    file.pages[0].gates.push_back({"1", "AA_AND2", {0, 0}, 0, {}});
    require(cl::readCircuitFile(cl::writeCircuitFile(file)) == file,
            "Circuit roundtrip failed");
    bool finished = false;
    TimeType currentTime = 0;
    unsigned long wanted = 1;
    Simulation simulation;
    QEventLoop loop;
    simulation.onFrame = [&](auto frame) {
      if (frame.generation != wanted)
        return;
      require(frame.error.empty(), "Simulation failed");
      currentTime = frame.time;
      finished = true;
      loop.quit();
    };
    simulation.submit(file, 1);
    simulation.step();
    QTimer::singleShot(5000, &loop, &QEventLoop::quit);
    loop.exec();
    require(finished, "Simulation timed out");
    auto priorTime = currentTime;
    require(priorTime > 0, "Simulation did not advance");
    file.pages[0].gates.push_back({"2", "AA_TOGGLE", {10, 0}, 0, {}});
    DocumentIds beforeDelete(file);
    finished = false;
    wanted = 2;
    simulation.submit(file, wanted);
    QTimer::singleShot(5000, &loop, &QEventLoop::quit);
    loop.exec();
    require(finished && currentTime == priorTime,
            "Adding a component restarted simulation");
    file.pages[0].gates.erase(file.pages[0].gates.begin());
    DocumentIds afterDelete(file);
    require(beforeDelete.gates.at("2") == afterDelete.gates.at("2"),
            "Deleting a component changed another gate's identity");
    require(afterDelete.gateUuids.at(beforeDelete.gates.at("2")) == "2" &&
                !afterDelete.gateUuids.count(beforeDelete.gates.at("1")),
            "Reverse gate lookup retained a deleted gate or lost a surviving gate");
    finished = false;
    wanted = 3;
    simulation.submit(file, wanted);
    QTimer::singleShot(5000, &loop, &QEventLoop::quit);
    loop.exec();
    require(finished && currentTime == priorTime,
            "Deleting a component restarted simulation");
    finished = false;
    wanted = 4;
    simulation.submit(file, wanted, true);
    QTimer::singleShot(5000, &loop, &QEventLoop::quit);
    loop.exec();
    require(finished && currentTime == 0,
            "Opening a new document did not reset simulation");
    std::cout << "All gate definitions, accent isolation, file roundtrip and "
                 "worker smoke tests passed\n";
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
