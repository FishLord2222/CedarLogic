#include "Canvas.h"
#include "Appearance.h"
#include "Editor.h"
#include "Settings.h"
#include "render/RenderStyle.h"
#include "render/SkiaProbe.h"
#include <QFile>
#include <QCursor>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QHoverEvent>
#include <QPainter>
#include <QQuickWindow>
#include <QSvgRenderer>
#include <QWheelEvent>
#include <cmath>
using namespace cl::render;
namespace {
QImage raster(int w, int h, const Color &clear,
              const std::function<void(Scene &)> &draw, float strokeScale = 1) {
  if (w < 1 || h < 1)
    return {};
  std::vector<unsigned char> pixels(static_cast<size_t>(w) * h * 3);
  if (!skiaRenderToRGB(w, h, draw, pixels.data(), clear, strokeScale))
    return {};
  return QImage(pixels.data(), w, h, w * 3, QImage::Format_RGB888).copy();
}
} // namespace
Canvas::Canvas(QQuickItem *parent) : QQuickPaintedItem(parent) {
  setAcceptedMouseButtons(Qt::AllButtons);
  setAcceptHoverEvents(true);
  setAntialiasing(true);
  frameTimer.setSingleShot(true);
  connect(&frameTimer, &QTimer::timeout, this, [this] { invalidate(); });
  connect(this, &QQuickItem::widthChanged, this, &Canvas::invalidate);
  connect(this, &QQuickItem::heightChanged, this, &Canvas::invalidate);
}
void Canvas::setEditor(Editor *value) {
  if (model)
    disconnect(model, nullptr, this, nullptr);
  model = value;
  if (model) {
    connect(model, &Editor::sceneChanged, this, &Canvas::invalidate);
    connect(model, &Editor::changed, this, [this, previous = QString()]() mutable {
      if (model->editingLocked() || !model->placement().isEmpty() || model->isPastePending())
        clearWirePreview();
      update(); // Hover indicators also depend on placement and editing lock.
      if (model->placement().isEmpty() && previous.isEmpty()) return;
      previous = model->placement();
      if (!miniature && window()) {
        cursorPosition = mapFromScene(window()->mapFromGlobal(QCursor::pos()));
        cursorInside = boundingRect().contains(cursorPosition);
      }
      invalidate();
    });
    connect(model, &Editor::frameReady, this, [this] {
      if (!frameTimer.isActive())
        frameTimer.start(std::max(1, appConfig().appSettings.refreshRate));
    });
    connect(model,&Editor::pastePlacementRequested,this,[this](QPointF anchor){if(!miniature){pasteAnchor=anchor;setAcceptHoverEvents(true);forceActiveFocus();}});
    connect(model,&Editor::pageAboutToChange,this,[this]{clearWirePreview();if(!miniature)model->rememberView({{"x",center.x()},{"y",center.y()},{"scale",scale}});});
    connect(model,&Editor::pageActivated,this,[this]{
      if(miniature)return;auto view=model->pageView();
      if(view.isEmpty())fit();else{center={view["x"].toDouble(),view["y"].toDouble()};scale=view["scale"].toDouble();invalidate();emit cameraChanged();}
    });
    connect(model, &Editor::cameraFitRequested, this,
            [this] { QTimer::singleShot(0, this, &Canvas::fit); });
  }
  emit editorChanged();
  invalidate();
}
void Canvas::setAppearance(Appearance *value) {
  theme = value;
  if (theme)
    connect(theme, &Appearance::changed, this, &Canvas::invalidate);
  emit appearanceChanged();
  invalidate();
}
void Canvas::setMainCanvas(Canvas *v) {
  if (main) disconnect(main, nullptr, this, nullptr);
  main = v;
  if (main) {
    connect(main, &Canvas::cameraChanged, this, &Canvas::invalidate);
    connect(main, &QQuickItem::widthChanged, this, &Canvas::invalidate);
    connect(main, &QQuickItem::heightChanged, this, &Canvas::invalidate);
    connect(main, &QObject::destroyed, this, [this] { main = nullptr; invalidate(); });
  }
  emit overviewChanged();
  invalidate();
}
void Canvas::invalidate() {
  invalid = true;
  update();
}
Transform Canvas::camera(int w, int h) const {
  Transform t;
  double ratio = width() > 0 ? w / width() : 1;
  double s = scale * ratio;
  QPointF c = center;
  if (miniature && model && w > 0 && h > 0) {
    auto b = model->bounds();
    // Original klsMiniMap::setViewport fits both the circuit and the main
    // viewport, with a five-world-unit margin and preserved aspect ratio.
    if (main && main->width() > 0 && main->height() > 0)
      b = b.united(main->visibleWorld());
    b.adjust(-5, -5, 5, 5);
    s = std::min(w / b.width(), h / b.height());
    c = b.center();
  }
  t.a = s;
  t.d = -s;
  t.e = w / 2 - c.x() * s;
  t.f = h / 2 + c.y() * s;
  return t;
}
QPointF Canvas::toWorld(QPointF p) const {
  if (!miniature)
    return {center.x() + (p.x() - width() / 2) / scale,
            center.y() - (p.y() - height() / 2) / scale};
  const auto t = camera(width(), height());
  return {(p.x() - t.e) / t.a, (p.y() - t.f) / t.d};
}
QRectF Canvas::visibleWorld() const {
  return QRectF(toWorld({0, height()}), toWorld({width(), 0})).normalized();
}
QImage Canvas::renderImage(int w, int h, bool grid) {
  if (!model)
    return {};
  auto style = RenderStyle::screen(theme && theme->dark());
  style.showGrid =
      grid && !miniature && appConfig().appSettings.gridlineVisible;
  style.showSelection = !miniature;
  auto t = camera(w, h);
  return raster(
      w, h, style.background(),
      [&](Scene &scene) {
        scene.setViewport(t);
        if (style.showGrid) {
          auto loX = -t.e / t.a, hiX = (w - t.e) / t.a, loY = (h - t.f) / t.d,
               hiY = -t.f / t.d;
          double ratio = width() > 0 ? w / width() : 1;
          double spacing = std::max(1L, static_cast<long>(13 * ratio / t.a));
          std::vector<Point> lines;
          for (double x = std::ceil(loX / spacing) * spacing; x <= hiX;
               x += spacing) {
            lines.push_back({static_cast<float>(x), static_cast<float>(loY)});
            lines.push_back({static_cast<float>(x), static_cast<float>(hiY)});
          }
          for (double y = std::ceil(loY / spacing) * spacing; y <= hiY;
               y += spacing) {
            lines.push_back({static_cast<float>(loX), static_cast<float>(y)});
            lines.push_back({static_cast<float>(hiX), static_cast<float>(y)});
          }
          scene.lines(lines, Stroke(style.gridColor()));
        }
        model->draw(scene, style);
        if (!miniature && cursorInside && !model->placement().isEmpty())
          model->drawPlacement(scene, style, toWorld(cursorPosition));
      },
      width() > 0 ? w / width() : 1);
}
void Canvas::paint(QPainter *painter) {
  if (!model || !theme)
    return;
  double dpr = window() ? window()->devicePixelRatio() : 1;
  int w = qRound(width() * dpr), h = qRound(height() * dpr);
  if (invalid || cache.size() != QSize(w, h)) {
    cache = renderImage(w, h);
    invalid = false;
  }
  painter->drawImage(boundingRect(), cache);
  if (miniature && main) {
    auto t = camera(width(), height());
    auto b = main->visibleWorld();
    QRectF rect(QPointF(t.a * b.left() + t.e, t.d * b.bottom() + t.f),
                QPointF(t.a * b.right() + t.e, t.d * b.top() + t.f));
    painter->setPen(QPen(theme->accent(), 1.5));
    painter->setBrush(Qt::NoBrush);
    painter->drawRect(rect.normalized());
  }
  if (boxing) {
    painter->setPen(QPen(QColor::fromRgbF(0, 0.4, 1), 1));
    painter->setBrush(QColor::fromRgbF(0, 0.4, 1, 0.3));
    painter->drawRect(selectionBox.normalized());
  }
  if (!miniature && cursorInside && !model->editingLocked() && !wireStart.isEmpty()) {
    auto t = camera(width(), height());
    QPointF a(t.a * wireStart["x"].toDouble() + t.e,
              t.d * wireStart["y"].toDouble() + t.f);
    // Match GUICanvas::drawOverlaysInto: a live straight green line from
    // the source hotspot to the cursor. The real router runs on connection.
    painter->setPen(QPen(QColor::fromRgbF(0, 0.78, 0), 1));
    painter->drawLine(a, wireEnd);
  }
  if (!miniature && cursorInside && !model->editingLocked() &&
      model->placement().isEmpty() && !model->isPastePending() &&
      !panning && !dragging && !boxing && !wireDragging) {
    // Match the original transient hotspot square and wire-hover X. Query the
    // live model so deleting a gate/wire cannot leave a stale indicator behind.
    const auto world = toWorld(cursorPosition);
    const auto pin = model->pinAt(world, 5.0 / scale);
    painter->save();
    painter->setPen(QPen(Qt::red, 1));
    painter->setBrush(Qt::NoBrush);
    if (!pin.isEmpty()) {
      auto t = camera(width(), height());
      QPointF p(t.a * pin["x"].toDouble() + t.e,
                t.d * pin["y"].toDouble() + t.f);
      painter->drawRect(QRectF(p - QPointF(3, 3), QSizeF(6, 6)));
    }
    if (model->hasWireAt(world, 5.0 / scale)) {
      painter->drawLine(cursorPosition + QPointF(-3, -3),
                        cursorPosition + QPointF(3, 3));
      painter->drawLine(cursorPosition + QPointF(-3, 3),
                        cursorPosition + QPointF(3, -3));
    }
    painter->restore();
  }
  if (!miniature && cursorInside && !model->editingLocked() && !panning &&
      !boxing && !wireDragging) {
    auto points = model->pendingAutoConnections(toWorld(cursorPosition));
    if (!wireStart.isEmpty() && model->placement().isEmpty() && !model->isPastePending()) {
      const auto target = model->connectionTarget(wireStart, toWorld(cursorPosition), 6.0 / scale);
      if (!target.isEmpty()) points.append(target);
    }
    // Transient blue rings are connection feedback, separate from signal-state
    // colors. Keep their screen size constant and out of exports/minimap.
    painter->save();
    painter->setPen(QPen(QColor::fromRgbF(.3, .3, 1), 1.5));
    painter->setBrush(Qt::NoBrush);
    const auto t = camera(width(), height());
    for (const auto &value : points) {
      const auto point = value.toMap();
      painter->drawEllipse(QPointF(t.a * point["x"].toDouble() + t.e,
                                  t.d * point["y"].toDouble() + t.f), 7, 7);
    }
    painter->restore();
  }
}
void Canvas::fit() {
  if (!model || width() < 1 || height() < 1)
    return;
  auto b = model->bounds();
  center = b.center();
  scale = qBound(
      0.01, std::min((width() - 60) / b.width(), (height() - 60) / b.height()),
      36.0);
  invalidate();
  emit cameraChanged();
}
void Canvas::zoomBy(double factor) {
  scale = qBound(0.01, scale * factor, 160.0);
  invalidate();
  emit cameraChanged();
}
void Canvas::place(double x, double y) {
  if (model)
    model->placeAt(toWorld({x, y}));
}
void Canvas::clearWirePreview() {
  wireStart.clear();
  connectionPressed = connectionDragged = false;
}
void Canvas::cancel() {
  if (model) {
    model->finishPaste(false);
    model->cancelMove();
    model->setPlacement("");
  }
  clearWirePreview();
  boxing = false;
  dragging = false;
  wireDragging = false;
  panning = false;
  update();
}
void Canvas::navigateOverview(QPointF position) {
  main->center = toWorld(position);
  main->invalidate();
  emit main->cameraChanged();
}
void Canvas::mousePressEvent(QMouseEvent *e) {
  if (!model)
    return;
  if (miniature) {
    if (main && e->button() == Qt::LeftButton) {
      navigateOverview(e->position());
      main->forceActiveFocus();
    }
    e->accept();
    return;
  }
  forceActiveFocus();
  press = e->position();
  cursorPosition = press;
  cursorInside = boundingRect().contains(press);
  worldPress = toWorld(press);
  originalCenter = center;
  if(model->isPastePending() && e->button()==Qt::LeftButton){model->finishPaste(true);return;}
  if (e->button() == Qt::MiddleButton ||
      (e->button() == Qt::RightButton &&
       !appConfig().appSettings.rightClickRotate)) {
    panning = true;
    update();
    return;
  }
  if (e->button() == Qt::RightButton) {
    auto pin=model->pinAt(worldPress,6.0/scale);
    if(!model->disconnectPin(pin) && !model->deleteWireAt(worldPress,6.0/scale)){model->selectAt(worldPress);model->rotateSelection();}
    return;
  }
  if (!model->placement().isEmpty()) {
    model->placeAt(worldPress);
    return;
  }
  auto pin = model->pinAt(worldPress, 6.0 / scale);
  if (!pin.isEmpty()) {
    if (wireStart.isEmpty()) {
      wireStart = pin;
      wireEnd = press;
      connectionPressed = true;
      connectionDragged = false;
    } else {
      try {
        model->connectPins(wireStart, pin);
      } catch (const std::exception &ex) {
        model->setStatus(ex.what());
      }
      clearWirePreview();
    }
    update();
    return;
  }
  if (!wireStart.isEmpty()) {
    try {
      model->connectPinToWire(wireStart, worldPress, 6.0 / scale);
    } catch (const std::exception &ex) {
      model->setStatus(ex.what());
    }
    clearWirePreview();
    update();
    return;
  }
  bool additive = e->modifiers() & (Qt::ShiftModifier|Qt::ControlModifier);
  if (model->selectAt(worldPress, additive)) {
    model->startMove();
    dragging = true;
  } else if (model->startWireMove(worldPress, 5.0 / scale)) {
    wireDragging = true;
  } else {
    boxing = true;
    selectionBox = QRectF(press, press);
  }
  update();
}
void Canvas::mouseMoveEvent(QMouseEvent *e) {
  if (miniature) {
    if (main && (e->buttons() & Qt::LeftButton)) navigateOverview(e->position());
    e->accept();
    return;
  }
  if (!model) return;
  auto pos = e->position();
  cursorPosition = pos; cursorInside = boundingRect().contains(pos);
  if (connectionPressed && (pos - press).manhattanLength() > 3)
    connectionDragged = true;
  if (!model->placement().isEmpty()) invalidate();
  wireEnd = pos;
  if(model->isPastePending()){auto delta=toWorld(pos)-pasteAnchor;model->moveSelected({std::round(delta.x()*2)/2,std::round(delta.y()*2)/2});return;}
  if (panning) {
    center = originalCenter + QPointF(-(pos.x() - press.x()) / scale,
                                      (pos.y() - press.y()) / scale);
    invalidate();
    emit cameraChanged();
  } else if (dragging) {
    auto delta = toWorld(pos) - worldPress;
    model->moveSelected(
        {std::round(delta.x() * 2) / 2, std::round(delta.y() * 2) / 2});
  } else if (wireDragging) {
    model->moveWire(toWorld(pos));
  } else if (boxing) {
    selectionBox = QRectF(press, pos);
    update();
  } else if (!wireStart.isEmpty())
    update();
}
void Canvas::hoverEnterEvent(QHoverEvent *e) {
  cursorInside = true; cursorPosition = e->position();
  wireEnd = e->position(); invalidate(); e->accept();
}
void Canvas::hoverLeaveEvent(QHoverEvent *e) {
  cursorInside = false; invalidate(); e->accept();
}
void Canvas::hoverMoveEvent(QHoverEvent *e) {
  cursorInside = true; cursorPosition = e->position();
  if (!wireStart.isEmpty()) wireEnd = e->position();
  update(); // Repaint overlays without rerasterizing the circuit on each hover.
  if(model && !miniature && model->isPastePending()) {
    auto delta=toWorld(e->position())-pasteAnchor;
    model->moveSelected({std::round(delta.x()*2)/2,std::round(delta.y()*2)/2});
  }
  if (model && !model->placement().isEmpty()) invalidate();
  e->accept();
}
void Canvas::mouseReleaseEvent(QMouseEvent *e) {
  if (miniature) { e->accept(); return; }
  if (!model)
    return;
  cursorPosition = e->position();
  cursorInside = boundingRect().contains(cursorPosition);
  if (e->button() == Qt::LeftButton && connectionPressed) {
    // A click may continue in click-to-connect mode. An actual drag ends on
    // release, even over empty space, outside the canvas, or back at its source.
    const bool endedDrag = connectionDragged || !cursorInside ||
                           (e->position() - press).manhattanLength() > 3;
    if (!wireStart.isEmpty() && endedDrag) {
      if (cursorInside && !model->editingLocked()) {
        try {
          const auto point = toWorld(e->position());
          const auto end = model->pinAt(point, 6.0 / scale);
          if (!end.isEmpty())
            model->connectPins(wireStart, end);
          else
            model->connectPinToWire(wireStart, point, 6.0 / scale);
        } catch (const std::exception &ex) {
          model->setStatus(ex.what());
        }
      }
      clearWirePreview();
    }
    connectionPressed = connectionDragged = false;
  }
  if (dragging) {
    auto delta = e->position() - press;
    model->finishMove();
    if (delta.manhattanLength() < 3)
      model->interactAt(toWorld(e->position()));
  }
  if (wireDragging)
    model->finishWireMove();
  wireDragging = false;
  if (boxing)
    model->selectBox(QRectF(toWorld(selectionBox.topLeft()),
                            toWorld(selectionBox.bottomRight()))
                         .normalized(),
                     e->modifiers() & (Qt::ShiftModifier|Qt::ControlModifier));
  dragging = false;
  boxing = false;
  panning = false;
  update();
}
void Canvas::mouseUngrabEvent() {
  // A popup or another item can steal a held drag without sending a release.
  // Roll back its live geometry now, so the next click cannot finish an old
  // gesture or leave a route on screen that was never captured in the file.
  if (dragging || wireDragging) {
    if (model) model->cancelMove();
    dragging = wireDragging = false;
    invalidate();
  }
  boxing = panning = false;
  // Normal release resets connectionPressed first; only an interrupted held
  // gesture is canceled here, preserving intentional click-to-connect mode.
  if (connectionPressed) {
    clearWirePreview();
    update();
  }
  update();
  QQuickPaintedItem::mouseUngrabEvent();
}
void Canvas::mouseDoubleClickEvent(QMouseEvent *e) {
  if (model && !miniature && e->button() == Qt::LeftButton &&
      model->placement().isEmpty() && !model->isPastePending() && wireStart.isEmpty()) {
    model->finishMove();
    dragging = boxing = wireDragging = false;
    if (model->selectEditableAt(toWorld(e->position())))
      emit propertiesRequested();
  }
  e->accept();
}
void Canvas::wheelEvent(QWheelEvent *e) {
  if (miniature)
    return;
  auto before = toWorld(e->position());
  scale = qBound(0.5, scale * std::pow(1.0015, e->angleDelta().y()), 160.0);
  center += before - toWorld(e->position());
  invalidate();
  emit cameraChanged();
  e->accept();
}
void Canvas::keyPressEvent(QKeyEvent *e) {
  if (miniature || !model || (e->modifiers() & (Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier))) {
    QQuickPaintedItem::keyPressEvent(e);
    return;
  }
  switch (e->key()) {
    case Qt::Key_Escape: cancel(); break;
    case Qt::Key_Left: center.rx() -= 30.0 / scale; break;
    case Qt::Key_Right: center.rx() += 30.0 / scale; break;
    case Qt::Key_Up: center.ry() += 30.0 / scale; break;
    case Qt::Key_Down: center.ry() -= 30.0 / scale; break;
    case Qt::Key_Plus: case Qt::Key_Equal: zoomBy(1.2); break;
    case Qt::Key_Minus: zoomBy(1 / 1.2); break;
    case Qt::Key_Space: fit(); break;
    case Qt::Key_Delete: case Qt::Key_Backspace: model->deleteSelection(); break;
    case Qt::Key_T: model->convertToFrom(true);break;
  case Qt::Key_F: model->convertToFrom(false);break;
  case Qt::Key_R: model->rotateSelection(); break;
    case Qt::Key_A: if (!model->editingLocked()) emit quickAddRequested(); break;
    default: QQuickPaintedItem::keyPressEvent(e); return;
  }
  invalidate();
  emit cameraChanged();
  e->accept();
}
QImage GateImages::requestImage(const QString &id, QSize *size,
                                const QSize &requested) {
  const auto parts = id.split('/');
  const QString name = parts[0];
  const bool dark = parts.value(1) == "dark";
  const int w = qBound(16, requested.width() > 0 ? requested.width() : 144, 512);
  const int h = qBound(16, requested.height() > 0 ? requested.height() : 144, 512);
  const QString key = QString("%1/%2/%3x%4").arg(name).arg(dark).arg(w).arg(h);
  QMutexLocker lock(&thumbnailMutex);
  if (const auto cached = thumbnails.object(key)) {
    if (size) *size = cached->size();
    return *cached;
  }
  try {
    auto g = makeGate(name.toStdString());
    auto box = g->getModelDrawBBox();
    auto lo = box.getBottomLeft(), hi = box.getTopRight();
    double dx = std::max(1.0f, hi.x - lo.x), dy = std::max(1.0f, hi.y - lo.y),
           s = std::min((w - 20) / dx, (h - 20) / dy);
    Transform t;
    t.a = s;
    t.d = -s;
    t.e = w / 2 - (lo.x + hi.x) / 2 * s;
    t.f = h / 2 + (lo.y + hi.y) / 2 * s;
    auto style = RenderStyle::screen(dark);
    style.showSelection = false;
    Color clear = dark ? Color(0.137f, 0.153f, 0.176f) : Color(1, 1, 1);
    auto out = raster(
        w, h, clear,
        [&](Scene &scene) {
          scene.setViewport(t);
          g->drawToScene(scene, style);
        },
        2.0f);
    if (size)
      *size = out.size();
    if (!out.isNull())
      thumbnails.insert(key, new QImage(out), int((out.sizeInBytes() + 1023) / 1024));
    return out;
  } catch (...) {
    return {};
  }
}

QImage Icons::requestImage(const QString &id, QSize *size,
                           const QSize &requested) {
  auto parts = id.split('/');
  if (parts.size() != 2)
    return {};
  QFile file(QString::fromStdString(appConfig().resourcesDir) + "/icons/" +
             parts[0] + ".svg");
  if (!file.open(QIODevice::ReadOnly))
    return {};
  auto svg = file.readAll();
  svg.replace("#333333", ("#" + parts[1]).toUtf8());
  QSvgRenderer renderer(svg);
  QSize target = requested.isValid() ? requested : QSize(48, 48);
  QImage image(target, QImage::Format_ARGB32_Premultiplied);
  image.fill(Qt::transparent);
  QPainter painter(&image);
  renderer.render(&painter);
  if (size)
    *size = target;
  return image;
}

void Waveforms::paint(QPainter *painter) {
  if (!model || !theme)
    return;
  painter->fillRect(boundingRect(), theme->background());
  auto traces = model->traces();
  if (traces.isEmpty()) {
    painter->setPen(theme->muted());
    painter->drawText(boundingRect(), Qt::AlignCenter,
                      "Add a signal to capture its waveform.");
    return;
  }
  int row = 0;
  for (auto trace : traces) {
    auto data = trace.toMap();
    auto values = data["values"].toList();
    int y = row * 48;
    if (y + 48 > height())
      break;
    painter->setPen(theme->muted());
    painter->drawText(QRectF(10, y, 130, 48), Qt::AlignVCenter | Qt::AlignLeft,
                      data["name"].toString());
    painter->setPen(theme->border());
    painter->drawLine(150, y + 40, width(), y + 40);
    double dx = std::max(2.0, (width() - 160) / 256.0);
    int n = values.size();
    double start = width() - n * dx;
    auto neutral = theme->text();
    auto color = [&](int state) {
      switch (state) {
      case ONE:
        return QColor::fromRgbF(1, 0, 0);
      case HI_Z:
        return QColor::fromRgbF(0, 0.78, 0);
      case UNKNOWN:
        return QColor::fromRgbF(0.3, 0.3, 1);
      case CONFLICT:
        return QColor::fromRgbF(0, 1, 1);
      default:
        return neutral;
      }
    };
    for (int i = 0; i < n; ++i) {
      int state = values[i].toInt();
      double x = start + i * dx;
      double yy = y + (state == ONE ? 10 : state == ZERO ? 36 : 23);
      painter->setPen(QPen(color(state), 1));
      if (state == UNKNOWN || state == CONFLICT)
        painter->fillRect(QRectF(x, y + 10, dx, 26), color(state));
      else
        painter->drawLine(QPointF(x, yy), QPointF(x + dx, yy));
      if (i && state != values[i - 1].toInt()) {
        double previous = y + (values[i - 1].toInt() == ONE    ? 10
                               : values[i - 1].toInt() == ZERO ? 36
                                                               : 23);
        painter->drawLine(QPointF(x, previous), QPointF(x, yy));
      }
    }
    ++row;
  }
}
