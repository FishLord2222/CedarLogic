#pragma once
#include "SharedModel.h"
#include <QObject>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <thread>
struct SimulationFrame {
  unsigned long generation = 0;
  TimeType time = 0;
  std::map<IDType, StateType> wires;
  std::vector<std::map<IDType,StateType>> samples;
  struct Param {
    unsigned long gate;
    std::string name, value;
  };
  std::vector<Param> params;
  std::string error;
};
class Simulation : public QObject {
  Q_OBJECT
public:
  explicit Simulation(QObject *parent = nullptr);
  ~Simulation();
  void submit(cl::CircuitFile file, unsigned long generation,
              bool reset = false);
  void setRunning(bool value);
  void step(int count = 1);
  void setGateParameter(unsigned long gate, const std::string &name, const std::string &value);
  void setInterval(int ms);
  std::function<void(const SimulationFrame &)> onFrame;

private:
  std::thread worker;
  std::mutex mutex;
  std::condition_variable wake;
  bool stopping = false, running = false, pending = false,
       resetRequested = false;
  int steps = 0, interval = 25;
  unsigned long generation = 0;
  cl::CircuitFile next;
  std::vector<SimulationFrame::Param> commands;
  void loop();
};
