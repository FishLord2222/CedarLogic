import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
Dialog {
    id: help
    title:"Keyboard shortcuts";modal:true;parent:Overlay.overlay;anchors.centerIn:parent
    width:Math.min(690,parent.width-24);height:Math.min(590,parent.height-24)
    property int section:0
    property var groups:[
        {title:"Files",rows:[
            ["Ctrl + N","New circuit"],["Ctrl + O","Open circuit"],["Ctrl + Shift + O","Open in another window"],
            ["Ctrl + S","Save"],["Ctrl + Shift + S","Save as"],["Ctrl + E","Export image"],
            ["Ctrl + T","New page"],["Ctrl + W","Close current page"],["Ctrl + Q","Quit"]]},
        {title:"Editing",rows:[
            ["Ctrl + Z","Undo"],["Ctrl + Shift + Z / Ctrl + Y","Redo"],["Ctrl + A","Select all"],
            ["Ctrl + X","Cut"],["Ctrl + C","Copy"],["Ctrl + V","Paste"],
            ["A","Add component"],["Delete / Backspace","Delete selection"],["R","Rotate unconnected gates"],
            ["T / F","Convert selection to TO / FROM"],["Ctrl + I","Gate properties"],
            ["Esc","Cancel placement or wiring"],["Ctrl + ,","Preferences"]]},
        {title:"Navigation",rows:[
            ["Arrow keys","Pan the circuit"],["+ / −","Zoom in / out"],["Ctrl + = / Ctrl + −","Zoom in / out"],
            ["Space / Ctrl + 0","Fit circuit"],["Ctrl + F","Search gates"],["Ctrl + B","Show / hide sidebar"],
            ["Middle-button drag","Pan the circuit"],["Mouse wheel","Zoom at the cursor"],
            ["Shift / Ctrl + click","Add to selection"],["Right-click pin","Disconnect a connected pin"],
            ["Right-click wire","Delete a wire"],["Double-click component","Edit available properties"],["F1","Open tutorial"]]},
        {title:"Simulation",rows:[
            ["F5","Run / pause simulation"],["F6","Advance one step"],["Ctrl + G","Show / hide oscilloscope"]]}
    ]
    background:Rectangle { radius:8;color:theme.panel;border.color:theme.border }
    header:Label { text:help.title;color:theme.text;font.pixelSize:20;font.weight:Font.DemiBold;padding:20 }
    footer:RowLayout {
        spacing:8
        Item { Layout.fillWidth:true }
        AppButton { text:"Close";Layout.rightMargin:16;Layout.bottomMargin:12;onClicked:help.close() }
    }
    contentItem:ColumnLayout {
        spacing:16
        RowLayout {
            Layout.fillWidth:true;spacing:6
            Repeater {
                model:help.groups
                delegate:Button {
                    required property var modelData
                    required property int index
                    text:modelData.title;Layout.fillWidth:true;implicitHeight:34
                    onClicked:{help.section=index;rows.contentItem.contentY=0}
                    background:Rectangle { radius:5;color:help.section===index?Qt.alpha(theme.accent,0.14):parent.hovered?theme.raised:"transparent" }
                    contentItem:Label { text:parent.text;color:help.section===parent.index?theme.accent:theme.muted;font.bold:help.section===parent.index;horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter }
                }
            }
        }
        ScrollView {
            id:rows;Layout.fillWidth:true;Layout.fillHeight:true;clip:true;contentWidth:availableWidth
            ColumnLayout {
                width:rows.availableWidth;spacing:2
                Repeater {
                    model:help.groups[help.section].rows
                    delegate:Rectangle {
                        required property var modelData
                        required property int index
                        objectName:"shortcutRow"+index
                        Layout.fillWidth:true;implicitHeight:Math.max(38,Math.max(keys.implicitHeight,action.implicitHeight)+16)
                        radius:4;color:index%2===0?Qt.alpha(theme.raised,0.55):"transparent"
                        RowLayout {
                            anchors.fill:parent;anchors.leftMargin:10;anchors.rightMargin:10;spacing:16
                            Label { id:keys;objectName:"shortcutKeys"+index;text:modelData[0];Layout.preferredWidth:195;color:theme.text;font.pixelSize:12;font.weight:Font.DemiBold;wrapMode:Text.WordWrap }
                            Label { id:action;objectName:"shortcutAction"+index;text:modelData[1];Layout.fillWidth:true;color:theme.text;font.pixelSize:13;wrapMode:Text.WordWrap }
                        }
                    }
                }
            }
        }
        Label { text:"Text fields keep their own editing shortcuts.";color:theme.muted;font.pixelSize:12;Layout.fillWidth:true;wrapMode:Text.WordWrap }
    }
}
