import QtQuick
import QtCore
import QtQuick.Controls
import QtQuick.Layouts
import CedarLogic 1.0
ApplicationWindow {
    id: root
    width:1200;height:820;minimumWidth:760;minimumHeight:500
    visible:true;title:backend.title+" — CedarLogic"
    color:theme.background
    palette.window: theme.panel
    palette.windowText: theme.text
    palette.base: theme.background
    palette.text: theme.text
    palette.button: theme.raised
    palette.buttonText: theme.text
    palette.highlight: theme.accent
    palette.highlightedText: theme.dark ? "#101418" : "#ffffff"
    palette.mid: theme.border
    palette.light: theme.raised
    palette.dark: theme.border
    onClosing:function(close){close.accepted=backend.confirmClose()}
    property bool modalActive: preferences.visible||properties.visible||signDialog.visible||about.visible||quickAdd.visible||changelog.visible||shortcutHelp.visible
    property bool sidebarVisible: true
    property bool scopeVisible: false
    Settings {
        category: "window"
        property alias windowWidth: root.width
        property alias windowHeight: root.height
        property alias windowX: root.x
        property alias windowY: root.y
        property alias sidebarVisible: root.sidebarVisible
        property alias scopeVisible: root.scopeVisible
        property real sidebarWidth: 280
        property real scopeHeight: 250
        id: windowSettings
    }
    property var paletteItems: backend.palette("",backend.categories[0]||"")
    function openPreferences(){preferences.signingRequired=false;preferences.open()}
    function requestSign(){if(backend.beginSigning())signDialog.open()}
    function openChangelog(){changelog.open()}
    function openGateProperties(){if(!backend.memoryDialog())properties.open()}
    function refreshPalette(){paletteItems=backend.palette(search.text,category.currentText)}
    Action { enabled:!root.modalActive; id:newAction;property string keyHint:"Ctrl+N";text:"New";shortcut:StandardKey.New;onTriggered:backend.newDocument() }
    Action { enabled:!root.modalActive; id:openAction;property string keyHint:"Ctrl+O";text:"Open…";shortcut:StandardKey.Open;onTriggered:backend.openDialog() }
    Action { enabled:!root.modalActive; id:saveAction;property string keyHint:"Ctrl+S";text:"Save";shortcut:StandardKey.Save;onTriggered:backend.save() }
    Action { enabled:!root.modalActive; id:saveAsAction;property string keyHint:"Ctrl+Shift+S";text:"Save As…";shortcut:StandardKey.SaveAs;onTriggered:backend.saveAs() }
    Action { id:undoAction;property string keyHint:"Ctrl+Z";text:"Undo";shortcut:StandardKey.Undo;enabled:!root.modalActive&&backend.canUndo;onTriggered:backend.undo() }
    Action { id:redoAction;property string keyHint:"Ctrl+Shift+Z";text:"Redo";shortcut:StandardKey.Redo;enabled:!root.modalActive&&backend.canRedo;onTriggered:backend.redo() }
    Action { enabled:!root.modalActive; id:copyAction;property string keyHint:"Ctrl+C";text:"Copy";shortcut:StandardKey.Copy;onTriggered:backend.copy() }
    Action { enabled:!root.modalActive; id:cutAction;property string keyHint:"Ctrl+X";text:"Cut";shortcut:StandardKey.Cut;onTriggered:backend.cut() }
    Action { enabled:!root.modalActive; id:pasteAction;property string keyHint:"Ctrl+V";text:"Paste";shortcut:StandardKey.Paste;onTriggered:backend.paste(true) }
    Action { enabled:!root.modalActive; id:sidebarAction;property string keyHint:"Ctrl+B";text:"Show sidebar";shortcut:"Ctrl+B";checkable:true;checked:root.sidebarVisible;onTriggered:root.sidebarVisible=!root.sidebarVisible }
    Action { enabled:!root.modalActive; id:preferencesAction;property string keyHint:"Ctrl+,";text:"Preferences…";shortcut:"Ctrl+,";onTriggered:root.openPreferences() }
    function focusCircuit(){canvas.forceActiveFocus()}
    function findGate(){root.sidebarVisible=true;search.forceActiveFocus();search.selectAll()}
    Binding { target:keyboard;property:"blocked";value:root.modalActive }
    Connections {
        target:keyboard
        function onCommand(name) {
            switch(name) {
            case "new": backend.newDocument();break
            case "open": backend.openDialog();break
            case "openNewWindow": backend.openNewWindow();break
            case "quit": root.close();return
            case "save": backend.save();break
            case "saveAs": backend.saveAs();break
            case "undo": backend.undo();break
            case "redo": backend.redo();break
            case "cut": backend.cut();break
            case "copy": backend.copy();break
            case "paste": backend.paste(true);break
            case "selectAll": backend.selectAll();break
            case "addPage": backend.addPage();break
            case "removePage": backend.removePage();break
            case "export": backend.exportDialog();break
            case "sidebar": root.sidebarVisible=!root.sidebarVisible;break
            case "scope": root.scopeVisible=!root.scopeVisible;break
            case "search": root.findGate();return
            case "preferences": root.openPreferences();return
            case "fit": canvas.fit();break
            case "zoomIn": canvas.zoomBy(1.2);break
            case "zoomOut": canvas.zoomBy(1/1.2);break
            case "run": backend.running=!backend.running;break
            case "step": backend.step();break
            case "help": about.open();return
            case "properties": root.openGateProperties();return
            }
            root.focusCircuit()
        }
    }
    component CommandItem: MenuItem {
        id:commandItem
        property string keyHint:action && action.keyHint !== undefined ? action.keyHint : ""
        implicitHeight:28;implicitWidth:Math.max(250,implicitContentWidth+leftPadding+rightPadding)
        font.pixelSize:13;topPadding:4;bottomPadding:4;leftPadding:32;rightPadding:12
        indicator:Label {
            objectName:commandItem.objectName+"Check"
            x:8;y:(commandItem.height-height)/2;width:16;height:16
            text:commandItem.checked?"✓":"";visible:commandItem.checkable
            color:commandItem.enabled?theme.text:theme.muted
            horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter
        }
        contentItem:RowLayout {
            spacing:18
            Label { objectName:commandItem.objectName+"Label";text:commandItem.text;color:commandItem.enabled?theme.text:theme.muted;font:commandItem.font;Layout.fillWidth:true;elide:Text.ElideRight }
            Label { objectName:commandItem.objectName+"Shortcut";text:commandItem.keyHint;color:theme.muted;font.pixelSize:12;horizontalAlignment:Text.AlignRight }
        }
    }
    menuBar:MenuBar {
        objectName:"mainMenu";implicitHeight:28
        delegate:MenuBarItem { implicitHeight:28;leftPadding:10;rightPadding:10;topPadding:4;bottomPadding:4;font.pixelSize:13 }
        background:Rectangle { color:theme.panel }
        Menu { id:fileMenu;objectName:"fileMenu";title:"&File";width:340
            CommandItem { action:newAction } CommandItem { objectName:"openMenuCommand";action:openAction }
            CommandItem { text:"Open in new window…";keyHint:"Ctrl+Shift+O";onTriggered:backend.openNewWindow() }
            MenuSeparator {} CommandItem { action:saveAction } CommandItem { action:saveAsAction }
            CommandItem { text:"New tab";keyHint:"Ctrl+T";onTriggered:backend.addPage() }
            CommandItem { text:"Close tab";keyHint:"Ctrl+W";onTriggered:backend.removePage() }
            CommandItem { text:"Export as V2 (legacy XML)…";onTriggered:backend.exportLegacyDialog(2) }
            CommandItem { text:"Export as V1.x compatible…";onTriggered:backend.exportLegacyDialog(1) }
            CommandItem { text:"Sign circuit…";enabled:!backend.editingLocked;onTriggered:root.requestSign() }
            CommandItem { objectName:"exportMenuCommand";text:"Export as image…";keyHint:"Ctrl+E";onTriggered:backend.exportDialog() }
            MenuSeparator {} CommandItem { text:"Exit";keyHint:"Ctrl+Q";onTriggered:root.close() }
        }
        Menu { width:340;title:"&Edit"
            CommandItem { action:undoAction } CommandItem { action:redoAction } MenuSeparator {}
            CommandItem { action:cutAction } CommandItem { action:copyAction } CommandItem { action:pasteAction }
            CommandItem { text:"Add component…";keyHint:"A";enabled:!backend.editingLocked;onTriggered:quickAdd.open() }
            MenuSeparator {} CommandItem { action:preferencesAction }
        }
        Menu { id:viewMenu;objectName:"viewMenu";title:"&View";width:340
            CommandItem { objectName:"zoomInMenuCommand";text:"Zoom in";keyHint:"Ctrl+=";onTriggered:canvas.zoomBy(1.2) }
            CommandItem { objectName:"zoomOutMenuCommand";text:"Zoom out";keyHint:"Ctrl+-";onTriggered:canvas.zoomBy(1/1.2) }
            MenuSeparator {}
            CommandItem { objectName:"gridMenuCommand";text:"Display gridlines";checkable:true;checked:!!theme.editorSettings.grid;onTriggered:{let v=Object.assign({},theme.editorSettings);v.grid=!v.grid;theme.apply(theme.mode,theme.accentName,v)} }
            CommandItem { objectName:"connectionMenuCommand";text:"Display wire connection points";checkable:true;checked:!!theme.editorSettings.connections;onTriggered:{let v=Object.assign({},theme.editorSettings);v.connections=!v.connections;theme.apply(theme.mode,theme.accentName,v)} }
            CommandItem { objectName:"sidebarMenuCommand";action:sidebarAction }
            MenuSeparator {}
            CommandItem { objectName:"scopeMenuCommand";text:"Oscilloscope";keyHint:"Ctrl+G";checkable:true;checked:root.scopeVisible;onTriggered:root.scopeVisible=!root.scopeVisible }
            MenuSeparator {}
            CommandItem { objectName:"fitMenuCommand";text:"Fit circuit";keyHint:"Space / Ctrl+0";onTriggered:canvas.fit() }
            CommandItem { objectName:"searchMenuCommand";text:"Search gates…";keyHint:"Ctrl+F";onTriggered:root.findGate() }
            CommandItem { objectName:"sidebarNamesMenuCommand";text:"Show sidebar part names";checkable:true;checked:!!theme.editorSettings.sidebarNames;onTriggered:theme.setSidebarNames(checked) }
        }
        Menu { width:340;title:"&Help"
            CommandItem { text:"CedarLogic tutorial…";keyHint:"F1";onTriggered:about.open() }
            CommandItem { text:"Keyboard shortcuts…";onTriggered:shortcutHelp.open() }
            CommandItem { text:"Download latest version…";onTriggered:Qt.openUrlExternally("https://github.com/emonte-cu/CedarLogic/releases/latest") }
            CommandItem { text:"Changelog…";onTriggered:changelog.open() }
            CommandItem { text:"About CedarLogic…";onTriggered:about.open() }
        }
    }
    header:Rectangle {
        height:38;color:theme.panel
        Rectangle { anchors.bottom:parent.bottom;width:parent.width;height:1;color:theme.border }
        RowLayout {
            anchors.fill:parent;anchors.leftMargin:10;anchors.rightMargin:10;spacing:3
            Tool { iconName:"sidebar-collapse";hint:"Toggle sidebar (Ctrl+B)";accentActive:root.sidebarVisible;onClicked:root.sidebarVisible=!root.sidebarVisible }
            Rectangle { width:1;height:24;color:theme.border }
            Tool { objectName:"newCircuitTool";iconName:"new";hint:"New (Ctrl+N)";onClicked:backend.newDocument() }
            Tool { objectName:"openCircuitTool";iconName:"open";hint:"Open (Ctrl+O)";onClicked:backend.openDialog() }
            Tool { objectName:"openAdditionalCircuitTool";iconName:"open-circuit";hint:"Open circuit in new window (Ctrl+Shift+O)";onClicked:backend.openNewWindow() }
            Tool { objectName:"saveCircuitTool";iconName:"save";hint:"Save (Ctrl+S)";onClicked:backend.save() }
            Rectangle { width:1;height:24;color:theme.border }
            Tool { iconName:"undo";hint:"Undo (Ctrl+Z)";enabled:backend.canUndo;onClicked:backend.undo() }
            Tool { iconName:"redo";hint:"Redo (Ctrl+Shift+Z)";enabled:backend.canRedo;onClicked:backend.redo() }
            Tool { iconName:"copy";hint:"Copy";onClicked:backend.copy() }
            Tool { iconName:"paste";hint:"Paste";onClicked:backend.paste(true) }
            Rectangle { width:1;height:24;color:theme.border }
            Tool { iconName:"zoomout";hint:"Zoom out";onClicked:canvas.zoomBy(1/1.2) }
            Tool { objectName:"zoomInTool";iconName:"zoomin";hint:"Zoom in";onClicked:canvas.zoomBy(1.2) }
            Rectangle { width:1;height:24;color:theme.border }
            Tool { iconName:backend.running?"pause":"play";hint:backend.running?"Pause (F5)":"Run (F5)";accentActive:backend.running;onClicked:backend.running=!backend.running }
            Tool { iconName:"step";hint:"Simulation step (F6)";onClicked:backend.step() }
            Label { text:"Sim step";color:theme.muted;font.pixelSize:12;visible:root.width>950 }
            Slider { Layout.preferredWidth:120;visible:root.width>1000;from:1;to:500;value:theme.editorSettings.stepMs||25;onMoved:theme.setStepInterval(Math.round(value)) }
            Label { text:(theme.editorSettings.stepMs||25)+" ms";color:theme.muted;font.pixelSize:12 }
            Item { Layout.fillWidth:true }
            Tool { iconName:backend.editingLocked?"locked":"unlocked";accentActive:backend.editingLocked;hint:"Lock circuit editing";onClicked:backend.editingLocked=!backend.editingLocked }
            Tool { iconName:"settings";hint:"Preferences";onClicked:root.openPreferences() }
        }
    }
    SplitView {
        onResizingChanged: if(!resizing && sidebar.visible) windowSettings.sidebarWidth=sidebar.width
        anchors.fill:parent
        handle:Rectangle { implicitWidth:6;implicitHeight:6;color:SplitHandle.hovered?Qt.alpha(theme.accent,0.3):theme.background }
        Rectangle {
            id:sidebar;visible:root.sidebarVisible;color:theme.panel
            SplitView.preferredWidth:windowSettings.sidebarWidth;SplitView.minimumWidth:210;SplitView.maximumWidth:460
            ColumnLayout {
                anchors.fill:parent;anchors.margins:10;spacing:10
                AppField {
                    id:search;Layout.fillWidth:true;implicitHeight:38
                    placeholderText:"Search gates…";leftPadding:32
                    onTextChanged:root.refreshPalette()
                    objectName:"gateSearch"
                    Keys.onEscapePressed:function(event){root.focusCircuit();event.accepted=true}
                    background:Rectangle { radius:5;color:theme.background;border.color:search.activeFocus?theme.accent:theme.border }
                    Image { width:16;height:16;x:10;anchors.verticalCenter:parent.verticalCenter;source:"image://icons/search/"+theme.muted.toString().substring(1);sourceSize:Qt.size(32,32) }
                }
                AppCombo { id:category;objectName:"categoryCombo";Layout.fillWidth:true;model:backend.categories;onActivated:root.refreshPalette();Component.onCompleted:root.refreshPalette() }
                GridView {
                    id:gates;objectName:"sidebarParts";Layout.fillWidth:true;Layout.fillHeight:true;clip:true
                    property bool showNames:!!theme.editorSettings.sidebarNames
                    cellWidth:width/(showNames?Math.max(2,Math.min(4,Math.floor(width/92))):4)
                    cellHeight:showNames?108:cellWidth
                    // Scale the existing image during a resize, then render once
                    // at the settled dimensions instead of on every mouse move.
                    property size thumbnailSize: Qt.size(144, 144)
                    function updateThumbnailSize() {
                        thumbnailSize = Qt.size(Math.max(16, Math.round((cellWidth - 18) * 2)),
                                                Math.max(16, Math.round((showNames ? 58 : cellHeight - 18) * 2)))
                    }
                    onCellWidthChanged: thumbnailResize.restart()
                    onCellHeightChanged: thumbnailResize.restart()
                    Component.onCompleted: updateThumbnailSize()
                    Timer {
                        id: thumbnailResize
                        interval: 100
                        onTriggered: gates.updateThumbnailSize()
                    }
                    model:root.paletteItems
                    ScrollBar.vertical:ScrollBar { }
                    delegate:PartTile {
                        width: gates.cellWidth
                        height: gates.cellHeight
                        showNames: gates.showNames
                        thumbnailSize: gates.thumbnailSize
                        placementArea: canvas
                        isSelected: backend.placement === gateName
                        onPicked: function(name) {
                            backend.placement = name
                            root.focusCircuit()
                        }
                        onDragStarted: function(name) { backend.placement = name }
                        onDragFinished: function(scenePosition) {
                            const p = canvas.mapFromItem(null, scenePosition.x, scenePosition.y)
                            if (p.x >= 0 && p.y >= 0 && p.x < canvas.width && p.y < canvas.height)
                                canvas.place(p.x, p.y)
                            backend.placement = ""
                        }
                    }
                    Label { anchors.centerIn:parent;visible:gates.count===0;text:"No matching gates";color:theme.muted }
                }
                Rectangle {
                    Layout.fillWidth:true;Layout.preferredHeight:132;radius:5;color:theme.background;border.color:theme.border
                    CircuitCanvas { objectName:"circuitOverview";anchors.fill:parent;anchors.margins:5;editor:backend;appearance:theme;overview:true;mainCanvas:canvas }
                }
            }
        }
        ColumnLayout {
            SplitView.fillWidth:true;spacing:0
            Rectangle {
                objectName:"pageStrip";Layout.fillWidth:true;Layout.preferredHeight:28;color:theme.panel
                RowLayout {
                    anchors.fill:parent;spacing:0
                    Flickable {
                        id:pageScroll;Layout.fillWidth:true;Layout.fillHeight:true;clip:true
                        contentWidth:pageRow.width;contentHeight:height;flickableDirection:Flickable.HorizontalFlick
                        Row {
                            id:pageRow;height:parent.height;spacing:1
                            Repeater {
                                model:backend.pages
                                delegate:Button {
                                    id:pageButton
                                    required property int index;required property string modelData
                                    text:modelData;height:28;width:Math.max(88,Math.min(145,implicitContentWidth+16))
                                    padding:6;focusPolicy:Qt.NoFocus;font.pixelSize:12
                                    onClicked:{backend.currentPage=index;root.focusCircuit()}
                                    background:Rectangle {
                                        color:backend.currentPage===pageButton.index?theme.background:pageButton.hovered?theme.raised:"transparent"
                                        Rectangle { anchors.bottom:parent.bottom;width:parent.width;height:2;color:theme.accent;visible:backend.currentPage===pageButton.index }
                                    }
                                    contentItem:RowLayout {
                                        spacing:5
                                        Label { text:pageButton.text;color:backend.currentPage===pageButton.index?theme.text:theme.muted;font:pageButton.font;Layout.fillWidth:true;verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight }
                                        Button {
                                            objectName:"pageClose"+pageButton.index
                                            Layout.preferredWidth:20;Layout.preferredHeight:20
                                            focusPolicy:Qt.NoFocus;enabled:backend.pages.length>1 && !backend.editingLocked
                                            text:"×";font.pixelSize:17
                                            background:Rectangle { radius:4;color:parent.hovered?theme.raised:"transparent" }
                                            contentItem:Label { text:parent.text;font:parent.font;color:parent.enabled?theme.muted:Qt.alpha(theme.muted,0.4);horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter }
                                            onClicked:{root.focusCircuit();backend.removePage(pageButton.index)}
                                            ToolTip.visible:hovered;ToolTip.text:"Close page (Ctrl+W)"
                                        }
                                    }
                                }
                            }
                            Tool { iconName:"newtab";implicitWidth:28;implicitHeight:28;hint:"Add page (Ctrl+T)";onClicked:{backend.addPage();root.focusCircuit()} }
                        }
                    }
                }
            }
            SplitView {
                id:workspaceSplit;objectName:"workspaceSplit"
                Layout.fillWidth:true;Layout.fillHeight:true;orientation:Qt.Vertical
                onResizingChanged:if(!resizing && root.scopeVisible)windowSettings.scopeHeight=scopePanel.height
                handle:Rectangle {
                    objectName:"scopeDivider";implicitHeight:8;color:theme.panel
                    Rectangle { anchors.centerIn:parent;width:42;height:3;radius:1.5;color:parent.SplitHandle.hovered||parent.SplitHandle.pressed?theme.accent:theme.border }
                    HoverHandler { cursorShape:Qt.SizeVerCursor }
                }
            CircuitCanvas { id:canvas;objectName:"circuitCanvas";focus:true;SplitView.fillHeight:true;SplitView.minimumHeight:Math.min(180,workspaceSplit.height/2);editor:backend;appearance:theme;onQuickAddRequested:quickAdd.open();onPropertiesRequested:root.openGateProperties();Component.onCompleted:forceActiveFocus() }
            ColumnLayout {
                id:scopePanel;objectName:"scopePanel"
                visible:root.scopeVisible;spacing:0
                SplitView.preferredHeight:windowSettings.scopeHeight
                SplitView.minimumHeight:120
                SplitView.maximumHeight:Math.max(120,workspaceSplit.height-180)
                Rectangle { Layout.fillWidth:true;Layout.preferredHeight:74;Layout.minimumHeight:74;Layout.maximumHeight:74;color:theme.panel
                    ColumnLayout { anchors.fill:parent;anchors.leftMargin:8;anchors.rightMargin:8;spacing:2
                        RowLayout { Layout.fillWidth:true;spacing:6
                            Label { text:"Oscilloscope";color:theme.text }
                            AppButton { text:backend.scopePaused?"Resume / Reset":"Pause";implicitWidth:100;onClicked:backend.scopePaused=!backend.scopePaused }
                            Tool { iconName:"copy";hint:"Copy oscilloscope image";onClicked:backend.copyScopeImage() }
                            Tool { iconName:"open";hint:"Load .cdo layout";onClicked:backend.scopeLayoutDialog(false) }
                            Tool { iconName:"save";hint:"Save .cdo layout";onClicked:backend.scopeLayoutDialog(true) }
                            Item { Layout.fillWidth:true }
                            Tool { glyph:"×";hint:"Close oscilloscope";onClicked:root.scopeVisible=false }
                        }
                        RowLayout { Layout.fillWidth:true;spacing:6
                            AppCombo { id:feedChoice;model:backend.availableSignals;Layout.fillWidth:true }
                            AppButton { text:"Add";implicitWidth:55;enabled:feedChoice.currentIndex>=0;onClicked:backend.addScopeFeed(feedChoice.currentText) }
                            AppCombo { id:selectedFeed;model:backend.scopeFeeds;Layout.fillWidth:true }
                            AppButton { text:"Remove";implicitWidth:70;enabled:selectedFeed.currentIndex>=0;onClicked:backend.removeScopeFeed(selectedFeed.currentIndex) }
                        }
                    }
                }
                ScrollView { id:scopeScroll;Layout.fillWidth:true;Layout.fillHeight:true;Layout.minimumHeight:0;clip:true;contentWidth:availableWidth
                    Waveforms { width:scopeScroll.availableWidth;height:Math.max(140,backend.scopeFeeds.length*48);editor:backend;appearance:theme }
                }
            }
            }
        }
    }
    footer:Rectangle {
        height:28;color:theme.panel
        Rectangle { width:parent.width;height:1;color:theme.border }
        RowLayout {
            anchors.fill:parent;anchors.leftMargin:12;anchors.rightMargin:12
            Label { objectName:"statusLabel";text:backend.placement.length?"Place "+backend.placement+" · Esc to finish":backend.status;color:theme.muted;font.pixelSize:12;Layout.fillWidth:true;elide:Text.ElideRight }
            Label { text:Math.round(canvas.zoom*100)+"%";color:theme.muted;font.pixelSize:12 }
        }
    }
    Preferences { id:preferences;objectName:"preferencesDialog";onClosed:root.focusCircuit() }
    Dialog {
        id:properties;onClosed:root.focusCircuit();objectName:"gatePropertiesDialog";title:"Gate properties";modal:true;anchors.centerIn:parent;width:460;height:Math.min(580,root.height-60,180+fields.length*78)
        standardButtons:Dialog.Ok|Dialog.Cancel
        property var fields:[];property var values:({})
        function applyValues(){
            if(backend.applyParameters(values))close()
            else errorText=backend.status
        }
        onOpened:{
            errorText=""
            // Recreate editors even when two gates have identical metadata:
            // user-edited text may differ from the original model value.
            fields=[]
            let fresh=backend.parameterFields();let v={}
            for(let f of fresh)v[f.key]=f.value
            values=v;fields=fresh
        }
        footer:RowLayout {
            spacing:8
            Item { Layout.fillWidth:true }
            AppButton { objectName:"gatePropertiesCancel";text:"Cancel";onClicked:properties.close() }
            AppButton { objectName:"gatePropertiesApply";text:"OK";highlighted:true;onClicked:properties.applyValues() }
        }
        property string errorText:""
        contentItem:ScrollView {
            clip:true
            ColumnLayout {
                width:properties.availableWidth;spacing:12
                Label { text:properties.errorText;visible:text.length>0;wrapMode:Text.WordWrap;Layout.fillWidth:true;color:theme.accent }
                Label { text:"Select one gate to edit its properties.";visible:properties.fields.length===0;color:theme.muted;wrapMode:Text.WordWrap;Layout.fillWidth:true }
                Repeater {
                    model:properties.fields
                    delegate:ColumnLayout {
                        required property var modelData
                        Layout.fillWidth:true
                        Label { text:modelData.label;color:theme.text }
                        RowLayout {
                            Layout.fillWidth:true
                            AppField { onAccepted:properties.applyValues();objectName:"gateParameterText";Layout.fillWidth:true;visible:["BOOL","CHOICE"].indexOf(parent.parent.modelData.type)<0;text:parent.parent.modelData.value;onTextEdited:{let v=Object.assign({},properties.values);v[parent.parent.modelData.key]=text;properties.values=v} }
                            AppCombo {
                                Layout.fillWidth:true;visible:parent.parent.modelData.type==="CHOICE"
                                objectName:visible?"decoderPolarityCombo":""
                                model:parent.parent.modelData.labels||[]
                                currentIndex:(parent.parent.modelData.choices||[]).indexOf(properties.values[parent.parent.modelData.key])
                                onActivated:{let v=Object.assign({},properties.values);v[parent.parent.modelData.key]=parent.parent.modelData.choices[currentIndex];properties.values=v}
                            }
                            CheckBox { visible:parent.parent.modelData.type==="BOOL";checked:parent.parent.modelData.value.toLowerCase()==="true";onToggled:{let v=Object.assign({},properties.values);v[parent.parent.modelData.key]=checked?"true":"false";properties.values=v} }
                            AppButton { text:"Browse…";visible:["FILE_IN","FILE_OUT"].indexOf(parent.parent.modelData.type)>=0;onClicked:{let value=backend.chooseParameterFile(parent.parent.modelData.type==="FILE_OUT");if(value.length){backend.parameterFile(parent.parent.modelData.key,value);let v=Object.assign({},properties.values);v[parent.parent.modelData.key]=value;properties.values=v;parent.children[0].text=value}} }
                        }
                    }
                }
            }
        }
    }
    Dialog {
        id:signDialog;onClosed:root.focusCircuit();objectName:"signCircuitDialog";title:"Sign circuit";modal:true;anchors.centerIn:parent;width:420;standardButtons:Dialog.Ok|Dialog.Cancel
        onOpened:{statusChoice.currentIndex=0;signatureStatus.text="This circuit works properly"}
        onAccepted:backend.signCircuit(signatureStatus.text)
        ColumnLayout { width:signDialog.availableWidth;spacing:12
            Label { text:"Circuit status";color:theme.text }
            AppCombo { id:statusChoice;Layout.fillWidth:true;model:["This circuit works properly","This circuit does not work properly","Other"];onActivated:signatureStatus.text=currentIndex<2?currentText:"" }
            AppField { onAccepted:signDialog.accept();id:signatureStatus;objectName:"signatureStatus";Layout.fillWidth:true;text:"This circuit works properly";placeholderText:"Describe the circuit status" }
        }
    }
    Tutorial { id:about;onClosed:root.focusCircuit() }
    QuickAdd { id:quickAdd;onSelected:function(name){backend.placement=name;root.focusCircuit()};onRejected:root.focusCircuit() }
    Dialog {
        id:changelog;objectName:"changelogDialog";title:"CedarLogic Changelog";modal:true;parent:Overlay.overlay;anchors.centerIn:parent
        width:Math.min(720,parent.width-24);height:Math.min(600,parent.height-24);standardButtons:Dialog.Close
        background:Rectangle { radius:8;color:theme.panel;border.color:theme.border }
        contentItem:ScrollView { id:changelogScroll;clip:true;contentWidth:availableWidth;TextEdit { objectName:"changelogText";width:changelogScroll.availableWidth;readOnly:true;selectByMouse:true;text:backend.changelogText();textFormat:TextEdit.PlainText;wrapMode:TextEdit.WordWrap;color:theme.text;font.pixelSize:13 } }
    }
    ShortcutHelp { id:shortcutHelp;objectName:"shortcutHelpDialog";onClosed:root.focusCircuit() }
    Connections { target:backend;function onSignatureRequired(){preferences.openForSigning()} }
}
