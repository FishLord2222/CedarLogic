import QtQuick
import QtQuick.Controls
Button {
    id:control
    implicitWidth:Math.max(88,contentItem.implicitWidth+28);implicitHeight:34
    leftPadding:14;rightPadding:14
    background:Rectangle { radius:5;color:control.down?Qt.alpha(theme.accent,0.2):control.hovered?theme.raised:theme.background;border.color:control.highlighted?theme.accent:theme.border }
    contentItem:Text { text:control.text;font:control.font;color:theme.text;horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter }
}
