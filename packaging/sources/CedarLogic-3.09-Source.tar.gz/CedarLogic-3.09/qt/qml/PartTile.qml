import QtQuick
import QtQuick.Controls

Item {
    id: tile
    required property var modelData
    required property int index
    property bool showNames: false
    property bool isSelected: false
    property Item placementArea: null
    readonly property point placementPosition: placementArea
        ? placementArea.mapFromItem(null, gateDrag.centroid.scenePosition.x,
                                    gateDrag.centroid.scenePosition.y)
        : Qt.point(-1, -1)
    readonly property bool overPlacementArea: placementArea
        && placementPosition.x >= 0 && placementPosition.y >= 0
        && placementPosition.x < placementArea.width
        && placementPosition.y < placementArea.height
    property size thumbnailSize: Qt.size(144, 144)
    readonly property string gateName: modelData.name
    readonly property string caption: modelData.caption || gateName
    readonly property string imageSource: "image://gates/" + gateName + "/" + (theme.dark ? "dark" : "light")

    signal picked(string name)
    signal dragStarted(string name)
    signal dragFinished(point scenePosition)

    Rectangle {
        anchors.fill: parent
        anchors.margins: 3
        radius: 5
        color: tile.isSelected ? Qt.alpha(theme.accent, 0.12)
                              : tileMouse.containsMouse ? theme.raised : theme.panel
        border.color: tile.isSelected ? theme.accent
                                     : tileMouse.containsMouse ? theme.muted : theme.border
        border.width: tile.isSelected ? 1.5 : 1

        Image {
            objectName: "sidebarPartImage" + tile.index
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 6
            height: tile.showNames ? 58 : parent.height - 12
            source: tile.imageSource
            sourceSize: tile.thumbnailSize
            fillMode: Image.PreserveAspectFit
        }
        Label {
            objectName: "sidebarPartName" + tile.index
            x: 6; y: 68
            width: parent.width - 12; height: 28
            visible: tile.showNames
            text: tile.caption
            color: theme.text
            font.pixelSize: 11
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            wrapMode: Text.Wrap
            maximumLineCount: 2
            elide: Text.ElideRight
        }
    }
    MouseArea {
        id: tileMouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: tile.picked(tile.gateName)
    }
    DragHandler {
        id: gateDrag
        target: null
        onActiveChanged: {
            if (active)
                tile.dragStarted(tile.gateName)
            else
                tile.dragFinished(centroid.scenePosition)
        }
    }
    Image {
        objectName: "sidebarDragPreview" + tile.index
        parent: Overlay.overlay
        z: 1000
        // The canvas draws the snapped gate here; do not cover it with an icon.
        visible: gateDrag.active && !tile.overPlacementArea
        opacity: 0.85
        width: 56; height: 56
        x: gateDrag.centroid.scenePosition.x - 28
        y: gateDrag.centroid.scenePosition.y - 28
        // Hidden previews previously rendered a second image for every tile.
        source: visible ? tile.imageSource : ""
        fillMode: Image.PreserveAspectFit
    }
    ToolTip.visible: tileMouse.containsMouse
    ToolTip.text: tile.caption
    ToolTip.delay: 500
}
