import QtQuick
import QtQuick.Controls
Button {
    id: control
    property string iconName: ""
    property string glyph: ""
    property string hint: ""
    property bool accentActive: false
    implicitWidth: 32; implicitHeight: 30
    focusPolicy: Qt.NoFocus
    hoverEnabled: true
    padding: 5
    contentItem: Item {
        Image {
            anchors.centerIn:parent;width:22;height:22
            visible:control.iconName.length>0
            source:visible?"image://icons/"+control.iconName+"/"+String(control.accentActive?theme.accent:theme.text).substring(1):""
            sourceSize:Qt.size(48,48)
            opacity:control.enabled?1:0.35
        }
        Text {
            anchors.fill:parent;visible:control.iconName.length===0
            text:control.glyph;font.pixelSize:22;color:control.accentActive?theme.accent:theme.text
            horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter
            opacity:control.enabled?1:0.35
        }
    }
    background: Rectangle {
        radius: 5
        color: control.accentActive ? Qt.alpha(theme.accent,0.12) : control.down ? theme.raised : control.hovered ? theme.raised : "transparent"
        border.width: control.accentActive || control.hovered ? 1 : 0
        border.color: control.accentActive ? theme.accent : theme.border
        Behavior on color { ColorAnimation { duration: 100 } }
    }
    ToolTip.visible: hovered && hint.length > 0
    ToolTip.text: hint; ToolTip.delay: 550
}
