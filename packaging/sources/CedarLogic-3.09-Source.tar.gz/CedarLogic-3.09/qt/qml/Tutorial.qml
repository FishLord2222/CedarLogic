import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
Dialog {
    id: guide
    objectName:"tutorialDialog"
    parent:Overlay.overlay;anchors.centerIn:parent;modal:true
    title:"CedarLogic "+releaseVersion+" — Tutorial"
    width:Math.min(960,parent.width-24);height:Math.min(660,parent.height-24)
    standardButtons:Dialog.Close
    property var topics:backend.helpTopics()
    readonly property string topicHtml:topics[topicIndex] ? backend.helpText(topics[topicIndex].file) : ""
    property int topicIndex:0
    property var expanded:({})
    readonly property real touchpadScrollSpeed:Math.max(1,Math.min(8,Number(theme.editorSettings.helpTouchpadSpeed)||3))
    function fitImages(html, available) {
        // The selected topic's title is already displayed above the scroll view.
        html=html.replace(/^\s*<h1\b[^>]*>[\s\S]*?<\/h1>\s*/i, function(heading) {
            return /<img\b/i.test(heading) ? heading : ""
        })
        html=html.replace(/icons\/([a-z-]+)-light\.png/g, function(match,name) {
            return "icons/"+name+(theme.dark?"-dark.png":"-light.png")
        })
        // Keep the capture's aspect ratio on smaller windows and at high DPI.
        return html.replace(/width="(\d+)" height="(\d+)"/g, function(match,w,h) {
            let width=Math.max(1,Math.min(Number(w),Math.floor(available)))
            return 'width="'+width+'" height="'+Math.round(Number(h)*width/Number(w))+'"'
        })
    }
    function selectTopic(index) {
        if(index<0 || index>=topics.length || topics[index].category)return
        topicIndex=index
        let parents=Object.assign({},expanded)
        let depth=topics[index].depth
        for(let i=index-1;i>=0;i--)if(topics[i].depth<depth){parents[i]=true;depth=topics[i].depth}
        expanded=parents
        page.contentItem.contentY=0
    }
    function toggleCategory(index) {
        let next=Object.assign({},expanded)
        next[index]=!next[index]
        expanded=next
    }
    function visibleTopics() {
        let rows=[],hiddenDepth=-1
        for(let i=0;i<topics.length;i++) {
            let entry=topics[i]
            if(hiddenDepth>=0 && entry.depth>hiddenDepth)continue
            hiddenDepth=-1
            rows.push(Object.assign({sourceIndex:i},entry))
            if(entry.category && !expanded[i])hiddenDepth=entry.depth
        }
        return rows
    }
    Component.onCompleted: {
        for(let i=0;i<topics.length;i++)if(topics[i].file==="Introduction.htm"){selectTopic(i);return}
    }
    background:Rectangle { color:theme.panel;radius:8;border.color:theme.border }
    contentItem:RowLayout {
        spacing:16
        ColumnLayout {
            Layout.preferredWidth:250;Layout.minimumWidth:180;Layout.fillHeight:true
            Label { text:"Contents";color:theme.text;font.bold:true;font.pixelSize:14 }
            ListView {
                id:contents;objectName:"tutorialTopics"
                Layout.fillWidth:true;Layout.fillHeight:true;clip:true
                model:guide.visibleTopics()
                ScrollBar.vertical:ScrollBar {}
                delegate:ItemDelegate {
                    id:entry
                    required property var modelData
                    required property int index
                    objectName:"tutorialEntry"+modelData.sourceIndex
                    width:contents.width;height:32
                    text:modelData.title
                    highlighted:!modelData.category && guide.topicIndex===modelData.sourceIndex
                    onClicked: {
                        contents.currentIndex=index
                        if(modelData.category)guide.toggleCategory(modelData.sourceIndex)
                        else guide.selectTopic(modelData.sourceIndex)
                    }
                    background:Rectangle { radius:4;color:entry.highlighted?Qt.alpha(theme.accent,0.15):entry.hovered?theme.raised:"transparent" }
                    contentItem:RowLayout {
                        spacing:5
                        Item { Layout.preferredWidth:entry.modelData.depth*12 }
                        Label { Layout.preferredWidth:12;text:entry.modelData.category?(guide.expanded[entry.modelData.sourceIndex]?"⌄":"›"):"";color:theme.muted }
                        Label { Layout.fillWidth:true;text:entry.text;elide:Text.ElideRight;color:entry.highlighted?theme.accent:theme.text;font.bold:entry.modelData.category;font.pixelSize:12 }
                    }
                    ToolTip.visible:hovered;ToolTip.text:text
                }
                Keys.onReturnPressed: {
                    let entry=model[currentIndex]
                    if(!entry)return
                    if(entry.category)guide.toggleCategory(entry.sourceIndex)
                    else guide.selectTopic(entry.sourceIndex)
                }
            }
        }
        Rectangle { Layout.preferredWidth:1;Layout.fillHeight:true;color:theme.border }
        ColumnLayout {
            Layout.fillWidth:true;Layout.fillHeight:true
            Label { text:guide.topics[guide.topicIndex] ? guide.topics[guide.topicIndex].title : "Tutorial";color:theme.text;font.pixelSize:18;font.bold:true;Layout.fillWidth:true;elide:Text.ElideRight }
            ScrollView {
                id:page;objectName:"tutorialPage";Layout.fillWidth:true;Layout.fillHeight:true;clip:true;contentWidth:availableWidth
                WheelHandler {
                    parent:page.contentItem;target:null
                    acceptedDevices:PointerDevice.Mouse | PointerDevice.TouchPad
                    onWheel:function(event) {
                        // Wayland may identify a phased pixel gesture as a mouse event.
                        let gesture=event.device.type===PointerDevice.TouchPad
                            || (event.phase!==Qt.NoScrollPhase && event.pixelDelta.y!==0)
                            || (event.angleDelta.y===0 && event.pixelDelta.y!==0)
                        let delta=gesture
                            ? (event.pixelDelta.y!==0?event.pixelDelta.y:event.angleDelta.y)*guide.touchpadScrollSpeed
                            : event.angleDelta.y
                        if(delta===0) {
                            event.accepted=false
                            return
                        }
                        let view=page.contentItem
                        view.cancelFlick()
                        let top=view.originY
                        let bottom=top+Math.max(0,view.contentHeight-view.height)
                        // Apply each packet once; momentum and natural direction are supplied by Qt.
                        view.contentY=Math.max(top,Math.min(bottom,view.contentY-delta))
                        event.accepted=true
                    }
                }
                Text {
                    objectName:"tutorialText";width:page.availableWidth
                    text:guide.fitImages(guide.topicHtml,width)
                    baseUrl:backend.helpBaseUrl();textFormat:Text.RichText;wrapMode:Text.WordWrap
                    color:theme.text;font.pixelSize:14
                    onLinkActivated:function(link){
                        let name=link.substring(link.lastIndexOf("/")+1).split("#")[0]
                        for(let i=0;i<guide.topics.length;i++)if(guide.topics[i].file===name){guide.selectTopic(i);return}
                    }
                }
            }
        }
    }
}
