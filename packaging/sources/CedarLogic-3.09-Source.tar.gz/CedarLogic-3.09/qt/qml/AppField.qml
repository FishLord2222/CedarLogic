import QtQuick
import QtQuick.Controls
TextField {
    id: control
    implicitHeight:36;padding:10;selectByMouse:true
    color:theme.text;placeholderTextColor:theme.muted
    background:Rectangle { radius:5;color:theme.background;border.color:control.activeFocus?theme.accent:theme.border }
}
