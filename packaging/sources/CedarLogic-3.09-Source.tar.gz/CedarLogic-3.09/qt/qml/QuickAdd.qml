import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
Dialog {
    id: picker
    objectName: "quickAddDialog"
    parent:Overlay.overlay;anchors.centerIn:parent;modal:true
    title:"Add Component";width:Math.min(580,parent.width-24);height:Math.min(440,parent.height-24)
    standardButtons:Dialog.Ok|Dialog.Cancel
    property var results: []
    signal selected(string name)
    function refresh(){results=backend.palette(query.text,"");matches.currentIndex=results.length?0:-1}
    function choose(){if(matches.currentIndex>=0){let name=results[matches.currentIndex].name;close();selected(name)}}
    onOpened:{query.text="";refresh();query.forceActiveFocus()}
    onAccepted:choose()
    background:Rectangle { color:theme.panel;radius:8;border.color:theme.border }
    contentItem:ColumnLayout {
        spacing:12
        AppField {
            id:query;objectName:"quickAddSearch";Layout.fillWidth:true;placeholderText:"Search components…"
            onTextChanged:picker.refresh()
            Keys.onPressed:function(event){
                if(event.key===Qt.Key_Down){matches.currentIndex=Math.min(matches.count-1,matches.currentIndex+1);event.accepted=true}
                else if(event.key===Qt.Key_Up){matches.currentIndex=Math.max(0,matches.currentIndex-1);event.accepted=true}
                else if(event.key===Qt.Key_Return||event.key===Qt.Key_Enter){picker.choose();event.accepted=true}
                if(event.accepted&&matches.currentIndex>=0)matches.positionViewAtIndex(matches.currentIndex,ListView.Contain)
            }
        }
        RowLayout {
            Layout.fillWidth:true;Layout.fillHeight:true;spacing:14
            ListView {
                id:matches;objectName:"quickAddResults";Layout.fillWidth:true;Layout.preferredWidth:360;Layout.minimumWidth:200;Layout.fillHeight:true;clip:true
                model:picker.results;ScrollBar.vertical:ScrollBar {}
                delegate:ItemDelegate {
                    required property var modelData;required property int index
                    width:matches.width;height:38;text:modelData.caption;highlighted:index===matches.currentIndex
                    onClicked:matches.currentIndex=index
                    background:Rectangle { radius:4;color:parent.highlighted?Qt.alpha(theme.accent,0.18):parent.hovered?theme.raised:"transparent" }
                    contentItem:Label { text:parent.text;color:theme.text;elide:Text.ElideRight;verticalAlignment:Text.AlignVCenter }
                    MouseArea { anchors.fill:parent;onClicked:matches.currentIndex=parent.index;onDoubleClicked:{matches.currentIndex=parent.index;picker.choose()} }
                }
            }
            ColumnLayout {
                Layout.preferredWidth:150;Layout.minimumWidth:150;Layout.maximumWidth:150
                Image { Layout.preferredWidth:140;Layout.preferredHeight:140;source:matches.currentIndex>=0?"image://gates/"+picker.results[matches.currentIndex].name+"/"+(theme.dark?"dark":"light"):"";sourceSize:Qt.size(280,280);fillMode:Image.PreserveAspectFit }
                Label { Layout.fillWidth:true;wrapMode:Text.WordWrap;text:matches.currentIndex>=0?picker.results[matches.currentIndex].caption:"No matching components";color:theme.muted }
                Item { Layout.fillHeight:true }
            }
        }
    }
}
