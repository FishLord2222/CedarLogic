import QtQuick
import QtQuick.Controls
ComboBox {
    id: control
    implicitHeight: 36
    leftPadding: 12;rightPadding:30
    delegate:ItemDelegate {
        required property int index
        required property var modelData
        objectName:"comboOption"+index
        width:control.width-8;implicitHeight:36
        highlighted:control.highlightedIndex===index
        contentItem:Text { text:control.textRole?modelData[control.textRole]:modelData;color:theme.text;font:control.font;verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight }
        background:Rectangle { radius:4;color:parent.highlighted?Qt.alpha(theme.accent,0.16):parent.hovered?theme.raised:"transparent" }
    }
    background:Rectangle { radius:5;color:theme.raised;border.color:control.activeFocus?theme.accent:theme.border }
    contentItem:Text { text:control.displayText;color:theme.text;verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight;font:control.font }
    indicator:Image { width:18;height:18;sourceSize:Qt.size(36,36);source:"image://icons/chevron-down/"+theme.muted.toString().substring(1);x:control.width-width-10;anchors.verticalCenter:parent.verticalCenter }
    popup:Popup {
        y:control.height+4;width:control.width;padding:4
        implicitHeight:Math.min(contentItem.implicitHeight+8,300)
        background:Rectangle { radius:5;color:theme.panel;border.color:theme.border }
        contentItem:ListView { clip:true;implicitHeight:contentHeight;model:control.popup.visible?control.delegateModel:null;currentIndex:control.highlightedIndex;ScrollIndicator.vertical:ScrollIndicator {} }
    }
}
