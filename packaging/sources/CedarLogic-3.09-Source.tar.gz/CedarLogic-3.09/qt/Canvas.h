#pragma once
#include "Appearance.h"
#include "Editor.h"
#include "render/Scene.h"
#include <QPointF>
#include <QCache>
#include <QMutex>
#include <QQuickImageProvider>
#include <QQuickPaintedItem>
#include <QTimer>
class Canvas : public QQuickPaintedItem {
  Q_OBJECT
  Q_PROPERTY(Editor *editor READ editor WRITE setEditor NOTIFY editorChanged)
  Q_PROPERTY(Appearance *appearance READ appearance WRITE setAppearance NOTIFY
                 appearanceChanged)
  Q_PROPERTY(
      bool overview READ overview WRITE setOverview NOTIFY overviewChanged)
  Q_PROPERTY(Canvas *mainCanvas READ mainCanvas WRITE setMainCanvas NOTIFY
                 overviewChanged)
  Q_PROPERTY(double zoom READ zoom NOTIFY cameraChanged)
public:
  Canvas(QQuickItem *parent = nullptr);
  Editor *editor() const { return model; }
  void setEditor(Editor *value);
  Appearance *appearance() const { return theme; }
  void setAppearance(Appearance *value);
  bool overview() const { return miniature; }
  void setOverview(bool v) {
    if (miniature == v) return;
    miniature = v;
    emit overviewChanged();
    invalidate();
  }
  Canvas *mainCanvas() const { return main; }
  void setMainCanvas(Canvas *v);
  double zoom() const { return scale / 12; }
  void paint(QPainter *painter) override;
  Q_INVOKABLE void fit();
  Q_INVOKABLE void zoomBy(double factor);
  Q_INVOKABLE void place(double x, double y);
  Q_INVOKABLE void cancel();
  QImage renderImage(int w, int h, bool grid = true);
  QRectF visibleWorld() const;
signals:
  void editorChanged();
  void appearanceChanged();
  void overviewChanged();
  void cameraChanged();
  void quickAddRequested();
  void propertiesRequested();

protected:
  void mousePressEvent(QMouseEvent *e) override;
  void mouseMoveEvent(QMouseEvent *e) override;
  void hoverMoveEvent(QHoverEvent *e) override;
  void hoverEnterEvent(QHoverEvent *e) override;
  void hoverLeaveEvent(QHoverEvent *e) override;
  void mouseReleaseEvent(QMouseEvent *e) override;
  void mouseUngrabEvent() override;
  void mouseDoubleClickEvent(QMouseEvent *e) override;
  void wheelEvent(QWheelEvent *e) override;
  void keyPressEvent(QKeyEvent *e) override;

private:
  Editor *model = nullptr;
  Appearance *theme = nullptr;
  Canvas *main = nullptr;
  bool miniature = false, panning = false, dragging = false, boxing = false,
       wireDragging = false;
  double scale = 12;
  QPointF center{0, 0}, press, originalCenter, worldPress;
  QRectF selectionBox;
  QVariantMap wireStart;
  bool connectionPressed = false, connectionDragged = false;
  QPointF wireEnd, pasteAnchor;
  QImage cache;
  bool invalid = true;
  bool cursorInside = false;
  QPointF cursorPosition;
  QTimer frameTimer;
  QPointF toWorld(QPointF p) const;
  cl::render::Transform camera(int w, int h) const;
  void invalidate();
  void clearWirePreview();
  void navigateOverview(QPointF position);
};
class GateImages : public QQuickImageProvider {
public:
  explicit GateImages(int cacheKiB = 16 * 1024)
      : QQuickImageProvider(QQuickImageProvider::Image), thumbnails(cacheKiB) {}
  QImage requestImage(const QString &id, QSize *size,
                      const QSize &requested) override;
private:
  // Cache exact sizes and themes; keep the original symbol pixels unchanged.
  QCache<QString, QImage> thumbnails;
  QMutex thumbnailMutex;
};

class Icons : public QQuickImageProvider {
public:
  Icons() : QQuickImageProvider(QQuickImageProvider::Image) {}
  QImage requestImage(const QString &id, QSize *size,
                      const QSize &requested) override;
};

class Waveforms : public QQuickPaintedItem {
  Q_OBJECT
  Q_PROPERTY(Editor *editor READ editor WRITE setEditor NOTIFY changed)
  Q_PROPERTY(
      Appearance *appearance READ appearance WRITE setAppearance NOTIFY changed)
public:
  Waveforms(QQuickItem *parent = nullptr) : QQuickPaintedItem(parent) {
    setAntialiasing(true);
  }
  Editor *editor() const { return model; }
  void setEditor(Editor *value) {
    model = value;
    if (model)
      connect(model, &Editor::tracesChanged, this, [this] { update(); });
    emit changed();
  }
  Appearance *appearance() const { return theme; }
  void setAppearance(Appearance *value) {
    theme = value;
    if (theme)
      connect(theme, &Appearance::changed, this, [this] { update(); });
    emit changed();
  }
  void paint(QPainter *painter) override;
signals:
  void changed();

private:
  Editor *model = nullptr;
  Appearance *theme = nullptr;
};
