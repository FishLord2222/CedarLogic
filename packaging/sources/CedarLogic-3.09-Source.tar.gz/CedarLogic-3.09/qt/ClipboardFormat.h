#pragma once
#include "SharedModel.h"
#pragma push_macro("emit")
#undef emit
#include "command/cmdSerialize.h"
#include "migrate.hpp"
#include <sstream>
#include <set>
#include <stdexcept>
inline cl::CircuitFile readClipboard(const std::string &text) {
  if(cmdser::keyword(text)!="creategate")return cl::loadCircuit(text).file;
  if(text.size()>16*1024*1024)throw std::runtime_error("Clipboard block is too large");
  cl::CircuitFile file;file.pages.push_back({});auto &page=file.pages[0];std::map<unsigned long,size_t> gates;std::map<IDType,size_t> wires;
  std::istringstream lines(text);std::string line;
  while(std::getline(lines,line)) {
    auto key=cmdser::keyword(line);
    if(key=="creategate"){cmdser::CreateGate gate;if(!cmdser::parse(line,gate))throw std::runtime_error("Invalid clipboard gate");makeGate(gate.gateType);gates[gate.gid]=page.gates.size();page.gates.push_back({std::to_string(gate.gid),gate.gateType,{gate.x,gate.y},0,{}});}
    else if(key=="setparams") {unsigned long id=0,g=0,l=0;char comma;std::istringstream guard(line);std::string word;guard>>word>>id>>g>>comma>>l;if(!guard||g+l>10000)throw std::runtime_error("Invalid clipboard parameters");cmdser::SetParams p;if(!cmdser::parse(line,p)||!gates.count(p.gid))throw std::runtime_error("Invalid clipboard parameters");auto &gate=page.gates[gates.at(p.gid)];for(auto param:p.guiParams)if(param.first=="angle")gate.angle=std::stod(param.second);else gate.params.push_back({param.first,param.second,true});for(auto param:p.logicParams)gate.params.push_back({param.first,param.second,false});}
    else if(key=="createwire"){cmdser::CreateWire wire;if(!cmdser::parse(line,wire)||wire.wireIds.empty())throw std::runtime_error("Invalid clipboard wire");wires[wire.wireIds[0]]=page.wires.size();cl::WireInstance w;for(auto id:wire.wireIds)w.ids.push_back(std::to_string(id));page.wires.push_back(w);}
    else if(key=="connectwire")continue; // The following routed shape contains every endpoint.
    else if(key=="movewire"){cmdser::MoveWire wire;if(!cmdser::parse(line,wire)||!wires.count(wire.wid))throw std::runtime_error("Invalid clipboard route");auto &dest=page.wires[wires.at(wire.wid)];for(auto seg:wire.segments){cl::WireSegment s;s.id=std::to_string(seg.id);s.vertical=seg.vertical;s.begin={seg.bx,seg.by};s.end={seg.ex,seg.ey};for(auto c:seg.connections){if(!gates.count(c.first))throw std::runtime_error("Invalid clipboard endpoint");s.connects.push_back({std::to_string(c.first),c.second});}for(auto x:seg.intersects)s.intersections.push_back({x.first,std::to_string(x.second)});dest.segments.push_back(s);}}
    else if(!key.empty())throw std::runtime_error("Unknown clipboard command");
  }
  for(auto w:page.wires)if(w.segments.empty())throw std::runtime_error("Clipboard wire has no route");return file;
}
inline std::string legacyClipboard(const cl::CircuitFile &file) {
  if(file.pages.empty())return {};std::ostringstream out;const auto &page=file.pages[0];
  for(auto gate:page.gates){auto id=std::stoul(gate.uuid);out<<cmdser::emit(cmdser::CreateGate{id,gate.libName,float(gate.at.x),float(gate.at.y)})<<'\n';auto model=makeGate(gate.libName);cmdser::SetParams p;p.gid=id;p.guiParams=*model->getAllGUIParams();p.logicParams=*model->getAllLogicParams();for(auto param:gate.params)if(param.gui)p.guiParams[param.name]=param.value;else p.logicParams[param.name]=param.value;p.guiParams["angle"]=std::to_string(gate.angle);out<<cmdser::emit(p)<<'\n';}
  for(auto wire:page.wires){std::vector<cmdser::ConnectWire> conns;std::set<std::pair<std::string,std::string>> seen;for(auto seg:wire.segments)for(auto c:seg.connects)if(seen.insert({c.gateUuid,c.pin}).second)conns.push_back({std::stoull(wire.ids[0]),std::stoull(c.gateUuid),c.pin});if(conns.size()<2)continue;cmdser::CreateWire w;for(auto id:wire.ids)w.wireIds.push_back(std::stoull(id));w.conn1=conns[0];w.conn2=conns[1];out<<cmdser::emit(w)<<'\n';for(size_t i=2;i<conns.size();++i)out<<cmdser::emit(conns[i])<<'\n';cmdser::MoveWire route;route.wid=w.wireIds[0];for(auto seg:wire.segments){cmdser::MoveWireSeg s;s.id=std::stol(seg.id);s.vertical=seg.vertical;s.bx=seg.begin.x;s.by=seg.begin.y;s.ex=seg.end.x;s.ey=seg.end.y;for(auto c:seg.connects)s.connections.push_back({std::stoul(c.gateUuid),c.pin});for(auto x:seg.intersections)s.intersects.push_back({float(x.at),std::stol(x.segment)});route.segments.push_back(s);}out<<cmdser::emit(route)<<'\n';}return out.str();
}

#pragma pop_macro("emit")
