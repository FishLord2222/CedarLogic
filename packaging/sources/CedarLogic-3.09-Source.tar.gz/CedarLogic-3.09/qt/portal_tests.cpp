#include <QApplication>
#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusContext>
#include <QDBusMessage>
#include <QDBusObjectPath>
#include <QFileDialog>
#include <QEventLoop>
#include <QTimer>
#include <QUrl>
#include <iostream>
class Portal : public QObject, protected QDBusContext {
  Q_OBJECT
  Q_CLASSINFO("D-Bus Interface", "org.freedesktop.portal.FileChooser")
  Q_PROPERTY(uint version READ version CONSTANT)
public:
  uint version() const { return 3; }
  QString fixture;
public slots:
  QDBusObjectPath OpenFile(const QString &, const QString &, const QVariantMap &options) {
    auto sender = message().service().mid(1).replace('.', '_');
    auto path = "/org/freedesktop/portal/desktop/request/" + sender + "/" + options.value("handle_token").toString();
    QTimer::singleShot(100, this, [this,path] {
      auto response = QDBusMessage::createSignal(path, "org.freedesktop.portal.Request", "Response");
      response << uint(0) << QVariantMap{{"uris", QStringList{QUrl::fromLocalFile(fixture).toString()}}};
      QDBusConnection::sessionBus().send(response);
    });
    return QDBusObjectPath(path);
  }
};
int main(int argc, char **argv) {
  if (argc > 1 && QByteArray(argv[1]) == "--server") {
    QCoreApplication app(argc, argv);
    Portal portal;portal.fixture = QString::fromLocal8Bit(argv[2]);
    auto bus = QDBusConnection::sessionBus();
    if (!bus.registerService("org.freedesktop.portal.Desktop") ||
        !bus.registerObject("/org/freedesktop/portal/desktop", &portal,
                            QDBusConnection::ExportAllSlots | QDBusConnection::ExportAllProperties)) return 2;
    std::cout << "Portal ready" << std::endl;
    QTimer::singleShot(10000, &app, &QCoreApplication::quit);
    return app.exec();
  }
  qputenv("QT_QPA_PLATFORMTHEME", "xdgdesktopportal");
  QApplication app(argc, argv);
  // Qt probes the portal version asynchronously during platform initialization.
  QEventLoop ready;
  QTimer::singleShot(200, &ready, &QEventLoop::quit);
  ready.exec();
  // A fallback Qt dialog cannot satisfy this test; only the mock portal responds.
  QTimer::singleShot(5000, &app, [] { std::cerr << "Native portal picker timed out\n";std::exit(1); });
  auto path = QFileDialog::getOpenFileName(nullptr, "Open circuit", {}, "CedarLogic circuits (*.cdl)");
  if (path != QString::fromLocal8Bit(argv[1])) { std::cerr << "Wrong native picker result\n";return 1; }
  std::cout << "Bundled Qt delegated file selection to the desktop portal\n";
}
#include "portal_tests.moc"
