#include "Keyboard.h"
#include <QKeyEvent>
#include <QQuickItem>
void Keyboard::setWindow(QQuickWindow *value) {
  if (window) window->removeEventFilter(this);
  window = value;
  if (window) window->installEventFilter(this);
}
QString Keyboard::commandFor(QKeyEvent *event) const {
  const auto modifiers = event->modifiers() & ~Qt::KeypadModifier;
  const bool ctrl = modifiers.testFlag(Qt::ControlModifier);
  const bool shift = modifiers.testFlag(Qt::ShiftModifier);
  if (modifiers.testFlag(Qt::AltModifier) || modifiers.testFlag(Qt::MetaModifier)) return {};
  const int key = event->key();
  if (ctrl) {
    // Text fields retain their own selection, clipboard and undo behavior.
    auto focus = window ? window->activeFocusItem() : nullptr;
    bool editing = false;
    if (focus) for (auto meta = focus->metaObject(); meta; meta = meta->superClass()) {
      const QByteArray name(meta->className());
      if (name.startsWith("QQuickTextInput") || name.startsWith("QQuickTextEdit")) editing = true;
    }
    if (editing && (key == Qt::Key_A || key == Qt::Key_C || key == Qt::Key_X ||
                    key == Qt::Key_V || key == Qt::Key_Z || key == Qt::Key_Y)) return {};
    if (shift) {
      if (key == Qt::Key_Z) return "redo";
      if (key == Qt::Key_S) return "saveAs";
      if (key == Qt::Key_O) return "openNewWindow";
      if (key != Qt::Key_Plus && key != Qt::Key_Equal) return {};
    }
    switch (key) {
      case Qt::Key_Q: return "quit";
      case Qt::Key_N: return "new";
      case Qt::Key_O: return "open";
      case Qt::Key_S: return "save";
      case Qt::Key_Z: return "undo";
      case Qt::Key_Y: return "redo";
      case Qt::Key_X: return "cut";
      case Qt::Key_C: return "copy";
      case Qt::Key_V: return "paste";
      case Qt::Key_A: return "selectAll";
      case Qt::Key_T: return "addPage";
      case Qt::Key_W: return "removePage";
      case Qt::Key_E: return "export";
      case Qt::Key_I: return "properties";
      case Qt::Key_B: return "sidebar";
      case Qt::Key_G: return "scope";
      case Qt::Key_F: return "search";
      case Qt::Key_Comma: return "preferences";
      case Qt::Key_0: return "fit";
      case Qt::Key_Equal: case Qt::Key_Plus: return "zoomIn";
      case Qt::Key_Minus: return "zoomOut";
    }
  } else if (!shift) {
    if (key == Qt::Key_F1) return "help";
    if (key == Qt::Key_F5) return "run";
    if (key == Qt::Key_F6) return "step";
  }
  return {};
}
bool Keyboard::eventFilter(QObject *object, QEvent *event) {
  if (object != window || modal || (event->type() != QEvent::ShortcutOverride &&
      event->type() != QEvent::KeyPress)) return false;
  auto key = static_cast<QKeyEvent *>(event);
  auto name = commandFor(key);
  if (name.isEmpty()) return false;
  key->accept();
  if (event->type() == QEvent::KeyPress) emit command(name);
  return true;
}
