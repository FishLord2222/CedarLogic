#pragma once
#include <QString>
namespace CrashReporter {
// Optional path is used by isolated crash tests; normal launches use the legacy path.
void install(const QString &path = {});
void showPending();
QString reportPath();
}
