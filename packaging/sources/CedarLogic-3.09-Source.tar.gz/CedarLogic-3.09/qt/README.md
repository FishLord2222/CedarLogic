# CedarLogic Qt frontend

The offline tutorial now uses current Qt screenshots and instructions. Its
authoring and validation workflow is documented in
[TUTORIAL_SCREENSHOTS.md](TUTORIAL_SCREENSHOTS.md).

The default CMake target builds a Qt 6.8+ Quick desktop application with no
legacy toolkit build or runtime dependency. The shared circuit model uses the existing
logic simulator, gate definitions, wire router, circuit file readers, and Skia
renderer. The original gate definitions and geometry are retained; green represents
non-driven signals and blue represents unknown signals in both themes.

## Desktop behavior

* The toolbar groups New, Open, Open Circuit in New Window, and Save in order.
  Additional-open uses the original independent-window workflow (Ctrl+Shift+O),
  with a dedicated overlapping-window icon. Fit circuit remains in View and on
  Space / Ctrl+0.

* Sidebar search spans all libraries. Choose a category when the search is empty.
  Part names are hidden by default; your choice persists across launches. Toggle them in View > Show sidebar
  part names or Preferences > Editor; the choice persists across launches.
  Named tiles adapt to the sidebar width; hiding names restores the compact grid.
  Drag a symbol onto the canvas, or click a symbol and then click the canvas.
  Each choice places one gate, then deselects the palette item. Escape cancels placement and wiring.
* Hover pins for the original red hotspot indicator, or wire segments for the red
  drag indicator. These overlays retain a fixed screen size as you zoom.
  Blue rings mark valid connection targets and free pins that line up during
  component placement or movement. They use the same eligibility checks as the
  connection action and disappear when the gesture is canceled or editing locks.
* Click pins to connect them. Click an unconnected pin and an existing segment
  to branch into that net. Different bus widths are rejected.
  Releasing a drag on empty space or outside the canvas cancels its preview.
  Click-to-connect previews hide outside the canvas and follow the mouse on return.
* Deleting a component trims its surviving wires through the original disconnect
  routine immediately. Disconnection updates paused wire states without moving
  the simulation clock; non-driven wires remain green and unknown wires blue.
* New connections and branches use the original guiWire router, including pin
  orientation, half-unit trunks and trimmed junctions. Wire drags snap both their
  starting and moving coordinates to the original half-unit grid.
* Drag gates or wire segments to move them. Shift-click adds to selection;
  dragging empty space selects a region. Right-click rotates; middle-drag pans.
  The scroll wheel zooms about the cursor. The overview can reposition the view.
  Like the original map, it fits the circuit and current viewport together,
  expanding when you pan or zoom beyond the circuit. Click or hold and drag the
  map to navigate without changing the main zoom; the accent frame tracks the view.
* Double-click RAM or ROM to open its original 16-column memory grid, with
  hexadecimal/decimal values, read/write highlights, and Open/Save/Close controls.
  Open accepts .cdm and .hex; Save writes .cdm, as in the original dialog.
  Memory file controls remain bound to the component even if selection changes.
* Double-click a decoder to choose Output polarity: Active high (normal) or
  Active low (inverted). The choice saves with the circuit and supports undo/redo.
  Existing standard decoders keep active high; the decoder chip keeps active low.
* Existing circuit pages, gate properties, input controls, RAM editing,
  undo/redo, clipboard, signing, and PNG/SVG/PDF export use the original model.
  Simulation runs on a worker thread; display refresh is independently limited.
  Structural edits update that circuit incrementally, preserving unaffected gate
  state and simulation time. Gate IDs remain stable across deletion and undo.
  New persisted IDs fit the previous Windows frontend’s 32-bit gate ID range.
* Preferences groups Appearance, Editor, and Files. Appearance has
  Follow system / Light / Dark and six accent choices. Accent changes affect
  controls and the overview frame. Circuit signal colors are isolated.
* Settings and window/sidebar size persist. Linux follows Qt's native color
  scheme and the desktop appearance portal; Windows follows Qt's native scheme.
* Atomic saves, shared legacy-compatible circuit locks, and separate recovery
  snapshots protect documents. Recovery files from live instances are skipped.

## Build

Install Qt 6.8+ Core, Gui, Quick, QuickControls2, Widgets, Svg and (Linux) DBus
SDK modules. Supply the existing Skia dist matching the target ABI. On Windows,
use a 64-bit compiler and Skia built with the dynamic MSVC runtime (`/MD`).

```sh
cmake -S . -B build-qt -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH=/path/to/Qt/6.8.3/gcc_64 \
  -DSKIA_ROOT=/path/to/skia-dist -DBUILD_TESTING=ON
cmake --build build-qt
ctest --test-dir build-qt --output-on-failure
```

The executable is `build-qt/qt/CedarLogic` (`CedarLogic.exe` on Windows).
Resources are copied beside it. For Windows distributions, include the original
bundled circuit label font as `res/LabelFont.ttf`, as in the existing release.
`InterfaceFont.ttf` and `InterfaceFont-Bold.ttf` are static Noto Sans instances
renamed Cedar UI; they are used only by the Qt interface and carry the OFL license.

The outer workspace contains package staging in `packaging/package-qt.py`, a
Windows LLVM/xwin toolchain, and separate Ubuntu 22.04 and Windows build trees.
Qt shared libraries remain replaceable. The retired desktop frontend, its build
path and compatibility branches have been removed from the current source.
Version 3.06 is preserved. Superseded 3.07 snapshots have been removed; only
the final 3.07 release set remains.

## Validation and limits

Tests cover all library gate factories, original wire color output across accent
choices, settings persistence, worker simulation, original circuit fixtures,
file round trips, placement, connection, branching/merging nets, gate moves and
rotation, undo/redo, clipboard, deletion, pages, search, and lock ownership.
UI screenshots exercise real circuits, both themes, Preferences, and display
scaling. The canvas currently rasterizes the original scene with Skia and caches
it between changes. Very large animated circuits still need performance profiling.

The oscilloscope supports named feeds, add/remove, pause/resume, reset, image
copy and legacy .cdo layouts. Legacy V1/V2 export, proximity connections, RAM
.cdm files and both legacy/native clipboard formats are exposed. See the outer
workspace's `packaging/Parity-3.06.md` for the feature comparison and verification
limits. The application's command line supports circuit opening, theme override,
UI screenshots and version/help.

## Current interface behavior

The A-key menu previews the original component under the pointer, snapping to half
units and updating when rotated. Each choice places one gate. Escape cancels the
preview. Double-click opens properties only for components with editable fields.
Menus show shortcuts; View and the categorized offline tutorial keep original order.
Print and the Simulation menu are removed. Page tabs include close buttons.
The shortcut reference uses aligned key/action rows. Image export opens a floating
window owned by the application.

Preferences has Appearance, Editor and Files. Alternate circuit-color settings and
recoloring are removed. Retired saved choices are discarded; UI accents affect only
interface controls and the overview frame. Circuit symbols, wires and signal colors
always use the original rendering, including palette and placement previews.

Simulation starts running automatically. Opening or creating circuits preserves
Run/Pause. A paused simulation shows Paused and single-step advances one tick.
The oscilloscope sits below the canvas with a draggable divider and saved height.
Native crash traces are captured and offered for local copying on the next
healthy launch. Windows distributions include the matching PDB. Reports stay local and can be copied; there is no report upload or upstream issue link.

Release downloads contain one build set per version: 3.06, 3.07 and 3.08. Filenames use
only the version, platform and architecture, without revision labels.

Wire connection previews match the original `GUICanvas::drawOverlaysInto`: one
solid green line from the exact source pin to the current mouse position.
The preview follows both held dragging and click-then-hover connections and
reanchors when zoom changes. Finished connections retain the original wire router.
Superseded migration snapshots were removed when preparing the final 3.07 release.


## Windows installer

After staging the complete Windows Qt runtime, build the per-user setup with NSIS:

```sh
python tools/build-windows-installer.py --payload /path/to/windows-runtime \
  --output /path/to/CedarLogic-3.07-Windows-Setup.exe
```

The payload includes Qt DLLs/plugins/QML, resources, licenses, matching PDB and
`vc_redist.x64.exe` version 14.44.35211.0. Setup adds Start menu shortcuts, offers
a desktop shortcut and `.cdl` association, and installs the Microsoft runtime if
missing or older. Uninstall deletes only shipped files and preserves user circuits.
A matching `.sha256` is generated beside the installer.
