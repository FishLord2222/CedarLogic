#include "Editor.h"
#include "DesktopDialogs.h"
#include "Appearance.h"
#include "MemoryTable.h"
#include "Settings.h"
#include "Changelog.h"
#include "ClipboardFormat.h"
#include <QMimeData>
#include "circuit_file_io.hpp"
#include "migrate.hpp"
#include "render/RenderStyle.h"
#include "render/Scene.h"
#include "render/SkiaProbe.h"
#include <QApplication>
#include <QClipboard>
#include <QCheckBox>
#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QRegularExpression>
#include <QHeaderView>
#include <QLabel>
#include <QLineF>
#include <QMessageBox>
#include <QPainter>
#include <QSaveFile>
#include <QStandardPaths>
#include <QTableView>
#include <QUrl>
#include <QUuid>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWindow>
#include <cmath>
#include <fstream>
#include <set>

namespace {
class Change : public QUndoCommand {
  Editor *editor;
  cl::CircuitFile before, after;

public:
  Change(Editor *e, QString label, cl::CircuitFile b, cl::CircuitFile a)
      : QUndoCommand(label), editor(e), before(std::move(b)),
        after(std::move(a)) {}
  void undo() override { editor->restore(before, after); }
  void redo() override { editor->restore(after, before); }
};
std::set<std::string> allocatedIds;
QString uuid() {
  // Decimal 32-bit gate IDs remain readable by the archived Windows frontend.
  static quint32 id = 100000;
  do {
    if (++id == 0)
      id = 1;
  } while (allocatedIds.count(std::to_string(id)));
  allocatedIds.insert(std::to_string(id));
  return QString::number(id);
}
void reserveIds(const cl::CircuitFile &file) {
  for (const auto &page : file.pages) {
    for (const auto &gate : page.gates)
      allocatedIds.insert(gate.uuid);
    for (const auto &wire : page.wires) {
      for (const auto &id : wire.ids)
        allocatedIds.insert(id);
      for (const auto &seg : wire.segments)
        allocatedIds.insert(seg.id);
    }
  }
}

void setParam(cl::GateInstance &g, const std::string &name,
              const std::string &value, bool gui) {
  for (auto &p : g.params)
    if (p.name == name && p.gui == gui) {
      p.value = value;
      return;
    }
  g.params.push_back({name, value, gui});
}
} // namespace
// Validate before replacing the live document, including recovery snapshots.
static void validateDocument(const cl::CircuitFile &document) {
    // Validate every library name, pin and segment before replacing the live
    // document.
    DocumentIds validated(document);
    for (auto &p : document.pages) {
      std::set<std::string> local;
      for (auto &g : p.gates) {
        makeGate(g.libName);
        local.insert(g.uuid);
      }
      for (auto &w : p.wires) {
        if (w.ids.empty())
          throw std::runtime_error("Wire has no IDs");
        std::set<std::string> segments;
        for (auto &s : w.segments)
          if (!segments.insert(s.id).second)
            throw std::runtime_error("Duplicate wire segment");
        for (auto &s : w.segments) {
          for (auto &x : s.intersections)
            if (!segments.count(x.segment))
              throw std::runtime_error("Unknown wire intersection");
          for (auto &c : s.connects) {
            if (!local.count(c.gateUuid))
              throw std::runtime_error("Unknown wire endpoint");
            auto g = std::find_if(p.gates.begin(), p.gates.end(), [&](auto &g) {
              return g.uuid == c.gateUuid;
            });
            auto model = makeGate(g->libName);
            const auto pins=model->getHotspotList();
            auto pin=pins.find(c.pin);
            if (pin==pins.end()) throw std::runtime_error("Unknown wire pin");
            if (w.ids.size()!=static_cast<size_t>(model->getHotspot(c.pin)->getBusLines()))
              throw std::runtime_error("Wire width does not match gate pin");
          }
        }
      }
    }
}

// A pin belongs to a single net. Keep its first claim, and report every conflict.
static int repairPinClaims(cl::CircuitFile &document) {
  int dropped = 0;
  for (auto &page : document.pages) {
    std::map<std::pair<std::string,std::string>,size_t> claims;
    for (size_t i=0; i<page.wires.size(); ++i)
      for (auto &segment : page.wires[i].segments) {
        auto &connections=segment.connects;
        connections.erase(std::remove_if(connections.begin(),connections.end(),[&](const auto &c) {
          auto claim=claims.emplace(std::make_pair(c.gateUuid,c.pin),i);
          if (claim.second) return false;
          if (claim.first->second!=i) ++dropped;
          return true; // repeated endpoints on the same net are harmless duplicates
        }),connections.end());
      }
  }
  return dropped;
}

Editor::Editor(Appearance *a, QObject *parent)
    : QObject(parent), appearance(a), simulation(this) {
  file.generator = "CedarLogic Qt";
  file.pages.push_back({});
  connect(&undoStack, &QUndoStack::indexChanged, this,
          [this] { emit changed(); });
  simulation.onFrame = [this](const SimulationFrame &frame) { receive(frame); };
  auto updateSettings = [this] {
    simulation.setInterval(appConfig().appSettings.timePerStep);
    autosave.setInterval(std::max(1, appConfig().appSettings.autosaveSeconds) *
                         1000);
    if (appConfig().appSettings.autosaveSeconds)
      autosave.start();
    else
      autosave.stop();
    emit sceneChanged();
  };
  connect(a, &Appearance::settingsChanged, this, updateSettings);
  connect(a, &Appearance::changed, this, [this] { emit sceneChanged(); });
  auto recoveryDir =
      QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
  QDir().mkpath(recoveryDir);
  recoveryPath = recoveryDir + "/recovery-" +
                 QUuid::createUuid().toString(QUuid::WithoutBraces) + ".cdl";
  recoveryLock = std::make_unique<QLockFile>(recoveryPath + ".lock");
  recoveryLock->setStaleLockTime(0);
  recoveryLock->tryLock();
  connect(&autosave, &QTimer::timeout, this, &Editor::snapshot);
  updateSettings();
  rebuild();
}
void Editor::closeMemoryDialogs() {
  const auto dialogs = memoryDialogs.values();
  for (const auto &dialog : dialogs) if (dialog) delete dialog.data();
}
Editor::~Editor() { closeMemoryDialogs(); simulation.setRunning(false); }
QString Editor::title() const {
  return (filePath.isEmpty() ? "Untitled" : QFileInfo(filePath).fileName()) +
         (dirty() ? " •" : "");
}
QStringList Editor::categories() const {
  QStringList out;
  for (auto &l : gateLibrary().libraries)
    out << QString::fromStdString(l.first);
  return out;
}
QStringList Editor::pages() const {
  QStringList out;
  for (size_t i = 0; i < file.pages.size(); ++i)
    out << QString("Page %1").arg(i + 1);
  return out;
}
void Editor::setCurrentPage(int p) {
  finishPaste(true);
  if (p < 0 || p >= static_cast<int>(file.pages.size()) || p == pageIndex)
    return;
  emit pageAboutToChange();
  pageIndex = p;
  selected.clear();
  selectedWires.clear();
  rebuild(false);
  emit pageActivated();
}
void Editor::setPlacement(const QString &name) {
  placing = name;
  placementAngle = 0;
  placementPreview.reset();
  previewAngle = -1;
  emit changed();
}
void Editor::setRunning(bool value) {
  isRunning = value;
  simulation.setRunning(value);
  message = value ? "Running" : "Paused";
  emit changed();
}
QVariantList Editor::palette(const QString &query,
                             const QString &category) const {
  QVariantList result;
  const QString q = query.trimmed();
  // Match the original Quick Add scorer: prefix/substring matches first,
  // then ordered letters with bonuses for adjacent letters and word starts.
  auto score = [](QString query, QString target) {
    query = query.toCaseFolded(); target = target.toCaseFolded();
    if (query.isEmpty()) return 0;
    if (target.startsWith(query)) return 100;
    if (target.contains(query)) return 80;
    int qi = 0, value = 0, last = -1;
    for (int ti = 0; ti < target.size() && qi < query.size(); ++ti)
      if (target[ti] == query[qi]) {
        value += 10;
        if (last == ti - 1) value += 5;
        if (ti == 0 || target[ti-1].isSpace() || target[ti-1] == '-' || target[ti-1] == '_') value += 5;
        last = ti; ++qi;
      }
    return qi == query.size() ? value : -1;
  };
  for (const auto &l : gateLibrary().libraries) {
    // Search spans every category; selecting a category applies when search is
    // empty.
    if (q.isEmpty() && !category.isEmpty() &&
        QString::fromStdString(l.first) != category)
      continue;
    for (const auto &item : l.second) {
      const auto &d = item.second;
      auto name = QString::fromStdString(d.gateName),
           caption = QString::fromStdString(d.caption);
      int relevance = std::max(score(q, name), score(q, caption));
      if (!q.isEmpty() && relevance < 0) continue;
      result << QVariantMap{{"name", name},
                            {"caption", caption},
                            {"score", relevance},
                            {"category", QString::fromStdString(l.first)}};
    }
  }
  if (!q.isEmpty()) std::stable_sort(result.begin(), result.end(), [](const QVariant &a, const QVariant &b) {
    return a.toMap()["score"].toInt() > b.toMap()["score"].toInt();
  });
  return result;
}
void Editor::rebuild(bool simulate, bool resetSimulation) {
  reserveIds(file);
  wires.clear();
  gates.clear();
  ids = DocumentIds(file);
  pageIndex = qBound(0, pageIndex, static_cast<int>(file.pages.size()) - 1);
  auto &page = file.pages.at(pageIndex);
  for (const auto &g : page.gates) {
    auto gate = makeGate(g.libName, ids.gates.at(g.uuid));
    for (const auto &p : g.params)
      if (p.gui)
        gate->setGUIParam(p.name, p.value);
      else
        gate->setLogicParam(p.name, p.value);
    if (runtimeParams.count(g.uuid))
      for (auto p : runtimeParams.at(g.uuid))
        gate->setLogicParam(p.first, p.second);
    gate->setGUIParam("angle", std::to_string(g.angle));
    gate->calcBBox();
    gate->setGLcoords(g.at.x, g.at.y);
    if (selected.contains(QString::fromStdString(g.uuid)))
      gate->select();
    gates.emplace(gate->getID(), std::move(gate));
  }
  for (const auto &w : page.wires) {
    if (w.ids.empty())
      continue;
    auto wire = std::make_unique<guiWire>();
    std::vector<IDType> wid;
    for (const auto &id : w.ids)
      wid.push_back(ids.wires.at(id));
    wire->setIDs(wid);
    for(auto id:wid) if(wireStates.count(id)) wire->setSubState(id,wireStates.at(id));
    wire->setGateResolver([this](unsigned long id) {
      auto g = gates.find(id);
      return g == gates.end() ? nullptr : g->second.get();
    });
    std::map<std::string, long> sid;
    long next = 0;
    for (auto &s : w.segments)
      sid[s.id] = next++;
    std::map<long, wireSegment> segments;
    for (const auto &s : w.segments) {
      auto n = sid.at(s.id);
      wireSegment seg(GLPoint2f(s.begin.x, s.begin.y),
                      GLPoint2f(s.end.x, s.end.y), s.vertical, n);
      for (auto &c : s.connects) {
        auto gid = ids.gates.at(c.gateUuid);
        auto found = gates.find(gid);
        if (found == gates.end())
          throw std::runtime_error("Wire references a gate on another page");
        wire->addConnection(found->second.get(), c.pin, true);
        found->second->addConnection(c.pin, wire.get());
        seg.connections.push_back({gid, c.pin});
      }
      for (auto &x : s.intersections)
        seg.intersects[x.at].push_back(sid.at(x.segment));
      segments.emplace(n, std::move(seg));
    }
    // Keep the authored wire topology, including segment IDs and intersections.
    wire->restoreSegmentMap(std::move(segments));
    if (selectedWires.contains(QString::fromStdString(w.ids[0])))
      wire->select();
    wires.push_back(std::move(wire));
  }
  refreshSignals();
  if (publishedPageCount != static_cast<int>(file.pages.size())) {
    publishedPageCount = static_cast<int>(file.pages.size());
    emit pagesChanged();
  }
  if (simulate) {
    ++generation;
    simulation.submit(file, generation, resetSimulation);
  }
  emit changed();
  emit sceneChanged();
}
void Editor::restore(const cl::CircuitFile &value, const cl::CircuitFile &reference) {
  auto restored = value;
  auto findGate = [](const cl::CircuitFile &document, const std::string &id)
      -> const cl::GateInstance * {
    for (const auto &page : document.pages)
      for (const auto &gate : page.gates)
        if (gate.uuid == id) return &gate;
    return nullptr;
  };
  for (auto &page : restored.pages) {
    for (auto &gate : page.gates) {
      const auto *baseline = findGate(reference, gate.uuid);
      const auto *current = findGate(file, gate.uuid);
      if (!baseline || !current) continue;
      for (auto &param : gate.params) {
        if (param.gui) continue;
        auto previous = std::find_if(baseline->params.begin(), baseline->params.end(),
            [&](const auto &p) { return !p.gui && p.name == param.name; });
        if (previous != baseline->params.end() && previous->value == param.value) {
          // Structural undo must not rewind inputs changed while simulating.
          auto live = std::find_if(current->params.begin(), current->params.end(),
              [&](const auto &p) { return !p.gui && p.name == param.name; });
          if (live != current->params.end()) param.value = live->value;
        } else {
          runtimeParams[gate.uuid].erase(param.name);
        }
      }
      // Drivers can acquire their first OUTPUT_NUM parameter after an edit.
      for (const auto &live : current->params) {
        if (live.gui || live.name != "OUTPUT_NUM") continue;
        auto has = [&](const cl::GateInstance &g) {
          return std::any_of(g.params.begin(), g.params.end(),
              [&](const auto &p) { return !p.gui && p.name == live.name; });
        };
        if (!has(gate) && !has(*baseline)) gate.params.push_back(live);
      }
    }
  }
  file = std::move(restored);
  rebuild();
}
void Editor::edit(const QString &label,
                  const std::function<void(cl::CircuitFile &)> &action) {
  finishPaste(true);
  if (locked && label != "Change input" && label != "Edit RAM" &&
      label != "Gate properties")
    return;
  auto after = file;
  action(after);
  if (after == file)
    return;
  undoStack.push(new Change(this, label, file, std::move(after)));
}
void Editor::receive(const SimulationFrame &frame) {
  if (frame.generation != generation)
    return;
  if (!frame.error.empty()) {
    setRunning(false);
    setStatus(QString::fromStdString(frame.error));
    return;
  }
  lastSimulationTime = frame.time;
  wireStates = frame.wires;
  for (const auto &w : wires)
    for (auto id : w->getIDs()) {
      auto state = frame.wires.find(id);
      if (state != frame.wires.end())
        w->setSubState(id, state->second);
    }
  for (const auto &p : frame.params) {
    const auto owner = ids.gateUuids.find(p.gate);
    if (owner != ids.gateUuids.end()) {
      auto &params = runtimeParams[owner->second];
      if (p.name == "MemoryReset") {
        params.clear();
        for (auto &page : file.pages)
          for (auto &gate : page.gates)
            if (gate.uuid == owner->second)
              gate.params.erase(std::remove_if(gate.params.begin(), gate.params.end(),
                  [](const auto &param) {
                    return !param.gui && param.name.rfind("Address:", 0) == 0;
                  }), gate.params.end());
      }
      params[p.name] = p.value;
    }
    auto g = gates.find(p.gate);
    if (g != gates.end())
      g->second->setLogicParam(p.name, p.value);
    if (p.name == "PAUSE_SIM")
      setRunning(false);
  }
  if (!freezeScope && (historyTime == TIME_NONE || frame.time != historyTime)) {
    if (historyTime != TIME_NONE && frame.time < historyTime)
      history.clear();
    historyTime = frame.time;
    auto capture = [this](const auto &sample) {
      for (const auto &state : sample) {
        auto &values = history[state.first];
        values.push_back(state.second);
        if (values.size() > 256) values.pop_front();
      }
    };
    if (frame.samples.empty()) capture(frame.wires);
    else for (const auto &sample : frame.samples) capture(sample);
    emit tracesChanged();
  }
  message = isRunning ? "Running" : "Paused";
  emit changed();
  emit frameReady();
}
void Editor::draw(cl::render::Scene &scene,
                  const cl::render::RenderStyle &style) {
  for (auto &wire : wires) wire->drawToScene(scene, style);
  for (auto &gate : gates) gate.second->drawToScene(scene, style);
}
guiGate *Editor::preparePlacement(QPointF point) {
  if (placing.isEmpty() || locked) return nullptr;
  // Reuse the symbol while the cursor moves. Rotation and snapping stay live.
  if (!placementPreview) placementPreview = makeGate(placing.toStdString());
  if (previewAngle != placementAngle) {
    placementPreview->setGUIParam("angle", std::to_string(placementAngle));
    previewAngle = placementAngle;
  }
  placementPreview->setGLcoords(std::round(point.x()*2)/2, std::round(point.y()*2)/2);
  return placementPreview.get();
}
void Editor::drawPlacement(cl::render::Scene &scene,
                           const cl::render::RenderStyle &style, QPointF point) {
  auto *preview = preparePlacement(point);
  if (!preview) return;
  auto previewStyle = style;
  previewStyle.showSelection = false;
  preview->drawToScene(scene, previewStyle);
}
QRectF Editor::bounds() const {
  QRectF result;
  bool first = true;
  for (auto &g : gates) {
    auto b = g.second->getBBox();
    auto lo = b.getBottomLeft(), hi = b.getTopRight();
    QRectF box(QPointF(lo.x, lo.y), QPointF(hi.x, hi.y));
    if (first) {
      result = box;
      first = false;
    } else
      result = result.united(box);
  }
  for (auto &w : wires) {
    auto b = w->getBBox();
    if (b.empty())
      continue;
    auto lo = b.getBottomLeft(), hi = b.getTopRight();
    QRectF box(QPointF(lo.x, lo.y), QPointF(hi.x, hi.y));
    if (first) {
      result = box;
      first = false;
    } else
      result = result.united(box);
  }
  return first ? QRectF(-20, -15, 40, 30)
               : result.normalized().adjusted(-3, -3, 3, 3);
}
void Editor::selectionChanged() {
  for (auto &g : file.pages[pageIndex].gates) {
    auto &model = gates.at(ids.gates.at(g.uuid));
    if (selected.contains(QString::fromStdString(g.uuid)))
      model->select();
    else
      model->unselect();
  }
  for (size_t i = 0; i < wires.size(); ++i) {
    if (selectedWires.contains(
            QString::fromStdString(file.pages[pageIndex].wires[i].ids[0])))
      wires[i]->select();
    else
      wires[i]->unselect();
  }
  emit sceneChanged();
}
bool Editor::selectAt(QPointF p, bool additive) {
  const auto &page = file.pages[pageIndex];
  for (auto it = page.gates.rbegin(); it != page.gates.rend(); ++it) {
    auto b = gates.at(ids.gates.at(it->uuid))->getSelectionBBox();
    auto lo = b.getBottomLeft(), hi = b.getTopRight();
    if (p.x() >= lo.x && p.x() <= hi.x && p.y() >= lo.y && p.y() <= hi.y) {
      auto id = QString::fromStdString(it->uuid);
      if (additive) {
        if (selected.contains(id))
          selected.remove(id);
        else
          selected.insert(id);
      } else if (!selected.contains(id)) {
        selected.clear();
        selectedWires.clear();
        selected.insert(id);
      }
      selectionChanged();
      return true;
    }
  }
  if (!additive) {
    selected.clear();
    selectedWires.clear();
  }
  selectionChanged();
  return false;
}
bool Editor::selectEditableAt(QPointF point) {
  if (locked) return false;
  for (auto it = file.pages[pageIndex].gates.rbegin();
       it != file.pages[pageIndex].gates.rend(); ++it) {
    auto &model = gates.at(ids.gates.at(it->uuid));
    auto box = model->getSelectionBBox();
    auto lo = box.getBottomLeft(), hi = box.getTopRight();
    if (point.x() < lo.x || point.x() > hi.x ||
        point.y() < lo.y || point.y() > hi.y) continue;
    const auto &definition = gateLibrary().libraries.at(model->getLibraryName()).at(it->libName);
    if (definition.dlgParams.empty() && definition.logicType != "DECODER" &&
        !dynamic_cast<guiGateRAM *>(model.get())) return false;
    selected = {QString::fromStdString(it->uuid)};
    selectedWires.clear();
    selectionChanged();
    return true;
  }
  return false;
}
void Editor::selectBox(QRectF rect, bool additive) {
  if (!additive) {
    selected.clear();
    selectedWires.clear();
  }
  for (auto &g : file.pages[pageIndex].gates) {
    auto b = gates.at(ids.gates.at(g.uuid))->getSelectionBBox();
    auto lo = b.getBottomLeft(), hi = b.getTopRight();
    if (rect.intersects(
            QRectF(QPointF(lo.x, lo.y), QPointF(hi.x, hi.y)).normalized()))
      selected.insert(QString::fromStdString(g.uuid));
  }
  selectionChanged();
}
void Editor::placeAt(QPointF point) {
  if (placing.isEmpty() || locked)
    return;
  undoStack.beginMacro("Place gate");
  auto name = placing.toStdString();
  auto id = uuid().toStdString();
  edit("Place gate", [&](cl::CircuitFile &f) {
    cl::GateInstance g;
    g.uuid = id;
    g.libName = name;
    g.angle=placementAngle;
    g.at = {std::round(point.x()*2)/2, std::round(point.y()*2)/2};
    f.pages[pageIndex].gates.push_back(g);
  });
  selected = {QString::fromStdString(id)};
  selectedWires.clear();
  setPlacement("");
  selectionChanged();
  autoConnect();
  undoStack.endMacro();
}
void Editor::startMove() {
  if (locked)
    return;
  moveBefore = file;
  moveWireMaps.clear();
  for (const auto &wire : wires) moveWireMaps.push_back(wire->getSegmentMap());
  moving = true;
}
void Editor::moveSelected(QPointF delta) {
  if (!moving)
    return;
  file = moveBefore;
  auto &page = file.pages[pageIndex];
  for (auto &g : page.gates)
    if (selected.contains(QString::fromStdString(g.uuid))) {
      g.at.x += delta.x();
      g.at.y += delta.y();
    }
  for (size_t i = 0; i < wires.size(); ++i)
    wires[i]->restoreSegmentMap(moveWireMaps.at(i));
  // Let the original router update connected wires after moving the gates.
  for (auto &g : page.gates)
    if (selected.contains(QString::fromStdString(g.uuid)))
      gates.at(ids.gates.at(g.uuid))->setGLcoords(g.at.x, g.at.y);
  for (size_t i = 0; i < wires.size(); ++i) {
    bool allSelected = true;
    bool hasConnections = false;
    for (const auto &segment : moveBefore.pages[pageIndex].wires[i].segments)
      for (const auto &connection : segment.connects) {
        hasConnections = true;
        if (!selected.contains(QString::fromStdString(connection.gateUuid))) allSelected = false;
      }
    if (!allSelected) continue;
    // Match the original guiWire::move: a complete connected selection carries
    // the authored route even when marquee selection only selected the gates.
    // An unconnected wire still requires explicit selection to move.
    if (!hasConnections &&
        !selectedWires.contains(QString::fromStdString(page.wires[i].ids[0]))) continue;
    auto route = moveWireMaps.at(i);
    for (auto &[id, segment] : route) {
      segment.begin.x += delta.x(); segment.end.x += delta.x();
      segment.begin.y += delta.y(); segment.end.y += delta.y();
      decltype(segment.intersects) intersections;
      for (auto entry : segment.intersects)
        intersections[entry.first + (segment.verticalSeg ? delta.y() : delta.x())] = entry.second;
      segment.intersects = std::move(intersections);
      segment.calcBBox();
    }
    wires[i]->restoreSegmentMap(std::move(route));
  }
  captureWires();
  emit sceneChanged();
}
void Editor::captureWire(guiWire &wire, cl::WireInstance &target) {
  const auto segs = wire.getSegmentMap();
  std::map<long, std::string> names;
  long n = 0;
  for (const auto &segment : target.segments) names[n++] = segment.id;
  for (const auto &entry : segs)
    if (!names.count(entry.first)) names[entry.first] = uuid().toStdString();
  target.segments.clear();
  for (const auto &entry : segs) {
    const auto &seg = entry.second;
    cl::WireSegment out;
    out.id = names.at(entry.first);
    out.vertical = seg.verticalSeg;
    out.begin = {seg.begin.x, seg.begin.y};
    out.end = {seg.end.x, seg.end.y};
    for (const auto &connection : seg.connections) {
      const auto gate = ids.gateUuids.find(connection.gid);
      if (gate != ids.gateUuids.end() && gates.count(connection.gid))
        out.connects.push_back({gate->second, connection.connection});
    }
    for (const auto &crossing : seg.intersects)
      for (auto other : crossing.second)
        out.intersections.push_back({crossing.first, names.at(other)});
    target.segments.push_back(std::move(out));
  }
}
void Editor::captureWires() {
  auto &page = file.pages[pageIndex];
  for (size_t i = 0; i < wires.size(); ++i) captureWire(*wires[i], page.wires[i]);
}
std::unique_ptr<guiWire> Editor::copyWireRoute(int index) {
  auto result = std::make_unique<guiWire>();
  result->setGateResolver([this](unsigned long id) { return gates.at(id).get(); });
  if (index >= 0) {
    result->setIDs(wires[index]->getIDs());
    for (const auto &connection : wires[index]->getConnections())
      result->addConnection(gates.at(connection.gid).get(), connection.connection, true);
    result->restoreSegmentMap(wires[index]->getSegmentMap());
  }
  return result;
}

void Editor::finishMove() {
  if (!moving)
    return;
  moving = false;
  // Original GUICanvas::OnMouseUp finalizes connected segments before recording
  // the move. Trim old bends/tails after pins meet on the same axis, preserving
  // the user-positioned route while the selection is still at its new position.
  if (!(file == moveBefore)) {
    for (const auto &gate : file.pages[pageIndex].gates)
      if (selected.contains(QString::fromStdString(gate.uuid)))
        gates.at(ids.gates.at(gate.uuid))->finalizeWirePlacements();
    captureWires();
  }
  auto after = file;
  file = moveBefore;
  if (!(after == file)) {
    undoStack.beginMacro("Move gates");
    undoStack.push(new Change(this,"Move gates",file,std::move(after)));
    autoConnect();undoStack.endMacro();
  } else
    rebuild(false);
}
void Editor::cancelMove() {
  if (draggingWire >= 0) {
    draggingWire = -1;
    file = moveBefore;
    rebuild(false);
  }
  if (!moving)
    return;
  moving = false;
  file = moveBefore;
  rebuild(false);
}
QVariantMap Editor::pinAt(QPointF point, double radius) const {
  for (auto &g : file.pages[pageIndex].gates) {
    auto &model = gates.at(ids.gates.at(g.uuid));
    auto name = model->checkHotspots(point.x(), point.y(), radius);
    if (!name.empty()) {
      auto p = model->getHotspotList().at(name);
      auto &def =
          gateLibrary().libraries.at(model->getLibraryName()).at(g.libName);
      auto hs = std::find_if(def.hotspots.begin(), def.hotspots.end(),
                             [&](auto &h) { return h.name == name; });
      return {{"gate", QString::fromStdString(g.uuid)},
              {"pin", QString::fromStdString(name)},
              {"x", p.x},
              {"y", p.y},
              {"bits", hs->busLines}};
    }
  }
  return {};
}
int Editor::wireForPin(const QVariantMap &pin) const {
  const auto &nets = file.pages[pageIndex].wires;
  const auto gate = pin["gate"].toString().toStdString();
  const auto name = pin["pin"].toString().toStdString();
  for (size_t i = 0; i < nets.size(); ++i)
    for (const auto &segment : nets[i].segments)
      for (const auto &connection : segment.connects)
        if (connection.gateUuid == gate && connection.pin == name) return int(i);
  return -1;
}
QVariantMap Editor::connectionTarget(const QVariantMap &start, QPointF point, double radius) const {
  if (locked || start.isEmpty()) return {};
  const auto source = ids.gates.find(start["gate"].toString().toStdString());
  if (source == ids.gates.end() || !gates.count(source->second) ||
      !gates.at(source->second)->getHotspotList().count(start["pin"].toString().toStdString())) return {};
  const auto target = pinAt(point, radius);
  const auto sourceNet = wireForPin(start);
  if (!target.isEmpty()) {
    if (start["bits"] != target["bits"] ||
        (start["gate"] == target["gate"] && start["pin"] == target["pin"]) ||
        (sourceNet >= 0 && sourceNet == wireForPin(target))) return {};
    return target;
  }
  // A free pin can branch onto a net. Match the connection handler's first hit
  // and width rules; a pin already on a net cannot branch directly onto a wire.
  if (sourceNet >= 0) return {};
  for (size_t i = 0; i < wires.size(); ++i) {
    if (!wires[i]->hover(point.x(), point.y(), radius)) continue;
    if (file.pages[pageIndex].wires[i].ids.size() != size_t(start["bits"].toInt())) return {};
    for (const auto &segment : file.pages[pageIndex].wires[i].segments) {
      QPointF nearest(segment.vertical ? segment.begin.x : std::clamp(point.x(), segment.begin.x, segment.end.x),
                      segment.vertical ? std::clamp(point.y(), segment.begin.y, segment.end.y) : segment.begin.y);
      if (QLineF(nearest, point).length() <= radius)
        return {{"x", nearest.x()}, {"y", nearest.y()}};
    }
    return {};
  }
  return {};
}
void Editor::connectPins(const QVariantMap &a, const QVariantMap &b) {
  if (locked || a.isEmpty() || b.isEmpty() || a == b) return;
  if (a["bits"] != b["bits"]) {
    setStatus("Cannot connect pins of different widths"); return;
  }
  const auto ga=a["gate"].toString().toStdString(), gb=b["gate"].toString().toStdString();
  const auto pa=a["pin"].toString().toStdString(), pb=b["pin"].toString().toStdString();
  const auto &page=file.pages[pageIndex];
  auto findNet=[&](const std::string &gate,const std::string &pin) {
    for(size_t i=0;i<page.wires.size();++i)
      for(const auto &segment:page.wires[i].segments)
        for(const auto &connection:segment.connects)
          if(connection.gateUuid==gate && connection.pin==pin) return int(i);
    return -1;
  };
  const int first=findNet(ga,pa), last=findNet(gb,pb);
  if(first>=0 && first==last) return;
  const int target=first>=0?first:last;
  auto route=copyWireRoute(target);
  if(target<0) {
    route->addConnection(gates.at(ids.gates.at(ga)).get(),pa);
    route->addConnection(gates.at(ids.gates.at(gb)).get(),pb);
  } else if(first>=0 && last>=0) {
    // Preserve the target route and attach the other net's pins with the same
    // nearest-segment/merge handling used by original wire connections.
    for(const auto &connection:wires[last]->getConnections())
      route->addConnection(gates.at(connection.gid).get(),connection.connection);
  } else {
    route->addConnection(gates.at(ids.gates.at(first<0?ga:gb)).get(),first<0?pa:pb);
  }
  edit("Connect wire",[&](cl::CircuitFile &f) {
    auto &nets=f.pages[pageIndex].wires;
    int index=target;
    if(index<0) {
      cl::WireInstance wire;
      for(int bit=0;bit<a["bits"].toInt();++bit) wire.ids.push_back(uuid().toStdString());
      nets.push_back(std::move(wire));index=int(nets.size())-1;
    }
    captureWire(*route,nets[index]);
    if(first>=0 && last>=0) nets.erase(nets.begin()+last);
  });
}
bool Editor::connectPinToWire(const QVariantMap &start,QPointF end,double radius) {
  if(start.isEmpty() || locked) return false;
  const auto &page=file.pages[pageIndex];
  for(size_t i=0;i<wires.size();++i) {
    if(!wires[i]->hover(end.x(),end.y(),radius)) continue;
    if(page.wires[i].ids.size()!=size_t(start["bits"].toInt())) {
      setStatus("Cannot connect pins of different widths"); return true;
    }
    const auto gate=start["gate"].toString().toStdString(),pin=start["pin"].toString().toStdString();
    for(const auto &wire:page.wires)
      for(const auto &segment:wire.segments)
        for(const auto &connection:segment.connects)
          if(connection.gateUuid==gate && connection.pin==pin) {
            setStatus("Connect an existing net through one of its pins"); return true;
          }
    auto route=copyWireRoute(int(i));
    // Original cmdConnectWire connects to the net, then guiWire chooses and
    // trims the nearest branch. The release pixel is not a permanent endpoint.
    route->addConnection(gates.at(ids.gates.at(gate)).get(),pin);
    edit("Branch wire",[&](cl::CircuitFile &f){captureWire(*route,f.pages[pageIndex].wires[i]);});
    return true;
  }
  return false;
}

bool Editor::interactAt(QPointF point) {
  for (auto &g : gates) {
    std::unique_ptr<klsMessage::Message_SET_GATE_PARAM> msg(
        g.second->checkClick(point.x(), point.y()));
    if (!msg)
      continue;
    auto id = g.first;
    // Input events are commands, not edits to deduplicated document snapshots.
    // In particular every pulse click must reach the core, even at the same width.
    if(msg->paramName!="PULSE") {
      for(auto &gate:file.pages[pageIndex].gates) if(ids.gates.at(gate.uuid)==id) {
        setParam(gate,msg->paramName,msg->paramValue,false);
        runtimeParams[gate.uuid].erase(msg->paramName);
      }
    }
    simulation.setGateParameter(id,msg->paramName,msg->paramValue);
    emit sceneChanged();
    return true;
  }
  return false;
}
StateType Editor::wireState(const std::string &id) const {
  auto found=ids.wires.find(id);
  return found!=ids.wires.end() && wireStates.count(found->second)?wireStates.at(found->second):UNKNOWN;
}
QString Editor::gateValue(const std::string &id,const std::string &name) const {
  auto gate=runtimeParams.find(id);
  if(gate!=runtimeParams.end() && gate->second.count(name)) return QString::fromStdString(gate->second.at(name));
  for(const auto &page:file.pages) for(const auto &gate:page.gates) if(gate.uuid==id)
    for(const auto &p:gate.params) if(!p.gui && p.name==name) return QString::fromStdString(p.value);
  return {};
}
void Editor::deleteSelection() {
  if (locked) return;
  // Clean connections while their gate objects still exist, exactly as the
  // original disconnect/delete commands do. Erasing references alone leaves
  // the removed source's branch and trunk extent in the surviving wire.
  std::map<size_t,std::unique_ptr<guiWire>> trimmed;
  std::set<size_t> removed;
  const auto &page=file.pages[pageIndex];
  for(size_t i=0;i<page.wires.size();++i) {
    if(selectedWires.contains(QString::fromStdString(page.wires[i].ids[0]))) {
      removed.insert(i);continue;
    }
    std::vector<wireConnection> excluded;
    for(const auto &connection:wires[i]->getConnections())
      for(const auto &gate:page.gates)
        if(ids.gates.at(gate.uuid)==connection.gid && selected.contains(QString::fromStdString(gate.uuid)))
          excluded.push_back(connection);
    if(excluded.empty()) continue;
    auto route=copyWireRoute(int(i));
    if(route->numConnections()-long(excluded.size())<2) {removed.insert(i);continue;}
    for(const auto &connection:excluded)
      route->removeConnection(gates.at(connection.gid).get(),connection.connection);
    trimmed.emplace(i,std::move(route));
  }
  edit("Delete gates",[&](cl::CircuitFile &f) {
    auto &after=f.pages[pageIndex];
    for(auto &entry:trimmed) captureWire(*entry.second,after.wires[entry.first]);
    for(auto i=removed.rbegin();i!=removed.rend();++i) after.wires.erase(after.wires.begin()+*i);
    after.gates.erase(std::remove_if(after.gates.begin(),after.gates.end(),[&](const auto &g) {
      return selected.contains(QString::fromStdString(g.uuid));
    }),after.gates.end());
  });
  selected.clear();selectedWires.clear();selectionChanged();
}

void Editor::rotateSelection() {
  if (locked)
    return;
  if(!placing.isEmpty()){placementAngle=std::fmod(placementAngle+270,360.0);emit changed();return;}
  bool rotated=false;
  auto before = file;
  for (auto &g : file.pages[pageIndex].gates)
    if (selected.contains(QString::fromStdString(g.uuid))) {
      bool connected=false;
      for(const auto &wire:file.pages[pageIndex].wires)for(const auto &seg:wire.segments)for(const auto &conn:seg.connects)if(conn.gateUuid==g.uuid)connected=true;
      if(connected)continue;
      rotated=true;
      g.angle = std::fmod(g.angle + 270, 360.0);
      auto &gate = gates.at(ids.gates.at(g.uuid));
      gate->setGUIParam("angle", std::to_string(g.angle));
      gate->setGLcoords(g.at.x, g.at.y);
    }
  if(!rotated)return;
  captureWires();
  auto after = file;
  file = before;
  if (!(after == before))
    undoStack.push(new Change(this, "Rotate gates", before, std::move(after)));
}

void Editor::selectAll() {
  selected.clear();
  selectedWires.clear();
  for (auto &w : file.pages[pageIndex].wires)
    selectedWires.insert(QString::fromStdString(w.ids[0]));
  for (auto &g : file.pages[pageIndex].gates)
    selected.insert(QString::fromStdString(g.uuid));
  selectionChanged();
}
void Editor::copy() {
  cl::CircuitFile clip;clip.pages.push_back({});auto live=runtimeFile();
  for(auto g:live.pages[pageIndex].gates)if(selected.contains(QString::fromStdString(g.uuid)))clip.pages[0].gates.push_back(g);
  for(size_t i=0;i<file.pages[pageIndex].wires.size();++i) {
    auto wire=file.pages[pageIndex].wires[i];std::set<std::pair<std::string,std::string>> included,excluded;
    for(auto seg:wire.segments)for(auto c:seg.connects)(selected.contains(QString::fromStdString(c.gateUuid))?included:excluded).insert({c.gateUuid,c.pin});
    if(included.size()<2)continue;
    if(!excluded.empty()) {
      guiWire trimmed;trimmed.setIDs(wires[i]->getIDs());trimmed.setGateResolver([this](unsigned long id){return gates.at(id).get();});
      for(auto c:wires[i]->getConnections())trimmed.addConnection(gates.at(c.gid).get(),c.connection,true);
      trimmed.restoreSegmentMap(wires[i]->getSegmentMap());
      for(auto c:excluded)trimmed.removeConnection(gates.at(ids.gates.at(c.first)).get(),c.second);
      wire.segments.clear();for(auto entry:trimmed.getSegmentMap()){auto seg=entry.second;cl::WireSegment out;out.id=std::to_string(seg.id);out.vertical=seg.verticalSeg;out.begin={seg.begin.x,seg.begin.y};out.end={seg.end.x,seg.end.y};for(auto c:seg.connections)for(auto gate:file.pages[pageIndex].gates)if(ids.gates.at(gate.uuid)==c.gid)out.connects.push_back({gate.uuid,c.connection});for(auto x:seg.intersects)for(auto id:x.second)out.intersections.push_back({x.first,std::to_string(id)});wire.segments.push_back(out);}
    }
    clip.pages[0].wires.push_back(wire);
  }
  if(clip.pages[0].gates.empty())return;
  auto data=new QMimeData;data->setData("application/x-cedarlogic-circuit",QByteArray::fromStdString(cl::writeCircuitFile(clip)));data->setText(QString::fromStdString(legacyClipboard(clip)));qApp->clipboard()->setMimeData(data);
}
void Editor::cut() {
  copy();
  deleteSelection();
}
void Editor::paste(bool interactive) {
  if(locked)return;
  finishPaste(true);
  try {
    auto data=qApp->clipboard()->mimeData();
    auto clip=data->hasFormat("application/x-cedarlogic-circuit")?cl::loadCircuit(data->data("application/x-cedarlogic-circuit").toStdString()).file:readClipboard(data->text().toStdString());
    if (clip.pages.empty())
      return;
    if(clip.pages[0].gates.size()==1 && !(QApplication::keyboardModifiers() & Qt::ShiftModifier)) {
      auto &gate=clip.pages[0].gates[0];auto model=makeGate(gate.libName);
      if(model->getGUIType()=="TO" || model->getGUIType()=="FROM")for(auto &param:gate.params)if(!param.gui && param.name=="JUNCTION_ID") {
        auto name=QString::fromStdString(param.value);auto match=QRegularExpression("(\\d+)$").match(name);
        if(match.hasMatch()){bool ok;auto n=match.captured(1).toULongLong(&ok);if(ok && n<0xffffffffULL){name.replace(match.capturedStart(1),match.capturedLength(1),QString::number(n+1));param.value=name.toStdString();auto updated=new QMimeData;updated->setData("application/x-cedarlogic-circuit",QByteArray::fromStdString(cl::writeCircuitFile(clip)));updated->setText(QString::fromStdString(legacyClipboard(clip)));qApp->clipboard()->setMimeData(updated);}}
      }
    }
    auto page = clip.pages[0];
    std::map<std::string, std::string> remap;
    selected.clear();
    selectedWires.clear();
    for (auto &g : page.gates) {
      auto id = uuid().toStdString();
      remap[g.uuid] = id;
      g.uuid = id;
      g.at.x += 5;
      g.at.y -= 5;
      selected.insert(QString::fromStdString(id));
    }
    for (auto &w : page.wires) {
      for (auto &id : w.ids)
        id = uuid().toStdString();
      selectedWires.insert(QString::fromStdString(w.ids[0]));
      for (auto &s : w.segments) {
        s.begin.x += 5;
        s.end.x += 5;
        s.begin.y -= 5;
        s.end.y -= 5;
        for (auto &c : s.connects)
          c.gateUuid = remap.at(c.gateUuid);
        for (auto &x : s.intersections)
          x.at += s.vertical ? -5 : 5;
      }
    }
    auto after=file;auto &dest=after.pages[pageIndex];dest.gates.insert(dest.gates.end(),page.gates.begin(),page.gates.end());dest.wires.insert(dest.wires.end(),page.wires.begin(),page.wires.end());
    if(interactive && !page.gates.empty()) {
      pasteBefore=file;file=std::move(after);pastePending=true;rebuild(false);startMove();
      QPointF anchor;for(auto g:page.gates)anchor+=QPointF(g.at.x,g.at.y);anchor/=page.gates.size();emit pastePlacementRequested(anchor);
    } else edit("Paste",[&](auto &f){f=after;});
  } catch (const std::exception &e) {
    setStatus(QString("Paste failed: %1").arg(e.what()));
  }
}
void Editor::finishPaste(bool commit) {
  if(!pastePending)return;pastePending=false;moving=false;
  auto after=file;file=pasteBefore;
  if(commit){undoStack.beginMacro("Paste");undoStack.push(new Change(this,"Paste",file,std::move(after)));autoConnect();undoStack.endMacro();}
  else {selected.clear();selectedWires.clear();rebuild(false);}
}
void Editor::undo() { if(pastePending)finishPaste(false);else undoStack.undo(); }
void Editor::redo() { undoStack.redo(); }
void Editor::step(int count) { simulation.step(count); }
void Editor::addPage() {
  if(file.pages.size()>=42){setStatus("The maximum is 42 circuit pages.");return;}
  edit("Add page", [](auto &f) {
    cl::Page page;
    page.index = f.pages.size();
    f.pages.push_back(page);
  });
  setCurrentPage(file.pages.size() - 1);
}
void Editor::removePage(int index) {
  if (locked || file.pages.size() < 2) return;
  const int closing = index < 0 ? pageIndex : index;
  if (closing < 0 || closing >= static_cast<int>(file.pages.size())) return;
  finishPaste(true);
  emit pageAboutToChange();
  std::map<int, QVariantMap> retainedViews;
  for (const auto &view : pageViews)
    if (view.first != closing)
      retainedViews[view.first - (view.first > closing ? 1 : 0)] = view.second;
  pageViews = std::move(retainedViews);
  pageIndex = std::min(pageIndex - (closing < pageIndex ? 1 : 0),
                       static_cast<int>(file.pages.size()) - 2);
  edit("Remove page", [&](auto &f) {
    f.pages.erase(f.pages.begin() + closing);
    for (size_t i = 0; i < f.pages.size(); ++i) f.pages[i].index = i;
  });
  emit pageActivated();
}
bool Editor::confirmClose() {
  finishPaste(false);
  if (!dirty())
    return true;
  auto choice = DesktopDialogs::question(*appearance, 
      nullptr, "Unsaved circuit", "Save changes to " + title() + "?",
      QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel,
      QMessageBox::Save);
  if (choice == QMessageBox::Cancel)
    return false;
  if (choice == QMessageBox::Save)
    return save();
  QFile::remove(recoveryPath);
  if (!recoveredPath.isEmpty()) QFile::remove(recoveredPath);
  recoveredPath.clear();
  recoveredLock.reset();
  return true;
}
void Editor::newDocument() {
  if (!confirmClose())
    return;
  const bool resume = isRunning;
  setRunning(false);
  closeMemoryDialogs();
  lock.reset();
  filePath.clear();
  runtimeParams.clear();
  wireStates.clear();
  history.clear();
  historyTime = TIME_NONE;
  lastSimulationTime = TIME_NONE;
  pageViews.clear();
  pageIndex = 0;
  selected.clear();
  selectedWires.clear();
  file = {};
  file.generator = "CedarLogic Qt";
  file.pages.push_back({});
  undoStack.clear();
  rebuild(true, true);
  setRunning(resume);
  emit cameraFitRequested();
}
void Editor::openDialog() {
  auto path = QFileDialog::getOpenFileName(
      nullptr, "Open circuit", filePath.isEmpty()?appearance->editorSettings()["lastDir"].toString():filePath,
      "CedarLogic circuits (*.cdl);;All files (*)");
  if (!path.isEmpty())
    openPath(path);
}
bool Editor::openPath(const QString &inputPath, bool showErrors) {
  auto path = QFileInfo(inputPath).canonicalFilePath();
  if (path.isEmpty())
    path = QFileInfo(inputPath).absoluteFilePath();
  if (!confirmClose())
    return false;
  try {
    QFile input(path);
    if (!input.open(QIODevice::ReadOnly))
      throw std::runtime_error(input.errorString().toStdString());
    auto result = cl::loadCircuit(input.readAll().toStdString());
    if (result.file.pages.empty())
      result.file.pages.push_back({});
    const int dropped=repairPinClaims(result.file);
    validateDocument(result.file);
    auto newLock = std::make_unique<DocumentLock>();
    QString error;
    if (path != filePath && !newLock->acquire(path, error))
      throw std::runtime_error(error.toStdString());
    const bool resume = isRunning;
    setRunning(false);
    closeMemoryDialogs();
    locked = false;
    if (path != filePath)
      lock = std::move(newLock);
    runtimeParams.clear();
    wireStates.clear();
    history.clear();
    historyTime = TIME_NONE;
    lastSimulationTime = TIME_NONE;
    file = std::move(result.file);
    filePath = path;
    auto preferences=appearance->editorSettings();preferences["lastDir"]=QFileInfo(path).absolutePath();appearance->apply(appearance->mode(),appearance->accentName(),preferences);
    pageViews.clear();
    pageIndex = 0;
    selected.clear();
    selectedWires.clear();
    undoStack.clear();
    rebuild(true, true);
    setRunning(resume);
    emit cameraFitRequested();
    if (dropped) {
      undoStack.resetClean();
      const auto warning=QString("Loaded with %1 conflicting pin connections dropped; the first wire was kept. Review wiring before saving.").arg(dropped);
      setStatus(warning);
      if (showErrors) DesktopDialogs::warning(*appearance,nullptr,"Circuit wiring repaired",warning);
    }
    else if (!result.notices.empty())
      setStatus(QString("Loaded with %1 migration notices")
                    .arg(result.notices.size()));
    return true;
  } catch (const std::exception &e) {
    setStatus(QString::fromUtf8(e.what()));
    if (showErrors)
      DesktopDialogs::warning(*appearance, nullptr, "Cannot open circuit",
                           QString::fromUtf8(e.what()));
    return false;
  }
}
bool Editor::writePath(const QString &path) {
  QSaveFile output(path);
  if (!output.open(QIODevice::WriteOnly)) {
    DesktopDialogs::warning(*appearance, nullptr, "Cannot save", output.errorString());
    return false;
  }
  auto text = QByteArray::fromStdString(cl::writeCircuitFile(runtimeFile()));
  if (output.write(text) != text.size() || !output.commit()) {
    DesktopDialogs::warning(*appearance, nullptr, "Cannot save", output.errorString());
    return false;
  }
  filePath = path;
  undoStack.setClean();
  QFile::remove(recoveryPath);
  if (!recoveredPath.isEmpty()) QFile::remove(recoveredPath);
  recoveredPath.clear();
  recoveredLock.reset();
  emit changed();
  return true;
}
bool Editor::save() {
  finishPaste(true);
  return filePath.isEmpty() ? saveAs() : writePath(filePath);
}
bool Editor::saveAs() {
  finishPaste(true);
  auto path = QFileDialog::getSaveFileName(
      nullptr, "Save circuit", filePath.isEmpty() ? "Untitled.cdl" : filePath,
      "CedarLogic circuits (*.cdl)");
  if (path.isEmpty())
    return false;
  if (!path.endsWith(".cdl", Qt::CaseInsensitive))
    path += ".cdl";
  if (path == filePath)
    return writePath(path);
  auto newLock = std::make_unique<DocumentLock>();
  QString error;
  if (!newLock->acquire(path, error)) {
    DesktopDialogs::warning(*appearance, nullptr, "Cannot save", error);
    return false;
  }
  if (!writePath(path))
    return false;
  lock = std::move(newLock);
  return true;
}
QVariantList Editor::parameterFields() const {
  QVariantList result;
  if (selected.size() != 1)
    return result;
  auto key = *selected.begin();
  for (auto &g : file.pages[pageIndex].gates)
    if (QString::fromStdString(g.uuid) == key) {
      auto &model = gates.at(ids.gates.at(g.uuid));
      const auto &def =
          gateLibrary().libraries.at(model->getLibraryName()).at(g.libName);
      if (def.logicType == "DECODER") {
        result << QVariantMap{{"key", "logic:OUTPUT_POLARITY"},
                              {"label", "Output polarity"}, {"type", "CHOICE"},
                              {"value", QString::fromStdString(decoderOutputPolarity(def, g))},
                              {"choices", QStringList{"HIGH", "LOW"}},
                              {"labels", QStringList{"Active high — normal output", "Active low — inverted output"}}};
      }
      for (auto &p : def.dlgParams) {
        auto value =
            p.isGui ? model->getGUIParam(p.name) : model->getLogicParam(p.name);
        result << QVariantMap{{"key", QString(p.isGui ? "gui:" : "logic:") +
                                          QString::fromStdString(p.name)},
                              {"label", QString::fromStdString(p.textLabel)},
                              {"type", QString::fromStdString(p.type)},
                              {"value", QString::fromStdString(value)},
                              {"minimum", p.Rmin},
                              {"maximum", p.Rmax}};
      }
    }
  return result;
}
bool Editor::applyParameters(const QVariantMap &values) {
  try {
    auto fields = parameterFields();
    for (auto value : fields) {
      auto f = value.toMap();
      auto type = f["type"].toString(), key = f["key"].toString();
      if (type == "CHOICE" && values.contains(key) &&
          !f["choices"].toStringList().contains(values[key].toString()))
        throw std::runtime_error("Choose a valid output polarity");
      if ((type == "INT" || type == "FLOAT") && values.contains(key)) {
        bool ok = false;
        double n = values[key].toString().toDouble(&ok);
        if (!ok || (type=="INT" && std::floor(n)!=n) || n < f["minimum"].toDouble() || n > f["maximum"].toDouble())
          throw std::runtime_error("Parameter is outside its allowed range");
      }
    }
    edit("Gate properties", [&](auto &f) {
      for (auto &g : f.pages[pageIndex].gates)
        if (selected.contains(QString::fromStdString(g.uuid)))
          for (auto i = values.begin(); i != values.end(); ++i) {
            bool fileAction=false;
            for(auto field:fields){auto v=field.toMap();if(v["key"].toString()==i.key()&&(v["type"]=="FILE_IN"||v["type"]=="FILE_OUT"))fileAction=true;}
            if(fileAction)continue;
            bool gui = i.key().startsWith("gui:");
            auto name = i.key().mid(gui ? 4 : 6).toStdString();
            setParam(g, name, i.value().toString().toStdString(), gui);
          }
    });
    return true;
  } catch (const std::exception &e) {
    setStatus(QString::fromUtf8(e.what()));
    return false;
  }
}
QString Editor::helpUrl() const {
  return QUrl::fromLocalFile(QString::fromStdString(appConfig().resourcesDir) +
                             "/help/Introduction.htm")
      .toString();
}
QVariantList Editor::helpTopics() const {
  // HTML Help's original contents file is the authority for names, order and
  // nesting. It is HTML (with optional closing li tags), not well-formed XML.
  QFile contents(QString::fromStdString(appConfig().resourcesDir) + "/help/KLS_Logic.hhc");
  if (!contents.open(QIODevice::ReadOnly))
    return {QVariantMap{{"title", "Introduction"}, {"file", "Introduction.htm"}, {"depth", 0}}};
  const auto html = QString::fromLatin1(contents.readAll());
  const auto options = QRegularExpression::CaseInsensitiveOption |
                       QRegularExpression::DotMatchesEverythingOption;
  const QRegularExpression token("<ul\\b[^>]*>|</ul\\s*>|<object\\b[^>]*>.*?</object\\s*>", options);
  const QRegularExpression param("<param\\b[^>]*>", options);
  const QRegularExpression name("name\\s*=\\s*\"([^\"]*)\"", options);
  const QRegularExpression value("value\\s*=\\s*\"([^\"]*)\"", options);
  QVariantList topics;
  int depth = -1;
  auto tokens = token.globalMatch(html);
  while (tokens.hasNext()) {
    const auto entry = tokens.next().captured();
    if (entry.startsWith("<ul", Qt::CaseInsensitive)) { ++depth; continue; }
    if (entry.startsWith("</ul", Qt::CaseInsensitive)) { --depth; continue; }
    QString title, file;
    auto fields = param.globalMatch(entry);
    while (fields.hasNext()) {
      const auto field = fields.next().captured();
      const auto key = name.match(field).captured(1);
      const auto text = value.match(field).captured(1);
      if (key.compare("Name", Qt::CaseInsensitive) == 0) title = text;
      if (key.compare("Local", Qt::CaseInsensitive) == 0) file = text;
    }
    if (title.isEmpty() || depth < 0) continue;
    title.replace("&amp;", "&");
    topics << QVariantMap{{"title", title}, {"file", file}, {"depth", depth},
                         {"category", file.isEmpty()}};
  }
  return topics;
}
QString Editor::helpBaseUrl() const {
  return QUrl::fromLocalFile(QString::fromStdString(appConfig().resourcesDir) + "/help/").toString();
}
QString Editor::helpText(const QString &topic) const {
  if (QFileInfo(topic).fileName() != topic || !topic.endsWith(".htm", Qt::CaseInsensitive)) return {};
  QFile input(QString::fromStdString(appConfig().resourcesDir) + "/help/" + topic);
  if (!input.open(QIODevice::ReadOnly)) return "<p>This tutorial page is unavailable.</p>";
  QString html = QString::fromLatin1(input.readAll());
  QRegularExpression body("<body[^>]*>(.*)</body>", QRegularExpression::CaseInsensitiveOption | QRegularExpression::DotMatchesEverythingOption);
  auto match = body.match(html);
  if (match.hasMatch()) html = match.captured(1);
  html.remove(QRegularExpression("<script\\b[^>]*>.*?</script>", QRegularExpression::CaseInsensitiveOption | QRegularExpression::DotMatchesEverythingOption));
  return html;
}
QString Editor::changelogText() const { return QString::fromUtf8(CEDARLOGIC_CHANGELOG); }
bool Editor::beginSigning() {
  if (QString::fromStdString(appConfig().appSettings.signatureName).trimmed().isEmpty()) {
    setStatus("A Sign username is required before signing a circuit.");
    emit signatureRequired();
    return false;
  }
  return !locked;
}
void Editor::snapshot() {
  if (!dirty())
    return;
  QDir().mkpath(QFileInfo(recoveryPath).absolutePath());
  QSaveFile output(recoveryPath);
  if (!output.open(QIODevice::WriteOnly)) {
    setStatus("Autosave failed: " + output.errorString());
    return;
  }
  auto data = QByteArray::fromStdString(cl::writeCircuitFile(runtimeFile()));
  if (output.write(data)!=data.size() || !output.commit())
    setStatus("Autosave failed: " + output.errorString());
}
void Editor::checkRecovery() {
  QDir dir(QFileInfo(recoveryPath).absolutePath());
  for (const auto &name :
       dir.entryList({"recovery*.cdl"}, QDir::Files, QDir::Time)) {
    auto path = dir.filePath(name);
    if (path == recoveryPath)
      continue;
    auto candidate=std::make_unique<QLockFile>(path + ".lock");
    candidate->setStaleLockTime(0);
    if (!candidate->tryLock())
      continue;
    if (DesktopDialogs::question(*appearance, nullptr, "Recover circuit",
                              "An autosaved circuit is available. Recover it?",
                              QMessageBox::Yes | QMessageBox::No) ==
        QMessageBox::Yes) {
      QFile input(path);
      if (input.open(QIODevice::ReadOnly)) {
        try {
          auto restored = cl::loadCircuit(input.readAll().toStdString()).file;
          if (restored.pages.empty()) restored.pages.push_back({});
          const int dropped=repairPinClaims(restored);
          validateDocument(restored);
          edit("Recover circuit", [&](auto &f) { f = restored; });
          undoStack.resetClean();
          recoveredPath=path;
          recoveredLock=std::move(candidate);
          snapshot();
          if (dropped) setStatus(QString("Recovered with %1 conflicting pin connections dropped; review wiring before saving.").arg(dropped));
          emit cameraFitRequested();
        } catch (const std::exception &e) {
          setStatus(QString::fromUtf8(e.what()));
        }
      }
      return;
    } else
      QFile::remove(path);
  }
}
bool Editor::hasWireAt(QPointF point, double radius) const {
  for (const auto &wire : wires)
    if (wire->hover(point.x(), point.y(), radius))
      return true;
  return false;
}
bool Editor::startWireMove(QPointF point, double radius) {
  if (locked)
    return false;
  for (size_t i = 0; i < wires.size(); ++i)
    if (wires[i]->hover(point.x(), point.y(), radius)) {
      klsCollisionObject mouse(COLL_MOUSEBOX);
      klsBBox box;
      box.addPoint({static_cast<float>(std::floor(point.x()*2+0.5)/2 - radius),
                    static_cast<float>(std::floor(point.y()*2+0.5)/2 - radius)});
      box.addPoint({static_cast<float>(std::floor(point.x()*2+0.5)/2 + radius),
                    static_cast<float>(std::floor(point.y()*2+0.5)/2 + radius)});
      mouse.setBBox(box);
      if (!wires[i]->startSegDrag(&mouse))
        continue;
      moveBefore = file;
      draggingWire = i;
      wireDragRadius = radius;
      selected.clear();
      selectedWires = {
          QString::fromStdString(file.pages[pageIndex].wires[i].ids[0])};
      selectionChanged();
      return true;
    }
  return false;
}
void Editor::moveWire(QPointF point) {
  if (draggingWire < 0)
    return;
  klsCollisionObject mouse(COLL_MOUSEBOX);
  klsBBox box;
  box.addPoint(
      {static_cast<float>(std::floor(point.x()*2+0.5)/2 - wireDragRadius),
       static_cast<float>(std::floor(point.y()*2+0.5)/2 - wireDragRadius)});
  box.addPoint(
      {static_cast<float>(std::floor(point.x()*2+0.5)/2 + wireDragRadius),
       static_cast<float>(std::floor(point.y()*2+0.5)/2 + wireDragRadius)});
  mouse.setBBox(box);
  wires[draggingWire]->updateSegDrag(&mouse);
  emit sceneChanged();
}
void Editor::finishWireMove() {
  if (draggingWire < 0)
    return;
  bool valid = wires[draggingWire]->endSegDrag();
  draggingWire = -1;
  if (valid)
    captureWires();
  auto after = file;
  file = moveBefore;
  if (valid && !(after == file))
    undoStack.push(new Change(this, "Route wire", file, std::move(after)));
  else
    rebuild(false);
}

void Editor::signCircuit(const QString &response) {
  if (!beginSigning()) return;
  auto name =
      QString::fromStdString(appConfig().appSettings.signatureName).trimmed();
  if (response.trimmed().isEmpty()) {
    setStatus("Enter a circuit status before signing.");
    return;
  }
  auto b = bounds();
  edit("Sign circuit", [&](auto &f) {
    for (int i = 0; i < 2; ++i) {
      cl::GateInstance gate;
      gate.uuid = uuid().toStdString();
      gate.libName = "AA_LABEL";
      gate.at = {b.center().x(), b.bottom() + (i == 0 ? 2.0 : -0.5)};
      gate.params = {{"LABEL_TEXT",
                      (i == 0 ? name : response.trimmed()).toStdString(), true},
                     {"TEXT_HEIGHT", "2.0", true}};
      f.pages[pageIndex].gates.push_back(gate);
    }
  });
}
QString Editor::chooseParameterFile(bool save) {
  return save ? QFileDialog::getSaveFileName(nullptr, "Choose output file")
              : QFileDialog::getOpenFileName(nullptr, "Choose input file");
}

cl::CircuitFile Editor::runtimeFile() const {
  auto result = file;
  for (auto &page : result.pages)
    for (auto &gate : page.gates) {
      gate.params.erase(std::remove_if(gate.params.begin(),gate.params.end(),[](const auto &p){return !p.gui && (p.name=="PULSE"||p.name=="READ_FILE"||p.name=="WRITE_FILE"||p.name=="PAUSE_SIM"||p.name=="MemoryReset");}),gate.params.end());
      auto runtime = runtimeParams.find(gate.uuid);
      if (runtime == runtimeParams.end())
        continue;
      for (auto param : runtime->second)
        if (param.first != "PAUSE_SIM" && param.first != "MemoryReset" && param.first != "PULSE" && param.first != "READ_FILE" && param.first != "WRITE_FILE")
          setParam(gate, param.first, param.second, false);
    }
  return result;
}
bool Editor::memoryDialog() {
  if (selected.size() != 1) return false;
  const auto key = *selected.begin();
  auto resolve = [this, key]() -> guiGateRAM * {
    auto id = ids.gates.find(key.toStdString());
    if (id == ids.gates.end()) return nullptr;
    auto g = gates.find(id->second);
    return g == gates.end() ? nullptr : dynamic_cast<guiGateRAM *>(g->second.get());
  };
  auto ram = resolve();
  if (!ram) return false;
  if (auto existing = memoryDialogs.value(key)) {
    existing->show(); existing->raise(); existing->activateWindow();
    return true;
  }
  auto dialog = new QDialog;
  memoryDialogs.insert(key, dialog);
  dialog->setObjectName("memoryContentsDialog");
  dialog->setProperty("memoryGate", key);
  dialog->setAttribute(Qt::WA_DeleteOnClose);
  QString caption;
  for (const auto &gate : file.pages[pageIndex].gates)
    if (QString::fromStdString(gate.uuid) == key)
      caption = QString::fromStdString(gateLibrary().libraries.at(ram->getLibraryName()).at(gate.libName).caption);
  dialog->setWindowTitle(caption + " — Memory contents");
  dialog->resize(940, 560);
  dialog->setMinimumSize(600, 320);
  dialog->winId();
  if (auto owner = QGuiApplication::focusWindow()) dialog->windowHandle()->setTransientParent(owner);
  auto recolor = [this, dialog] {
    auto p = dialog->palette();
    p.setColor(QPalette::Window, appearance->panel());
    p.setColor(QPalette::WindowText, appearance->text());
    p.setColor(QPalette::Base, appearance->background());
    p.setColor(QPalette::Text, appearance->text());
    p.setColor(QPalette::Button, appearance->raised());
    p.setColor(QPalette::ButtonText, appearance->text());
    p.setColor(QPalette::Highlight, appearance->accent());
    dialog->setPalette(p);
    DesktopDialogs::style(*dialog, *appearance);
  };
  recolor(); connect(appearance, &Appearance::changed, dialog, recolor);
  auto layout = new QVBoxLayout(dialog);
  auto decimal = new QCheckBox("Show Decimal", dialog);
  decimal->setObjectName("memoryShowDecimal");
  layout->addWidget(decimal);
  auto table = new QTableView(dialog);
  table->setObjectName("memoryValues");
  auto model = new MemoryTable(
      QString::fromStdString(ram->getLogicParam("ADDRESS_BITS")).toInt(),
      QString::fromStdString(ram->getLogicParam("DATA_BITS")).toInt(), resolve,
      [this, key](unsigned long address, unsigned long data) {
        edit("Edit RAM", [&](auto &file) {
          for (auto &page : file.pages) for (auto &g : page.gates)
            if (QString::fromStdString(g.uuid) == key)
              setParam(g, "Address:" + std::to_string(address), std::to_string(data), false);
        });
      }, table);
  table->setModel(model);
  table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
  table->horizontalHeader()->setMinimumSectionSize(42);
  table->setSelectionMode(QAbstractItemView::SingleSelection);
  connect(decimal, &QCheckBox::toggled, model, [model](bool value) { model->setDecimal(value); });
  layout->addWidget(table);
  auto buttons = new QDialogButtonBox(QDialogButtonBox::Close, dialog);
  auto load = buttons->addButton("Open…", QDialogButtonBox::ActionRole);
  auto save = buttons->addButton("Save…", QDialogButtonBox::ActionRole);
  load->setObjectName("memoryOpen"); save->setObjectName("memorySave");
  layout->addWidget(buttons);
  connect(load, &QPushButton::clicked, dialog, [this, key, dialog] { memoryFileForGate(key, false, dialog); });
  connect(save, &QPushButton::clicked, dialog, [this, key, dialog] { memoryFileForGate(key, true, dialog); });
  connect(buttons, &QDialogButtonBox::rejected, dialog, &QDialog::close);
  connect(this, &Editor::frameReady, model, [model] { model->refresh(); });
  connect(this, &Editor::sceneChanged, dialog, [resolve, dialog, model] {
    if (!resolve()) dialog->close(); else model->refresh();
  });
  connect(dialog, &QObject::destroyed, this, [this, key] { memoryDialogs.remove(key); });
  DesktopDialogs::style(*dialog, *appearance);
  dialog->show();
  return true;
}
