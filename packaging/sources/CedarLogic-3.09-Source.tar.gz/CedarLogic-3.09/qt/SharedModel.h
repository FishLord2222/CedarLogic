#pragma once
#include "GateLibrary.h"
#include "circuit_file.hpp"
#include "guiGate.h"
#include "guiWire.h"
#include <map>
#include <memory>
#include <string>

std::unique_ptr<guiGate> makeGate(const std::string &name,
                                  unsigned long id = 0);
std::string decoderOutputPolarity(const LibraryGate &definition,
                                const cl::GateInstance &gate);
struct DocumentIds {
  std::map<std::string, unsigned long> gates;
  std::map<unsigned long, std::string> gateUuids;
  std::map<std::string, IDType> wires;
  explicit DocumentIds(const cl::CircuitFile &file);
};
