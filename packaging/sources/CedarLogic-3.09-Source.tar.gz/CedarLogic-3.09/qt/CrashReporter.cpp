// Native trace capture preserves the original crash-report workflow using Qt.
#include "CrashReporter.h"
#include <QApplication>
#include <QClipboard>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFile>
#include <QDir>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSysInfo>
#include <QVBoxLayout>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <string>
#ifdef _WIN32
#include <windows.h>
#include <dbghelp.h>
#else
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#endif
namespace {
std::string g_crashLogPath, g_crashHeader;
QString g_reportPath;
#ifdef _WIN32
std::wstring g_crashLogPathWide;
static const char *shortSourcePath(const char *full, char *buf, size_t bufLen) {
    const char *p = strstr(full, "src\\");
    if (!p) p = strstr(full, "src/");
    if (!p) { const char *s = strrchr(full, '\\'); p = s ? s + 1 : full; }
    size_t i = 0;
    for (; p[i] && i + 1 < bufLen; i++) buf[i] = (p[i] == '\\') ? '/' : p[i];
    buf[i] = '\0';
    return buf;
}

// On an otherwise-unhandled crash, walk the faulting thread's stack, symbolize
// it against the .pdb shipped next to the exe, and write a readable trace to
// %TEMP%\CedarLogic_crashtrace.log. Turns "it just crashed" into an actual
// function + file:line, which matters for a GUI app where the nastiest bugs
// only surface through live interaction and can't be caught under a debugger.
static LONG WINAPI writeCrashTrace(EXCEPTION_POINTERS *ep) {
    FILE *f = _wfopen(g_crashLogPathWide.c_str(), L"wb"); // binary: clean '\n', no '\r\n'
    if (f == NULL) return EXCEPTION_CONTINUE_SEARCH;

    HANDLE proc = GetCurrentProcess();
    SymSetOptions(SYMOPT_LOAD_LINES | SYMOPT_DEFERRED_LOADS | SYMOPT_UNDNAME);
    SymInitialize(proc, NULL, TRUE);

    fputs(g_crashHeader.c_str(), f);
    fprintf(f, "Unhandled exception 0x%08lX at %p\n",
            ep->ExceptionRecord->ExceptionCode, ep->ExceptionRecord->ExceptionAddress);

    // For an access violation, ExceptionInformation[0] is 0=read/1=write/8=DEP
    // and [1] is the faulting address -- the actual bad pointer we dereferenced.
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION &&
        ep->ExceptionRecord->NumberParameters >= 2) {
        ULONG_PTR kind = ep->ExceptionRecord->ExceptionInformation[0];
        fprintf(f, "  %s address 0x%p\n",
                kind == 1 ? "write to" : kind == 8 ? "execute at" : "read from",
                (void *)ep->ExceptionRecord->ExceptionInformation[1]);
    }

    // Faulting instruction as module+RVA, which is stable across ASLR runs and
    // can be mapped back to a source line with the .pdb offline.
    DWORD64 faultBase = SymGetModuleBase64(proc, (DWORD64)ep->ExceptionRecord->ExceptionAddress);
    if (faultBase) {
        char mod[MAX_PATH] = {};
        GetModuleFileNameA((HMODULE)faultBase, mod, MAX_PATH);
        fprintf(f, "  fault at %s +0x%llx (base 0x%llx)\n", mod,
                (unsigned long long)((DWORD64)ep->ExceptionRecord->ExceptionAddress - faultBase),
                (unsigned long long)faultBase);
    }
    fprintf(f, "\n");

    CONTEXT *ctx = ep->ContextRecord;
    STACKFRAME64 frame = {};
    DWORD machine;
#if defined(_M_X64)
    machine = IMAGE_FILE_MACHINE_AMD64;
    frame.AddrPC.Offset = ctx->Rip;    frame.AddrPC.Mode = AddrModeFlat;
    frame.AddrFrame.Offset = ctx->Rbp; frame.AddrFrame.Mode = AddrModeFlat;
    frame.AddrStack.Offset = ctx->Rsp; frame.AddrStack.Mode = AddrModeFlat;
#elif defined(_M_IX86)
    machine = IMAGE_FILE_MACHINE_I386;
    frame.AddrPC.Offset = ctx->Eip;    frame.AddrPC.Mode = AddrModeFlat;
    frame.AddrFrame.Offset = ctx->Ebp; frame.AddrFrame.Mode = AddrModeFlat;
    frame.AddrStack.Offset = ctx->Esp; frame.AddrStack.Mode = AddrModeFlat;
#else
    machine = IMAGE_FILE_MACHINE_UNKNOWN;
#endif
    for (int i = 0; i < 96; i++) {
        if (!StackWalk64(machine, proc, GetCurrentThread(), &frame, ctx, NULL,
                         SymFunctionTableAccess64, SymGetModuleBase64, NULL))
            break;
        if (frame.AddrPC.Offset == 0) break;
        DWORD64 addr = frame.AddrPC.Offset;

        char symBuf[sizeof(SYMBOL_INFO) + 512] = {};
        SYMBOL_INFO *sym = (SYMBOL_INFO *)symBuf;
        sym->SizeOfStruct = sizeof(SYMBOL_INFO);
        sym->MaxNameLen = 511;
        DWORD64 disp = 0;
        if (SymFromAddr(proc, addr, &disp, sym)) {
            IMAGEHLP_LINE64 line = {};
            line.SizeOfStruct = sizeof(line);
            DWORD lineDisp = 0;
            if (SymGetLineFromAddr64(proc, addr, &lineDisp, &line)) {
                char rel[MAX_PATH];
                fprintf(f, "  %-42s %s:%lu\n", sym->Name,
                        shortSourcePath(line.FileName, rel, sizeof(rel)), line.LineNumber);
            } else {
                fprintf(f, "  %s +0x%llx\n", sym->Name, (unsigned long long)disp);
            }
        } else {
            DWORD64 base = SymGetModuleBase64(proc, addr);
            if (base) {
                char mod[MAX_PATH] = {};
                GetModuleFileNameA((HMODULE)base, mod, MAX_PATH);
                const char *slash = strrchr(mod, '\\');
                fprintf(f, "  %s +0x%llx\n", slash ? slash + 1 : mod,
                        (unsigned long long)(addr - base));
            } else {
                fprintf(f, "  0x%llx\n", (unsigned long long)addr);
            }
        }
    }
    fflush(f);
    fclose(f);

    // Reporting UI is deferred until the next healthy launch.
    return EXCEPTION_CONTINUE_SEARCH; // let the OS still report/terminate as usual
}
#else
static volatile sig_atomic_t handlingFatal = 0;
static const char *crashSignalName(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV (segmentation fault)";
        case SIGABRT: return "SIGABRT (abort)";
        case SIGBUS:  return "SIGBUS (bus error)";
        case SIGFPE:  return "SIGFPE (floating-point exception)";
        case SIGILL:  return "SIGILL (illegal instruction)";
        default:      return "fatal signal";
    }
}

static void writeTrace(int fd, const char *bytes, size_t size) {
    while (size) {
        const auto written = write(fd, bytes, size);
        if (written > 0) { bytes += written; size -= written; }
        else if (written < 0 && errno == EINTR) continue;
        else break;
    }
}
static void posixCrashHandler(int sig, siginfo_t *, void *) {
    if (handlingFatal) _exit(128 + sig);
    handlingFatal = 1;
    int fd = open(g_crashLogPath.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd >= 0) {
        writeTrace(fd, g_crashHeader.data(), g_crashHeader.size());
        const char *label = "Fatal signal: ";
        writeTrace(fd, label, strlen(label));
        const char *name = crashSignalName(sig);
        writeTrace(fd, name, strlen(name));
        writeTrace(fd, "\n\n", 2);
        close(fd);
    }
    // Restore the default action and re-raise so the OS still produces its
    // normal crash report / core dump.
    signal(sig, SIG_DFL);
    raise(sig);
}
#endif
}
QString CrashReporter::reportPath() { return g_reportPath; }
void CrashReporter::install(const QString &path) {
  const auto destination = path.isEmpty() ? QDir::temp().filePath("CedarLogic_crashtrace.log") : path;
  g_reportPath = destination;
  g_crashLogPath = QFile::encodeName(destination).toStdString();
#ifdef _WIN32
  g_crashLogPathWide = destination.toStdWString();
#endif
  g_crashHeader = ("CedarLogic " + QCoreApplication::applicationVersion() + " (" +
      QString::number(sizeof(void*)*8) + "-bit) on " + QSysInfo::prettyProductName() + "\n\n").toStdString();
#ifdef _WIN32
  SetUnhandledExceptionFilter(writeCrashTrace);
#else
  handlingFatal = 0;
  struct sigaction sa{};
  sa.sa_sigaction = posixCrashHandler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_SIGINFO | SA_RESETHAND;
  for (int sig : {SIGSEGV, SIGABRT, SIGBUS, SIGFPE, SIGILL}) sigaction(sig, &sa, nullptr);
#endif
}
void CrashReporter::showPending() {
  QFile file(reportPath());
  if (!file.open(QIODevice::ReadOnly)) return;
  const auto trace = QString::fromUtf8(file.readAll()); file.close();
  if (trace.isEmpty()) return;
  const auto line = trace.indexOf('\n');
  const QString report = "### Steps to Reproduce\n\nDescribe what you were doing when it crashed.\n\n"
      "### Crash trace\n\n```\n" + trace.mid(line+1).trimmed() + "\n```\n\n### Version\n\n" + trace.left(line) + "\n";
  QDialog dialog;
  dialog.setObjectName("crashReportDialog"); dialog.setWindowTitle("Local crash report"); dialog.resize(700,500);
  auto layout = new QVBoxLayout(&dialog);
  auto label = new QLabel("CedarLogic closed unexpectedly the last time it ran. You can copy the local diagnostic report. No crash details are sent over the network.");
  label->setWordWrap(true); layout->addWidget(label);
  auto text = new QPlainTextEdit(trace); text->setReadOnly(true); layout->addWidget(text);
  auto buttons = new QDialogButtonBox;
  auto copy = buttons->addButton("Copy report", QDialogButtonBox::ActionRole); copy->setObjectName("copyCrashReport");
  auto dismiss = buttons->addButton("Dismiss", QDialogButtonBox::RejectRole); dismiss->setObjectName("dismissCrashReport");
  layout->addWidget(buttons);
  auto copyReport = [report]{ QApplication::clipboard()->setText(report); };
  QObject::connect(copy, &QPushButton::clicked, copyReport);
  QObject::connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
  dialog.exec();
  file.remove(); // Preserve legacy one-prompt-per-crash behavior.
}
