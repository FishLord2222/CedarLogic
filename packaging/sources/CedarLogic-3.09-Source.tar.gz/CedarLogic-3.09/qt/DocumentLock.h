#pragma once
#include <QByteArray>
#include <QLockFile>
#include <QString>
#include <memory>
class DocumentLock {
public:
  ~DocumentLock();
  bool acquire(const QString &path, QString &error);

private:
  std::unique_ptr<QLockFile> qtLock;
  QString marker;
  QByteArray owner;
};
