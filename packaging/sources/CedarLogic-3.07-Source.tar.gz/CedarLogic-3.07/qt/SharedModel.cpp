#include "SharedModel.h"
#include "PaletteDrag.h"
#include "RenderMode.h"
#include "Settings.h"
#include <mutex>
#include <stdexcept>
#include <algorithm>
#include <cmath>

namespace {
// Keep the original decoder body, labels and hotspots. Only the output leads
// change, to make the saved polarity visible in every rendering/export path.
class DecoderGate final : public guiGate {
  const LibraryGate &definition;
  std::vector<GLPoint2f> originalVertices;
  std::vector<GateCircle> originalCircles;
  bool ready = false, low = false;
  void updateSymbol() {
    vertices = originalVertices; circles = originalCircles;
    if (low) for (const auto &pin : definition.hotspots) {
      if (pin.isInput) continue;
      bool added = false;
      for (size_t i = 0; i + 1 < vertices.size(); i += 2) {
        auto &a = vertices[i]; auto &b = vertices[i + 1];
        auto atPin = [&](const GLPoint2f &p) {
          return std::abs(p.x-pin.x)<1e-5 && std::abs(p.y-pin.y)<1e-5;
        };
        if (!atPin(a) && !atPin(b)) continue;
        auto &body = atPin(a) ? b : a;
        const float dx = pin.x-body.x, dy = pin.y-body.y;
        const float length = std::hypot(dx,dy);
        if (length < .8f || length > 1.2f) continue;
        const float ux = dx/length, uy = dy/length, radius = .2f;
        if (!added) {
          insertCircle(body.x+ux*radius,body.y+uy*radius,radius,24);
          added = true;
        }
        body.x += ux*radius*2; body.y += uy*radius*2;
      }
    }
    calcBBox(); updateBBoxes(true);
  }
public:
  explicit DecoderGate(const LibraryGate &def) : definition(def) {
    low = std::any_of(def.hotspots.begin(),def.hotspots.end(),
                     [](const auto &pin){return !pin.isInput && pin.isInverted;});
  }
  void initializeSymbol() {
    originalVertices = vertices; originalCircles = circles; ready = true;
    updateSymbol();
  }
  void setLogicParam(std::string name, std::string value) override {
    guiGate::setLogicParam(name,value);
    if (name=="OUTPUT_POLARITY" && (value=="LOW" || value=="HIGH")) {
      const bool desired = value=="LOW";
      if (low==desired) return;
      low = desired;
      if (ready) updateSymbol();
    }
  }
  unsigned long long geometryHash() const override {
    return (guiGate::geometryHash() ^ (low ? 1ULL : 0ULL)) * 1099511628211ULL;
  }
};
}
std::string decoderOutputPolarity(const LibraryGate &definition,
                                const cl::GateInstance &gate) {
  for (const auto &param : gate.params)
    if (!param.gui && param.name == "OUTPUT_POLARITY" &&
        (param.value == "HIGH" || param.value == "LOW")) return param.value;
  // Standard decoders are active high; the original decoder chip is active low.
  for (const auto &pin : definition.hotspots)
    if (!pin.isInput && pin.isInverted) return "LOW";
  return "HIGH";
}
Settings &appConfig() {
  static Settings value;
  return value;
}
GateLibrary &gateLibrary() {
  static GateLibrary value;
  return value;
}
PaletteDrag &paletteDrag() {
  static PaletteDrag value;
  return value;
}
RenderMode &renderMode() {
  static RenderMode value;
  return value;
}

DocumentIds::DocumentIds(const cl::CircuitFile &file) {
  static std::mutex mutex;
  static std::map<std::string, unsigned long> stableGates;
  static std::map<std::string, IDType> stableWires;
  static unsigned long gid = 1;
  static IDType wid = 1;
  std::lock_guard<std::mutex> guard(mutex);
  for (const auto &page : file.pages) {
    for (const auto &gate : page.gates) {
      if (!stableGates.count(gate.uuid))
        stableGates[gate.uuid] = gid++;
      if (!gates.emplace(gate.uuid, stableGates.at(gate.uuid)).second)
        throw std::runtime_error("Duplicate gate identifier");
      gateUuids.emplace(stableGates.at(gate.uuid), gate.uuid);
    }
    for (const auto &wire : page.wires)
      for (const auto &id : wire.ids) {
        if (!stableWires.count(id))
          stableWires[id] = wid++;
        wires.emplace(id, stableWires.at(id));
      }
  }
}

std::unique_ptr<guiGate> makeGate(const std::string &name, unsigned long id) {
  auto owner = gateLibrary().gateNameToLibrary.find(name);
  if (owner == gateLibrary().gateNameToLibrary.end())
    throw std::runtime_error("Unknown library gate: " + name);
  const auto &def = gateLibrary().libraries.at(owner->second).at(name);
  std::unique_ptr<guiGate> gate;
  const auto &type = def.guiType;
  if (def.logicType == "DECODER")
    gate.reset(new DecoderGate(def));
  else if (type == "REGISTER")
    gate.reset(new guiGateREGISTER);
  else if (type == "TO" || type == "FROM")
    gate.reset(new guiTO_FROM);
  else if (type == "LABEL")
    gate.reset(new guiLabel);
  else if (type == "LED")
    gate.reset(new guiGateLED);
  else if (type == "TOGGLE")
    gate.reset(new guiGateTOGGLE);
  else if (type == "KEYPAD")
    gate.reset(new guiGateKEYPAD);
  else if (type == "PULSE")
    gate.reset(new guiGatePULSE);
  else if (type == "RAM")
    gate.reset(new guiGateRAM);
  else
    gate.reset(new guiGate);
  gate->setID(id);
  gate->setLibraryName(owner->second, name);
  for (auto l : def.shape)
    gate->insertLine(l.x1, l.y1, l.x2, l.y2, l.isLabel);
  for (auto a : def.arcs)
    gate->insertArc(a.cx, a.cy, a.r, a.startDeg, a.sweepDeg, a.isLabel);
  for (auto c : def.circles)
    gate->insertCircle(c.cx, c.cy, c.r, c.segs, c.isLabel);
  for (auto pin : def.hotspots) {
    gate->insertHotspot(pin.x, pin.y, pin.name, pin.busLines);
    if (pin.isInput)
      gate->declareInput(pin.name);
    else
      gate->declareOutput(pin.name);
  }
  for (auto p : def.guiParams)
    gate->setGUIParam(p.first, p.second);
  for (auto p : def.logicParams)
    gate->setLogicParam(p.first, p.second);
  if (auto decoder = dynamic_cast<DecoderGate *>(gate.get())) decoder->initializeSymbol();
  gate->calcBBox();
  gate->setGLcoords(0, 0);
  return gate;
}
