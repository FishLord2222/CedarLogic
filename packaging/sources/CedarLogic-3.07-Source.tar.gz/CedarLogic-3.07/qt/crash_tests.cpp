#include "CrashReporter.h"
#include <QApplication>
#include <QClipboard>
#include <QDialog>
#include <QFile>
#include <QProcess>
#include <QPushButton>
#include <QTemporaryDir>
#include <QTimer>
#include <csignal>
#include <iostream>
#ifdef _WIN32
#include <windows.h>
#endif
int main(int argc, char **argv) {
  QApplication app(argc,argv); app.setApplicationVersion("3.07");
  if (app.arguments().contains("--crash")) {
    CrashReporter::install(app.arguments().last());
#ifdef _WIN32
    RaiseException(EXCEPTION_ACCESS_VIOLATION,EXCEPTION_NONCONTINUABLE,0,nullptr);
#else
    std::raise(SIGABRT);
#endif
    return 2;
  }
  QTemporaryDir temp;
  const auto path=temp.filePath("trace.log");
  QProcess process; process.start(QCoreApplication::applicationFilePath(),{"--crash",path});
  if (!process.waitForFinished(10000)) { process.kill(); return 3; }
  QFile file(path);
  if (!file.open(QIODevice::ReadOnly)) { std::cerr << "No crash trace written\n"; return 4; }
  const auto trace=file.readAll(); file.close();
  if (!trace.contains("CedarLogic 3.07") || (!trace.contains("Fatal signal") && !trace.contains("Unhandled exception"))) return 5;
  CrashReporter::install(path);
  bool copied=false;
  QTimer::singleShot(100,[&] {
    for (auto widget : QApplication::topLevelWidgets()) {
      if(widget->objectName()!="crashReportDialog")continue;
      auto copy=widget->findChild<QPushButton*>("copyCrashReport");
      auto dismiss=widget->findChild<QPushButton*>("dismissCrashReport");
      if(copy && dismiss) { copy->click(); copied=app.clipboard()->text().contains("### Crash trace"); dismiss->click(); }
    }
  });
  QTimer::singleShot(5000,&app,[]{for(auto widget:QApplication::topLevelWidgets())if(auto dialog=qobject_cast<QDialog*>(widget))dialog->reject();});
  CrashReporter::showPending();
  if(!copied || QFile::exists(path))return 6;
  CrashReporter::showPending();
  std::cout << "Isolated fatal crash capture, next-launch dialog, copy and dismissal passed\n";
  return 0;
}
