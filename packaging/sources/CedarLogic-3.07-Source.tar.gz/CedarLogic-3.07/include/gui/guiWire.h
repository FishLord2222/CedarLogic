/*****************************************************************************
   Project: CEDAR Logic Simulator
   Copyright 2006 Cedarville University, Benjamin Sprague,
                     Matt Lewellyn, and David Knierim
   All rights reserved.
   For license information see license.txt included with distribution.   

   guiWire: GUI representation of wire objects
*****************************************************************************/

#ifndef GUIWIRE_H_
#define GUIWIRE_H_

#include <cfloat>
#include <functional>
#include <string>
#include <vector>
#include "logic_values.h" // StateType
#include "klsCollisionChecker.h"
#include "wireSegment.h"

// Engine-neutral rendering seam (Workstream G); defined in gui/render/.
namespace cl { namespace render { class Scene; struct RenderStyle; } }

class guiGate;
class XMLParser;

float distanceToLine(GLPoint2f p, GLPoint2f l1, GLPoint2f l2);

struct glWireRenderInfo {
	vector< GLPoint2f > vertexPoints;
	vector< GLPoint2f > intersectPoints;
	vector< GLLine2f > lineSegments;
};

class guiWire : public klsCollisionObject {
public:
	guiWire();

	virtual ~guiWire();

	// Connection functions
	//		addConnection: if openMode is true, then no shape is calculated; waiting for setSegmentMap call.
	void addConnection(guiGate* iGate, string connection, bool openMode = false);

	void removeConnection(guiGate* iGate, string connection);

	// The circuit this wire belongs to; used to resolve a wireConnection's gid
	// to a live guiGate* (see gateOf). Set by the editor when the wire is created.
	void setGateResolver(std::function<guiGate*(unsigned long)> resolver) { gateResolver = std::move(resolver); }

	long numConnections();

	vector < wireConnection > getConnections();

	// Update the placement of a connection by extending/moving its
	//	segment.  Will set up a mouse coord from the current position
	//	and another one from the new position to pass to updateSegDrag
	void updateConnectionPos(unsigned long gid, string connection);

	// Emit this wire into the engine-neutral rendering Scene (Workstream G).
	void drawToScene(cl::render::Scene& scene,
	                 const cl::render::RenderStyle& style);

	bool hover(float cx, float cy, float delta);

	GLPoint2f getCenter();

	// Moving functions
	void move(GLPoint2f origin, GLPoint2f delta);

	// Create the bbox for this wire, based on
	// the bboxes of the wire segments. Also,
	// add the wire segments into the subObjs list:
	void calcBBox();

	// Selection functions
	bool isSelected();
	void select();
	void unselect();

	// Set the wire's first (and most likely only) Id.
	void setID(IDType wireId);

	// Get the wire's first (and most likely only) Id.
	IDType getID() const;

	// Set the all of the wire's Ids (For buses, really).
	void setIDs(const std::vector<IDType> &ids);

	// Set all of the wire's Ids (For buses, really).
	const std::vector<IDType> & getIDs() const;
	
	// Set the state for each wire id. (again multiple because buses)
	void setState(std::vector<StateType> state);
	
	// Set the state of a busline in this wire from its id.
	void setSubState(IDType buslineId, StateType state);

	// Get the state for each wire id.
	const std::vector<StateType> & getState() const;

	// Render-cache signatures (see guiGate). geometryHash covers the wire's
	// routing (its line segments) + selection; appearanceHash adds signal state
	// (the net colour). Float bits are hashed to avoid the negative-cast UB.
	unsigned long long geometryHash() const;
	unsigned long long appearanceHash() const;

	// Get the intersection points for drawing connection dots
	const std::vector<GLPoint2f>& getIntersectPoints() const { return renderInfo.intersectPoints; }

	// Give directions for XML tag definition of wire
	void saveWire(XMLParser* xparse);
	// Save in v1.x compatible format (single wire ID)
	void saveWireLegacy(XMLParser* xparse);

	// Get the list of pointers to segments that constitute the wire shape
	// Get the mapping of ID to segment that is the wire shape
	//	NOTE: To do anything with the returned map via intersections of segs
	//			you must set the segments' parent map pointer
	map < long, wireSegment > getSegmentMap();

	// Set the map/tree from which the wire will generate its shape.
	//	Tree must contain valid wireConnection information.
	//	IMPORTANT: Also must set nextSegID to be a valid ID
	void setSegmentMap(map < long, wireSegment > newSegMap);
	// Restore an already-normalized shape exactly (used by wire-drag undo/redo).
	void restoreSegmentMap(map < long, wireSegment > newSegMap);

	// We need to hold an initial seg map for undo/redo functionality.
	map < long, wireSegment > getOldSegmentMap();

	// Generates segList, all segments being generated
	//	from the coordinates of the connection point vertices.
	//	As segments are created, they are merged with segments
	//	following the same path, and duplicates are removed.
	void calcShape();  // TODO

	// Manual wire routing functionality
	//	Takes a mouse pointer and finds the segment in question.
	//	The segment is isolated between its nearest intersections
	//	and set as the dragging segment.
	bool startSegDrag(klsCollisionObject* mouse);  // TODO

	//	The current dragging segment is moved to a new position
	//	while the associated segments are added/modified to keep
	//	our drag segment connected in the tree
	void updateSegDrag(klsCollisionObject* mouse);

	//	The current dragging segment is dropped, clean up
	// Returns false when the proposed drag cannot be cleaned up safely.
	bool endSegDrag();

private:
	// Resolve a connection's gate id to its live guiGate* via the circuit.
	// Replaces the old raw guiGate* cached in wireConnection, which could
	// dangle across a gate delete/undo/paste. Returns nullptr if unresolvable.
	guiGate* gateOf(const wireConnection& c) const;

	// Atomically replace the whole segment tree. Detaches the collision
	// sub-objects (raw pointers into the segMap values about to be freed), swaps
	// the map in, then rebuilds the registration via calcBBox -- so a wholesale
	// reassignment can never leave the collision checker holding a dangling
	// wireSegment pointer. Every `segMap = newMap` goes through here.
	void commitSegMap(map < long, wireSegment > newSegMap);

	// The owning circuit (gate registry). Non-owning.
	std::function<guiGate*(unsigned long)> gateResolver;

	// Take existing segment connections and update their map keys
	bool refreshIntersections(bool removeBadSegs = false);

	// Self-explanatory, see comments in source
	void removeZeroLengthSegments();  // TODO

	// Take existing segments and merge concurrent segments
	void mergeSegments();
	void generateRenderInfo();  // TODO




	// Store the tree in a non-pointered way for easy copy
	map < long, wireSegment > segMap;
	map < long, wireSegment > oldSegMap;
	long nextSegID;

	// What is the whole wire connected to?
	vector< wireConnection > connectPoints;

	// Instance vars
	bool selected;
	bool setVerticalBar;
	long headSegment; // reference segment
	
	// The wire ids for each wire in the bus.
	// These same ids are used in the gui and logic systems.
	// The editor owns maps of IDs to wire models.
	// In these maps, the first bus id is used to look up the wire.
	// The other ids all point to null.
	std::vector<IDType> ids;

	// The state for each wire in the bus.
	// Most wires will have a vector of size 1.
	std::vector<StateType> state;
	
	klsBBox mouseCoords;

	// Handle a pointer for the segment being moved, -1 if not set
	long currentDragSegment;

	glWireRenderInfo renderInfo;
};

#endif /*GUIWIRE_H_*/
