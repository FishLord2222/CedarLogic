#!/usr/bin/env python3
"""Bundle the Qt desktop build with replaceable shared Qt libraries."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--sdk', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
source = Path(__file__).resolve().parents[1]
windows = sys.platform == 'win32'
version = '3.07'
name = f'CedarLogic-{version}'
stage = args.output / name
if stage.exists():
    shutil.rmtree(stage)
stage.mkdir(parents=True)
exe = 'CedarLogic.exe' if windows else 'CedarLogic'
binary = args.build / 'qt' / ('Release' if windows else '') / exe
if not binary.exists():
    binary = args.build / 'qt' / exe
if not binary.is_file() or not (args.sdk / 'bin').is_dir():
    parser.error('A completed desktop build and a Qt SDK are required')
target = stage / exe if windows else stage / 'bin' / exe
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(binary, target)
resources = stage / 'res' if windows else stage / 'share/CedarLogic/res'
shutil.copytree(binary.parent / 'res', resources)
for module in ['plugins', 'qml']:
    shutil.copytree(args.sdk / module, stage / module)
shutil.copytree(source / 'qt/licenses', stage / 'licenses/Qt')
shutil.copy2(source / 'LICENSE', stage / 'LICENSE-CedarLogic')
shutil.copytree(source / 'qt/third-party/Skia', stage / 'licenses/Skia')
(stage / 'OPEN-SOURCE-NOTICES.txt').write_text(
    'CedarLogic: GNU GPL. Qt 6.8.3: replaceable shared libraries under LGPL/GPL.\n'
    'Qt source: https://download.qt.io/archive/qt/6.8/6.8.3/submodules/\n'
    'Skia and fonts retain their upstream licenses.\n')
if windows:
    subprocess.run([str((args.sdk / 'bin/windeployqt.exe').resolve()), '--release',
                    '--qmldir', str(source / 'qt/qml'), str(target.resolve())], check=True)
    pdb = binary.with_suffix('.pdb')
    if pdb.exists():
        shutil.copy2(pdb, stage / pdb.name)
    (stage / 'qt.conf').write_text('[Paths]\nPlugins=plugins\nQmlImports=qml\n')
    archive = args.output / f'{name}-Windows-x64.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for file in sorted(stage.rglob('*')):
            if file.is_file():
                z.write(file, file.relative_to(args.output))
else:
    (stage / 'lib').mkdir()
    for file in (args.sdk / 'lib').glob('*.so*'):
        target_lib = stage / 'lib' / file.name
        if file.is_symlink():
            target_lib.symlink_to(file.readlink())
        else:
            shutil.copy2(file, target_lib)
    (stage / 'bin/qt.conf').write_text('[Paths]\nPrefix=..\nPlugins=plugins\nQmlImports=qml\n')
    launcher = stage / 'CedarLogic'
    launcher.write_text('#!/bin/sh\nset -eu\nbase=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\n'
                        'export LD_LIBRARY_PATH="$base/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"\n'
                        'exec "$base/bin/CedarLogic" "$@"\n')
    launcher.chmod(0o755)
    archive = args.output / f'{name}-Linux-x64.tar.gz'
    with tarfile.open(archive, 'w:gz') as t:
        t.add(stage, arcname=name)
print(archive)
