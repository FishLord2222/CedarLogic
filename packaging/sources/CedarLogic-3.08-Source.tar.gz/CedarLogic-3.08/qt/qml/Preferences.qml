import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
Dialog {
    id: prefs
    title: "Preferences"
    modal: true; parent:Overlay.overlay; width:Math.min(620,parent.width-24); height:Math.min(530,parent.height-24)
    anchors.centerIn: parent
    standardButtons: Dialog.Apply | Dialog.Ok | Dialog.Cancel
    property bool signingRequired:false
    function openForSigning(){section=2;signingRequired=true;open();Qt.callLater(function(){signatureName.forceActiveFocus()})}
    property var draft: ({})
    property string chosenMode: "system"
    property string chosenAccent: "Teal"
    property int section: 0
    function load() {
        draft = Object.assign({}, theme.editorSettings)
        chosenMode = theme.mode; chosenAccent = theme.accentName
    }
    function apply() { theme.apply(chosenMode,chosenAccent,draft) }
    function put(key,value) { let d=Object.assign({},draft);d[key]=value;draft=d }
    onOpened: load()
    onApplied: apply()
    onAccepted: apply()
    footer:DialogButtonBox { standardButtons:prefs.standardButtons;alignment:Qt.AlignRight;padding:12;spacing:8;delegate:AppButton {} }
    background: Rectangle { color: theme.panel; radius: 8; border.color: theme.border }
    header: Label { text: "Preferences";font.pixelSize: 20;font.weight: Font.DemiBold;color:theme.text; padding: 22 }
    contentItem: RowLayout {
        spacing: 22
        ColumnLayout {
            Layout.preferredWidth: 128;Layout.fillHeight: true
            Repeater {
                model: ["Appearance","Editor","Files"]
                delegate: Button {
                    required property string modelData
                    required property int index
                    text: modelData;Layout.fillWidth:true;implicitHeight:38
                    onClicked:prefs.section=index
                    background: Rectangle { radius:5;color:prefs.section===index?Qt.alpha(theme.accent,0.13):parent.hovered?theme.raised:"transparent" }
                    contentItem: Label { text:parent.text;color:prefs.section===index?theme.accent:theme.text;leftPadding:12;verticalAlignment:Text.AlignVCenter }
                }
            }
            Item { Layout.fillHeight:true }
        }
        Rectangle { Layout.fillHeight:true;Layout.preferredWidth:1;color:theme.border }
        ScrollView {
            id:sections;Layout.fillWidth:true;Layout.fillHeight:true;clip:true;contentWidth:availableWidth
            StackLayout {
            width:sections.availableWidth;height:Math.max(implicitHeight,sections.availableHeight)
            currentIndex:prefs.section
            ColumnLayout {
                spacing:16
                Label { text:"Appearance";font.pixelSize:18;font.bold:true;color:theme.text }
                Label { text:"Theme";color:theme.text }
                AppCombo {
                    Layout.fillWidth:true
                    model:["Follow system","Light","Dark"]
                    currentIndex:Math.max(0,["system","light","dark"].indexOf(prefs.chosenMode))
                    onActivated:prefs.chosenMode=["system","light","dark"][currentIndex]
                }
                Label { text:"Accent color";color:theme.text }
                GridLayout {
                    columns:3;columnSpacing:8;rowSpacing:8
                    Repeater {
                        model:[{name:"Teal",color:"#00b4b8"},{name:"Blue",color:"#4b92ee"},{name:"Purple",color:"#a47bea"},{name:"Orange",color:"#e99b48"},{name:"Green",color:"#4ab878"},{name:"Rose",color:"#df6a95"}]
                        delegate: Button {
                            required property var modelData
                            text:modelData.name;implicitWidth:110;implicitHeight:42
                            onClicked:prefs.chosenAccent=modelData.name
                            background:Rectangle { radius:5;color:theme.raised;border.width:prefs.chosenAccent===parent.modelData.name?2:1;border.color:prefs.chosenAccent===parent.modelData.name?parent.modelData.color:theme.border }
                            contentItem:Row { spacing:8;Rectangle { width:12;height:12;radius:6;color:parent.parent.modelData.color;anchors.verticalCenter:parent.verticalCenter }Label { text:parent.parent.text;color:theme.text;anchors.verticalCenter:parent.verticalCenter } }
                        }
                    }
                }
                Label { text:"Accents apply to controls and the overview frame.\nCircuits use their original colors.";wrapMode:Text.WordWrap;Layout.fillWidth:true;color:theme.muted;font.pixelSize:12 }
                Item { Layout.fillHeight:true }
            }
            ColumnLayout {
                spacing:12
                Label { text:"Editor";font.pixelSize:18;font.bold:true;color:theme.text }
                CheckBox { text:"Show gridlines";checked:!!prefs.draft.grid;onToggled:prefs.put("grid",checked) }
                CheckBox { objectName:"sidebarNamesPreference";text:"Show sidebar part names";checked:!!prefs.draft.sidebarNames;onToggled:prefs.put("sidebarNames",checked) }
                CheckBox { text:"Show wire connection points";checked:!!prefs.draft.connections;onToggled:prefs.put("connections",checked) }
                RowLayout {
                    Label { text:"Connection radius";color:theme.text;Layout.fillWidth:true }
                    SpinBox { from:5;to:100;value:Math.round((prefs.draft.connectionRadius||0.18)*100);editable:true;textFromValue:function(v){return (v/100).toFixed(2)};valueFromText:function(t){return Math.round(Number(t)*100)};onValueModified:prefs.put("connectionRadius",value/100) }
                }
                CheckBox { text:"Right-click rotates gates";checked:!!prefs.draft.rightClickRotate;onToggled:prefs.put("rightClickRotate",checked) }
                Label { text:"Use the middle mouse button to pan.\nScroll to zoom; Esc cancels placement or wiring.";color:theme.muted;font.pixelSize:12;wrapMode:Text.WordWrap;Layout.fillWidth:true }
                RowLayout {
                    Label { text:"Refresh rate (FPS)";color:theme.text;Layout.fillWidth:true }
                    SpinBox { from:10;to:1000;value:prefs.draft.fps||60;editable:true;onValueModified:prefs.put("fps",value) }
                }
                RowLayout {
                    Label { text:"Step interval (ms)";color:theme.text;Layout.fillWidth:true }
                    SpinBox { from:1;to:1000;value:prefs.draft.stepMs||25;editable:true;onValueModified:prefs.put("stepMs",value) }
                }
                Item { Layout.fillHeight:true }
            }
            ColumnLayout {
                spacing:16
                Label { text:"Files";font.pixelSize:18;font.bold:true;color:theme.text }
                RowLayout {
                    Label { text:"Autosave interval (minutes)";color:theme.text;Layout.fillWidth:true }
                    SpinBox { from:0;to:60;value:prefs.draft.autosaveMinutes===undefined?3:prefs.draft.autosaveMinutes;editable:true;onValueModified:prefs.put("autosaveMinutes",value) }
                }
                Label { text:"Set to 0 to disable autosave.";color:theme.muted;font.pixelSize:12 }
                Label { text:"Sign username";color:theme.text }
                Label { objectName:"signatureWarning";visible:prefs.signingRequired;text:"A Sign username is required before signing a circuit.";color:theme.accent;wrapMode:Text.WordWrap;Layout.fillWidth:true }
                AppField { id:signatureName;objectName:"signatureNameField";Layout.fillWidth:true;text:prefs.draft.signature||"";placeholderText:"Name shown on signed circuits";onTextEdited:prefs.put("signature",text) }
                Item { Layout.fillHeight:true }
            }
            }
        }
    }
}
